import { Component, inject, signal } from '@angular/core';
import { FormBuilder, ReactiveFormsModule, Validators } from '@angular/forms';
import { firstValueFrom } from 'rxjs';
import { SuccessModalComponent } from '../../components/success-modal/success-modal';
import { FormAlertComponent } from '../../components/form-alert/form-alert';
import { AuthService } from '../../services/auth.service';
import { DocumentosService } from '../../services/documentos.service';
import { SolicitudesSacramentoService } from '../../services/solicitudes-sacramento.service';
import { BeneficiariosSolicitudService } from '../../services/beneficiarios-solicitud.service';
import { InscripcionesCatequesisService } from '../../services/inscripciones-catequesis.service';
import { PersonasService } from '../../services/personas.service';
import { UsuariosService } from '../../services/usuarios.service';
import { CertificadosService } from '../../services/certificados.service';
import { mensajesTemporales } from '../../shared/utils/mensajes-temporales';
import {
  cedulaEcuatorianaValidator,
  telefonoEcuadorValidator,
  soloTextoValidator,
  nombresValidator,
  apellidosValidator,
  cedulasDistintasValidator,
  mensajeDeError,
  validarArchivo
} from '../../shared/utils/validaciones';

type ModalType =
  | 'bautizo'
  | 'comunion-select'
  | 'comunion-propia'
  | 'comunion-terceros'
  | 'confirmacion-select'
  | 'confirmacion-propia'
  | 'confirmacion-terceros'
  | 'matrimonio'
  | 'certificado'
  | null;

function nuevoArchivo() {
  return { nombre: signal(''), dataUrl: signal(''), mime: signal(''), error: signal('') };
}

type ArchivoAdjunto = ReturnType<typeof nuevoArchivo>;

@Component({
  selector: 'app-inscripciones',
  standalone: true,
  imports: [ReactiveFormsModule, SuccessModalComponent, FormAlertComponent],
  templateUrl: './inscripciones.html',
  styleUrl: './inscripciones.css'
})
export class InscripcionesComponent {
  protected authService = inject(AuthService);
  private documentosService = inject(DocumentosService);
  private solicitudesService = inject(SolicitudesSacramentoService);
  private beneficiariosService = inject(BeneficiariosSolicitudService);
  private inscripcionesCatequesisService = inject(InscripcionesCatequesisService);
  private personasService = inject(PersonasService);
  private usuariosService = inject(UsuariosService);
  private certificadosService = inject(CertificadosService);
  private fb = inject(FormBuilder);

  activeModal: ModalType = null;
  showSuccess = false;
  mensajeExitoModal = 'SOLICITUD\nENVIADA';
  guardando = signal(false);
  buscando = signal(false);
  mensajeError = mensajesTemporales(signal(''));
  mensajeDeError = mensajeDeError;

  readonly sacramentosOpciones = ['Bautismo', 'Primera Comunion', 'Confirmacion', 'Matrimonio'];

  // Mensajes informativos de la búsqueda por cédula (no son errores de validación)
  bautizoBusqueda = signal('');
  comunionBusqueda = signal('');
  confirmacionBusqueda = signal('');
  matrimonioBusqueda1 = signal('');
  matrimonioBusqueda2 = signal('');

  // Estado de búsqueda: indica si la persona autocompletada fue encontrada en el sistema
  // (si no se encontró, los campos deben quedar editables para completarlos a mano)
  bautizoRepresentanteEnSistema = signal(false);
  comunionPersonaEnSistema = signal(false);
  confirmacionPersonaEnSistema = signal(false);
  matrimonioPersona1EnSistema = signal(false);
  matrimonioPersona2EnSistema = signal(false);

  // Si la persona SÍ tiene cuenta de usuario propia y no tiene el certificado prerrequisito
  // emitido, no se le puede dejar continuar (debe subirlo desde su propia cuenta en "Subir
  // un certificado"). Si es una persona registrada pero SIN cuenta (o no registrada), el
  // certificado se puede adjuntar aquí mismo como respaldo, porque no tiene otra forma de
  // hacerlo.
  comunionBloqueado = signal(false);
  confirmacionBloqueado = signal(false);
  comunionTieneCuenta = signal(false);
  confirmacionTieneCuenta = signal(false);

  // Si el prerrequisito ya está validado (tenga o no cuenta la persona), no hace falta
  // adjuntar ningún certificado: el botón de subida solo debe aparecer cuando todavía
  // falta por cumplir.
  comunionCertificadoValidado = signal(false);
  confirmacionCertificadoValidado = signal(false);

  // Se valida en el momento de la búsqueda (no al enviar) si cada contrayente ya
  // tiene emitido el certificado de Confirmación, prerrequisito de Matrimonio.
  matrimonioCertificado1 = signal(false);
  matrimonioCertificado2 = signal(false);

  // Una cédula no puede tener dos solicitudes "Atendida" vigentes del mismo sacramento.
  // Se valida al buscar por cédula y bloquea el envío mientras no se levante (rechazo o
  // eliminación de la solicitud aceptada).
  bautizoDuplicado = signal(false);
  // Bautismo es el primer sacramento: aquí no se valida un prerrequisito, sino que la
  // persona a bautizar NO tenga ya el certificado de Bautismo emitido (no se bautiza dos veces).
  bautizoCertificadoExistente = signal(false);
  comunionDuplicado = signal(false);
  confirmacionDuplicado = signal(false);
  matrimonioDuplicado1 = signal(false);
  matrimonioDuplicado2 = signal(false);

  // Un mismo usuario no puede subir dos certificados del mismo tipo.
  certificadoDuplicado = signal(false);

  // Archivos adjuntos (no se ligan a un FormControl porque los navegadores no permiten
  // asignar valores programáticos a un <input type="file">)
  comunionArchivo = nuevoArchivo();
  confirmacionArchivo = nuevoArchivo();
  matrimonioArchivo1 = nuevoArchivo();
  matrimonioArchivo2 = nuevoArchivo();
  certificadoArchivo = nuevoArchivo();

  // Foto del comprobante de pago (solo la ve Tesorero/Sacerdote para validar el monto)
  comunionPropiaComprobante = nuevoArchivo();
  confirmacionPropiaComprobante = nuevoArchivo();
  comunionTercerosComprobante = nuevoArchivo();
  confirmacionTercerosComprobante = nuevoArchivo();

  bautizoForm = this.fb.group({
    cedulaRep: ['', [Validators.required, cedulaEcuatorianaValidator()]],
    nombreRep: ['', [Validators.required, soloTextoValidator()]],
    cedulaRepresentado: ['', [Validators.required, cedulaEcuatorianaValidator()]],
    nombres: ['', [Validators.required, soloTextoValidator(), nombresValidator()]],
    apellidos: ['', [Validators.required, soloTextoValidator(), apellidosValidator()]]
  });

  comunionPropiaForm = this.fb.group({});

  comunionTercerosForm = this.fb.group({
    cedula: ['', [Validators.required, cedulaEcuatorianaValidator()]],
    telefono: ['', [Validators.required, telefonoEcuadorValidator()]],
    nombres: ['', [Validators.required, soloTextoValidator(), nombresValidator()]],
    apellidos: ['', [Validators.required, soloTextoValidator(), apellidosValidator()]]
  });

  confirmacionPropiaForm = this.fb.group({});

  confirmacionTercerosForm = this.fb.group({
    cedula: ['', [Validators.required, cedulaEcuatorianaValidator()]],
    telefono: ['', [Validators.required, telefonoEcuadorValidator()]],
    nombres: ['', [Validators.required, soloTextoValidator(), nombresValidator()]],
    apellidos: ['', [Validators.required, soloTextoValidator(), apellidosValidator()]]
  });

  matrimonioForm = this.fb.group({
    cedula1: ['', [Validators.required, cedulaEcuatorianaValidator()]],
    cedula2: ['', [Validators.required, cedulaEcuatorianaValidator()]],
    nombre1: ['', [Validators.required, soloTextoValidator()]],
    apellidos1: ['', [Validators.required, soloTextoValidator(), apellidosValidator()]],
    nombre2: ['', [Validators.required, soloTextoValidator()]],
    apellidos2: ['', [Validators.required, soloTextoValidator(), apellidosValidator()]],
    telefono1: ['', [telefonoEcuadorValidator()]],
    telefono2: ['', [telefonoEcuadorValidator()]]
  }, { validators: cedulasDistintasValidator('cedula1', 'cedula2') });

  certificadoForm = this.fb.group({
    sacramento: ['', [Validators.required]]
  });

  /** Se dispara al elegir el sacramento: bloquea la subida si ya existe un certificado de ese tipo. */
  async onSacramentoCertificadoChange() {
    const sacramento = this.certificadoForm.controls.sacramento.value ?? '';
    this.certificadoDuplicado.set(false);
    if (!sacramento) return;

    try {
      const existentes = await firstValueFrom(this.certificadosService.listar({ tipo: sacramento }));
      if (existentes.length > 0) {
        this.certificadoDuplicado.set(true);
        this.mensajeError.set(`Ya subiste un certificado de ${sacramento} anteriormente. No puedes subir otro del mismo tipo.`);
      }
    } catch {
      // Ante un error de red no se bloquea la UI; el backend igual lo exige al enviar.
    }
  }

  onFileSelect(event: Event, target: 'comunionArchivo' | 'confirmacionArchivo' | 'certificadoArchivo' | 'matrimonioArchivo1' | 'matrimonioArchivo2' | 'comunionPropiaComprobante' | 'confirmacionPropiaComprobante' | 'comunionTercerosComprobante' | 'confirmacionTercerosComprobante') {
    const input = event.target as HTMLInputElement;
    const file = input.files?.[0];
    if (!file) return;

    const archivo: ArchivoAdjunto = this[target];
    const error = validarArchivo(file, { tipos: ['application/pdf', 'image/png', 'image/jpeg'] });
    if (error) {
      archivo.error.set(error);
      archivo.nombre.set('');
      archivo.dataUrl.set('');
      archivo.mime.set('');
      input.value = '';
      return;
    }

    archivo.error.set('');
    const reader = new FileReader();
    reader.onload = () => {
      archivo.nombre.set(file.name);
      archivo.dataUrl.set(reader.result as string);
      archivo.mime.set(file.type);
    };
    reader.readAsDataURL(file);
  }

  /** Sube (si hay uno seleccionado) el comprobante de pago y devuelve su id_documento. */
  private async subirComprobante(archivo: ArchivoAdjunto, tipo: string): Promise<number | null> {
    if (!archivo.dataUrl()) return null;
    const documento = await firstValueFrom(this.documentosService.crear({
      tipo, archivo_nombre: archivo.nombre(), archivo_url: archivo.dataUrl(), mime_type: archivo.mime()
    }));
    return documento.id_documento;
  }

  open(modal: ModalType) {
    if (!this.authService.isLoggedIn()) {
      this.mensajeError.set('Debes iniciar sesión para enviar una solicitud.');
      return;
    }
    this.mensajeError.set('');
    this.activeModal = modal;
    this.showSuccess = false;
  }

  selectComunion(tipo: 'comunion-propia' | 'comunion-terceros') {
    this.activeModal = tipo;
  }

  selectConfirmacion(tipo: 'confirmacion-propia' | 'confirmacion-terceros') {
    this.activeModal = tipo;
  }

  /** Busca una persona registrada por cédula y autocompleta el/los campo(s) indicados. */
  private async buscarYAutocompletar(
    cedula: string,
    mensaje: ReturnType<typeof signal<string>>,
    enSistema: ReturnType<typeof signal<boolean>>,
    aplicar: (nombres: string, apellidos: string, telefono: string) => void,
    limpiar: () => void
  ): Promise<void> {
    if (!cedula || !/^\d{10}$/.test(cedula)) {
      mensaje.set('Ingresa una cédula válida (10 dígitos) para buscar.');
      return;
    }
    this.buscando.set(true);
    mensaje.set('');
    try {
      const persona = await firstValueFrom(this.personasService.buscarPorCedula(cedula));
      enSistema.set(true);
      aplicar(persona.nombres, persona.apellidos, persona.telefono ?? '');
      mensaje.set('Persona encontrada: datos completados automáticamente.');
    } catch {
      enSistema.set(false);
      // Deja los campos vacíos y editables: no queden datos de una búsqueda anterior.
      limpiar();
      mensaje.set('No se encontró una persona registrada con esa cédula. Puedes continuar ingresando los datos manualmente.');
    } finally {
      this.buscando.set(false);
    }
  }

  /**
   * Verifica si la cédula ya tiene una solicitud "Atendida" vigente de ese sacramento.
   * Se levanta si esa solicitud se rechaza o se elimina. Ante un error de red no bloquea
   * la UI (el backend igual lo exige al enviar); solo da el aviso temprano.
   */
  private async verificarSolicitudDuplicada(cedula: string, sacramento: string): Promise<boolean> {
    if (!cedula || !/^\d{10}$/.test(cedula)) return false;
    try {
      return await firstValueFrom(this.solicitudesService.verificarDuplicada(cedula, sacramento));
    } catch {
      return false;
    }
  }

  buscarRepresentanteBautizo() {
    const cedula = this.bautizoForm.controls.cedulaRep.value?.trim() ?? '';
    this.buscarYAutocompletar(
      cedula, this.bautizoBusqueda, this.bautizoRepresentanteEnSistema,
      (nombres, apellidos) => this.bautizoForm.patchValue({ nombreRep: `${nombres} ${apellidos}` }),
      () => this.bautizoForm.patchValue({ nombreRep: '' })
    );
  }

  /** Se dispara al salir del campo "cédula del bautizado" (no tiene botón de búsqueda propio). */
  async verificarCedulaBautizado() {
    const cedula = this.bautizoForm.controls.cedulaRepresentado.value?.trim() ?? '';
    this.bautizoDuplicado.set(false);
    this.bautizoCertificadoExistente.set(false);

    const duplicado = await this.verificarSolicitudDuplicada(cedula, 'Bautizo');
    this.bautizoDuplicado.set(duplicado);
    if (duplicado) {
      this.mensajeError.set('Ya existe una solicitud de Bautizo aceptada para esta cédula. No se puede enviar otra mientras siga vigente.');
      return;
    }

    if (!cedula || !/^\d{10}$/.test(cedula)) return;
    try {
      const persona = await firstValueFrom(this.personasService.buscarPorCedula(cedula));
      const yaTieneCertificado = await firstValueFrom(
        this.certificadosService.tienePrerrequisitoEmitido(persona.id_persona, 'Bautismo')
      );
      if (yaTieneCertificado) {
        this.bautizoCertificadoExistente.set(true);
        this.mensajeError.set('Esta persona ya tiene el certificado de Bautismo emitido. No se puede volver a solicitar este sacramento para ella.');
      }
    } catch {
      // No está registrada como persona: no puede tener certificado, se permite continuar.
    }
  }

  /**
   * Busca al tercero por cédula. Si está registrado, valida de una vez su certificado
   * prerrequisito: si no lo tiene, se bloquea el envío (no se puede adjuntar un respaldo
   * porque el sistema ya conoce su estado real). Si no está registrado, permite continuar
   * con los datos manuales y adjuntar el certificado como respaldo (opcional).
   */
  private async buscarTerceroConValidacion(
    cedula: string,
    mensaje: ReturnType<typeof signal<string>>,
    enSistema: ReturnType<typeof signal<boolean>>,
    tieneCuenta: ReturnType<typeof signal<boolean>>,
    bloqueado: ReturnType<typeof signal<boolean>>,
    certificadoValidado: ReturnType<typeof signal<boolean>>,
    tipoPrerrequisito: 'Bautismo' | 'Primera Comunion',
    aplicar: (nombres: string, apellidos: string, telefono: string) => void,
    limpiar: () => void
  ): Promise<void> {
    bloqueado.set(false);
    tieneCuenta.set(false);
    certificadoValidado.set(false);
    if (!cedula || !/^\d{10}$/.test(cedula)) {
      mensaje.set('Ingresa una cédula válida (10 dígitos) para buscar.');
      return;
    }
    this.buscando.set(true);
    mensaje.set('');
    try {
      const persona = await firstValueFrom(this.personasService.buscarPorCedula(cedula));
      enSistema.set(true);
      aplicar(persona.nombres, persona.apellidos, persona.telefono ?? '');

      // Una persona registrada puede o no tener cuenta de usuario propia. Si la tiene, el
      // certificado prerrequisito lo debe subir ella misma desde su cuenta ("Subir un
      // certificado"): por eso aquí se bloquea sin opción de adjuntarlo. Si NO tiene cuenta,
      // no tiene otra forma de hacerlo más que este formulario, así que se le permite adjuntar
      // el certificado como respaldo, igual que a una persona no registrada.
      let tieneUsuario = false;
      try {
        await firstValueFrom(this.usuariosService.buscarPorCedula(cedula));
        tieneUsuario = true;
      } catch {
        tieneUsuario = false;
      }
      tieneCuenta.set(tieneUsuario);

      const tienePrerrequisito = await firstValueFrom(
        this.certificadosService.tienePrerrequisitoEmitido(persona.id_persona, tipoPrerrequisito)
      );
      certificadoValidado.set(tienePrerrequisito);
      if (!tienePrerrequisito) {
        if (tieneUsuario) {
          bloqueado.set(true);
          mensaje.set(`Esta persona no cumple con el certificado de ${tipoPrerrequisito} requerido. No se puede enviar la solicitud.`);
        } else {
          mensaje.set(`Esta persona está registrada pero no tiene cuenta propia: adjunta su certificado de ${tipoPrerrequisito} como respaldo.`);
        }
      } else {
        mensaje.set(`Persona encontrada: tiene el certificado de ${tipoPrerrequisito} emitido.`);
      }
    } catch {
      enSistema.set(false);
      tieneCuenta.set(false);
      limpiar();
      mensaje.set('No se encontró una persona registrada con esa cédula. Completa los datos manualmente; puedes adjuntar su certificado como respaldo.');
    } finally {
      this.buscando.set(false);
    }
  }

  async buscarTerceroComunion() {
    const cedula = this.comunionTercerosForm.controls.cedula.value?.trim() ?? '';
    this.comunionDuplicado.set(false);
    await this.buscarTerceroConValidacion(
      cedula, this.comunionBusqueda, this.comunionPersonaEnSistema, this.comunionTieneCuenta, this.comunionBloqueado, this.comunionCertificadoValidado, 'Bautismo',
      (nombres, apellidos, telefono) => this.comunionTercerosForm.patchValue({
        nombres, apellidos, telefono: telefono || this.comunionTercerosForm.controls.telefono.value
      }),
      () => this.comunionTercerosForm.patchValue({ nombres: '', apellidos: '', telefono: '' })
    );
    // Se valida al final para que su mensaje (si aplica) tenga prioridad sobre el anterior.
    const duplicado = await this.verificarSolicitudDuplicada(cedula, 'Primera Comunion');
    this.comunionDuplicado.set(duplicado);
    if (duplicado) this.comunionBusqueda.set('Ya existe una solicitud de Primera Comunión aceptada para esta cédula. No se puede enviar otra mientras siga vigente.');
  }

  async buscarTerceroConfirmacion() {
    const cedula = this.confirmacionTercerosForm.controls.cedula.value?.trim() ?? '';
    this.confirmacionDuplicado.set(false);
    await this.buscarTerceroConValidacion(
      cedula, this.confirmacionBusqueda, this.confirmacionPersonaEnSistema, this.confirmacionTieneCuenta, this.confirmacionBloqueado, this.confirmacionCertificadoValidado, 'Primera Comunion',
      (nombres, apellidos, telefono) => this.confirmacionTercerosForm.patchValue({
        nombres, apellidos, telefono: telefono || this.confirmacionTercerosForm.controls.telefono.value
      }),
      () => this.confirmacionTercerosForm.patchValue({ nombres: '', apellidos: '', telefono: '' })
    );
    const duplicado = await this.verificarSolicitudDuplicada(cedula, 'Confirmacion');
    this.confirmacionDuplicado.set(duplicado);
    if (duplicado) this.confirmacionBusqueda.set('Ya existe una solicitud de Confirmación aceptada para esta cédula. No se puede enviar otra mientras siga vigente.');
  }

  async buscarPrimerContrayente() {
    const cedula = this.matrimonioForm.controls.cedula1.value?.trim() ?? '';
    if (!cedula || !/^\d{10}$/.test(cedula)) {
      this.matrimonioBusqueda1.set('Ingresa una cédula válida (10 dígitos) para buscar.');
      return;
    }
    this.buscando.set(true);
    this.matrimonioBusqueda1.set('');
    this.matrimonioCertificado1.set(false);
    this.matrimonioDuplicado1.set(false);

    try {
      const persona = await firstValueFrom(this.personasService.buscarPorCedula(cedula));
      this.matrimonioPersona1EnSistema.set(true);
      this.matrimonioForm.patchValue({
        nombre1: persona.nombres,
        apellidos1: persona.apellidos,
        telefono1: persona.telefono ?? ''
      });
      // Validar de una vez, en el momento de la búsqueda, si ya tiene el certificado
      // de Confirmación (prerrequisito de Matrimonio), sin esperar a "Enviar solicitud".
      const errorPrerrequisito = await this.validarPrerrequisito(cedula, 'Confirmacion', false);
      this.matrimonioCertificado1.set(!errorPrerrequisito);
      this.matrimonioBusqueda1.set(
        errorPrerrequisito
          ? 'Persona encontrada en el sistema, pero NO tiene el certificado de Confirmación emitido. Deberás adjuntarlo como respaldo.'
          : 'Persona encontrada en el sistema. Tiene el certificado de Confirmación emitido.'
      );
    } catch {
      this.matrimonioPersona1EnSistema.set(false);
      this.matrimonioForm.patchValue({ nombre1: '', apellidos1: '', telefono1: '' });
      this.matrimonioBusqueda1.set('No se encontró en el sistema. Ingresa los datos manualmente y adjunta su certificado de Confirmación.');
    }

    // Se valida al final para que su mensaje (si aplica) tenga prioridad sobre los anteriores.
    const duplicado = await this.verificarSolicitudDuplicada(cedula, 'Matrimonio');
    this.buscando.set(false);
    this.matrimonioDuplicado1.set(duplicado);
    if (duplicado) this.matrimonioBusqueda1.set('Ya existe una solicitud de Matrimonio aceptada para esta cédula. No se puede enviar otra mientras siga vigente.');
  }

  async buscarSegundoContrayente() {
    const cedula = this.matrimonioForm.controls.cedula2.value?.trim() ?? '';
    if (!cedula || !/^\d{10}$/.test(cedula)) {
      this.matrimonioBusqueda2.set('Ingresa una cédula válida (10 dígitos) para buscar.');
      return;
    }
    this.buscando.set(true);
    this.matrimonioBusqueda2.set('');
    this.matrimonioCertificado2.set(false);
    this.matrimonioDuplicado2.set(false);

    try {
      const persona = await firstValueFrom(this.personasService.buscarPorCedula(cedula));
      this.matrimonioPersona2EnSistema.set(true);
      this.matrimonioForm.patchValue({
        nombre2: persona.nombres,
        apellidos2: persona.apellidos,
        telefono2: persona.telefono ?? ''
      });
      const errorPrerrequisito = await this.validarPrerrequisito(cedula, 'Confirmacion', false);
      this.matrimonioCertificado2.set(!errorPrerrequisito);
      this.matrimonioBusqueda2.set(
        errorPrerrequisito
          ? 'Persona encontrada en el sistema, pero NO tiene el certificado de Confirmación emitido. Deberás adjuntarlo como respaldo.'
          : 'Persona encontrada en el sistema. Tiene el certificado de Confirmación emitido.'
      );
    } catch {
      this.matrimonioPersona2EnSistema.set(false);
      this.matrimonioForm.patchValue({ nombre2: '', apellidos2: '', telefono2: '' });
      this.matrimonioBusqueda2.set('No se encontró en el sistema. Ingresa los datos manualmente y adjunta su certificado de Confirmación.');
    }

    const duplicado = await this.verificarSolicitudDuplicada(cedula, 'Matrimonio');
    this.buscando.set(false);
    this.matrimonioDuplicado2.set(duplicado);
    if (duplicado) this.matrimonioBusqueda2.set('Ya existe una solicitud de Matrimonio aceptada para esta cédula. No se puede enviar otra mientras siga vigente.');
  }

  /**
   * Busca la persona por cédula; si no existe en el sistema, la crea (para que el
   * tercero quede como un registro real en la tabla persona, y no solo como texto
   * suelto en beneficiarios_solicitud).
   */
  private async obtenerOCrearPersonaTercero(
    cedula: string, nombres: string, apellidos: string, telefono?: string | null
  ): Promise<number> {
    try {
      const persona = await firstValueFrom(this.personasService.buscarPorCedula(cedula));
      return persona.id_persona;
    } catch {
      const persona = await firstValueFrom(this.personasService.crear({ cedula, nombres, apellidos, telefono: telefono ?? undefined }));
      return persona.id_persona;
    }
  }

  /**
   * Verifica que la persona a inscribir tenga emitido el certificado del sacramento
   * prerrequisito. Se busca por persona (no por cuenta de usuario): un tercero sin
   * cuenta registrada igual puede tener certificados propios (ver obtenerOCrearPersonaTercero).
   * Si la cédula no está registrada como persona en absoluto, no se puede validar
   * automáticamente: en ese caso se exige el certificado adjunto como respaldo.
   */
  private async validarPrerrequisito(
    cedula: string,
    tipoPrerrequisito: 'Bautismo' | 'Primera Comunion' | 'Confirmacion',
    tieneArchivoAdjunto: boolean
  ): Promise<string | null> {
    if (tieneArchivoAdjunto) return null;

    try {
      const persona = await firstValueFrom(this.personasService.buscarPorCedula(cedula));
      const tienePrerrequisito = await firstValueFrom(
        this.certificadosService.tienePrerrequisitoEmitido(persona.id_persona, tipoPrerrequisito)
      );
      if (!tienePrerrequisito) {
        return `La persona debe tener el certificado de ${tipoPrerrequisito} emitido antes de inscribirse a este sacramento.`;
      }
      return null;
    } catch {
      return `No se encontró una persona registrada con esa cédula para validar el certificado de ${tipoPrerrequisito} automáticamente. Adjunta el certificado como respaldo.`;
    }
  }

  async submit() {
    this.mensajeError.set('');
    const idCapilla = this.authService.user()?.id_capilla ?? null;

    try {
      this.guardando.set(true);

      switch (this.activeModal) {
        case 'bautizo': {
          if (this.bautizoForm.invalid) {
            this.bautizoForm.markAllAsTouched();
            throw new Error('Revisa los campos marcados en rojo.');
          }
          const { cedulaRepresentado, nombres, apellidos } = this.bautizoForm.getRawValue();
          if (await this.verificarSolicitudDuplicada(cedulaRepresentado ?? '', 'Bautizo')) {
            this.bautizoDuplicado.set(true);
            throw new Error('Ya existe una solicitud de Bautizo aceptada para esta cédula. No se puede enviar otra mientras siga vigente.');
          }

          // A diferencia de un prerrequisito (que SÍ debe tenerlo), aquí es al revés: se
          // bloquea si la persona YA tiene el certificado de Bautismo (no se bautiza dos veces).
          try {
            const persona = await firstValueFrom(this.personasService.buscarPorCedula(cedulaRepresentado!));
            const yaTieneCertificado = await firstValueFrom(
              this.certificadosService.tienePrerrequisitoEmitido(persona.id_persona, 'Bautismo')
            );
            if (yaTieneCertificado) {
              this.bautizoCertificadoExistente.set(true);
              throw new Error('Esta persona ya tiene el certificado de Bautismo emitido. No se puede volver a solicitar este sacramento para ella.');
            }
          } catch (error: any) {
            if (error?.message?.includes('certificado de Bautismo emitido')) throw error;
            // No encontrada como persona: no puede tener certificado, se permite continuar.
          }

          const idPersonaBautizando = await this.obtenerOCrearPersonaTercero(
            cedulaRepresentado!, nombres!, apellidos!
          );

          const solicitud = await firstValueFrom(this.solicitudesService.crear({
            sacramento: 'Bautizo', modalidad: 'Terceros', id_capilla: idCapilla
          }));
          await firstValueFrom(this.beneficiariosService.crear({
            id_solicitud: solicitud.id_solicitud, rol_beneficiario: 'Bautizando',
            nombres: nombres!, apellidos: apellidos!, cedula: cedulaRepresentado!,
            id_persona: idPersonaBautizando
          }));
          this.bautizoForm.reset();
          this.bautizoBusqueda.set('');
          this.bautizoRepresentanteEnSistema.set(false);
          this.bautizoDuplicado.set(false);
          this.bautizoCertificadoExistente.set(false);
          break;
        }

        case 'comunion-propia': {
          if (!idCapilla) {
            throw new Error('No tienes una capilla asignada.');
          }
          if (!this.comunionPropiaComprobante.dataUrl()) {
            throw new Error('La foto del comprobante es obligatoria.');
          }

          const cedulaUsuario = this.authService.user()!.cedula;
          const errorPrerrequisito = await this.validarPrerrequisito(cedulaUsuario, 'Bautismo', false);
          if (errorPrerrequisito) throw new Error(errorPrerrequisito);

          const idDocumentoComprobante = await this.subirComprobante(this.comunionPropiaComprobante, 'Comprobante - Primera Comunión');
          await firstValueFrom(this.inscripcionesCatequesisService.crear({
            nivel: 'Primera Comunion', id_capilla: idCapilla, monto: 5,
            id_documento: idDocumentoComprobante
          }));
          this.comunionPropiaForm.reset();
          this.comunionPropiaComprobante = nuevoArchivo();
          break;
        }

        case 'comunion-terceros': {
          if (this.comunionTercerosForm.invalid || !idCapilla) {
            this.comunionTercerosForm.markAllAsTouched();
            throw new Error('Revisa los campos marcados en rojo.');
          }
          if (this.comunionBloqueado()) {
            throw new Error('Esta persona no cumple con el certificado de Bautismo requerido. No se puede enviar la solicitud.');
          }
          if (!this.comunionTercerosComprobante.dataUrl()) {
            throw new Error('El comprobante de pago es obligatorio.');
          }
          const datos = this.comunionTercerosForm.getRawValue();

          if (await this.verificarSolicitudDuplicada(datos.cedula!, 'Primera Comunion')) {
            this.comunionDuplicado.set(true);
            throw new Error('Ya existe una solicitud de Primera Comunión aceptada para esta cédula. No se puede enviar otra mientras siga vigente.');
          }

          const idPersonaTercero = await this.obtenerOCrearPersonaTercero(
            datos.cedula!, datos.nombres!, datos.apellidos!, datos.telefono
          );

          // El certificado de respaldo solo aplica cuando la persona no tiene cuenta propia
          // (esté o no registrada como persona): si tiene cuenta, su certificado ya se validó
          // al buscarla. Se guarda como un certificado real (Pendiente de validar por el
          // Sacerdote), no solo un archivo suelto.
          if (!this.comunionCertificadoValidado() && this.comunionArchivo.dataUrl()) {
            await firstValueFrom(this.certificadosService.crear({
              tipo: 'Bautismo', id_persona: idPersonaTercero,
              archivo_nombre: this.comunionArchivo.nombre(),
              archivo_url: this.comunionArchivo.dataUrl(), mime_type: this.comunionArchivo.mime()
            }));
          }

          const idDocumento = await this.subirComprobante(
            this.comunionTercerosComprobante,
            `Comprobante Primera Comunión - Terceros (${datos.nombres} ${datos.apellidos}, cédula ${datos.cedula})`
          );

          const solicitud = await firstValueFrom(this.solicitudesService.crear({
            sacramento: 'Primera Comunion', modalidad: 'Terceros', id_capilla: idCapilla, id_documento: idDocumento
          }));
          await firstValueFrom(this.beneficiariosService.crear({
            id_solicitud: solicitud.id_solicitud, rol_beneficiario: 'Tercero',
            nombres: datos.nombres!, apellidos: datos.apellidos!,
            cedula: datos.cedula!, telefono: datos.telefono!,
            id_persona: idPersonaTercero
          }));

          this.comunionTercerosForm.reset();
          this.comunionArchivo = nuevoArchivo();
          this.comunionTercerosComprobante = nuevoArchivo();
          this.comunionBusqueda.set('');
          this.comunionPersonaEnSistema.set(false);
          this.comunionTieneCuenta.set(false);
          this.comunionCertificadoValidado.set(false);
          this.comunionDuplicado.set(false);
          this.comunionBloqueado.set(false);
          break;
        }

        case 'confirmacion-propia': {
          if (!idCapilla) {
            throw new Error('No tienes una capilla asignada.');
          }
          if (!this.confirmacionPropiaComprobante.dataUrl()) {
            throw new Error('La foto del comprobante es obligatoria.');
          }

          const cedulaUsuario = this.authService.user()!.cedula;
          const errorPrerrequisito = await this.validarPrerrequisito(cedulaUsuario, 'Primera Comunion', false);
          if (errorPrerrequisito) throw new Error(errorPrerrequisito);

          const idDocumentoComprobante = await this.subirComprobante(this.confirmacionPropiaComprobante, 'Comprobante - Confirmación');
          await firstValueFrom(this.inscripcionesCatequesisService.crear({
            nivel: 'Confirmacion', id_capilla: idCapilla, monto: 5,
            id_documento: idDocumentoComprobante
          }));
          this.confirmacionPropiaForm.reset();
          this.confirmacionPropiaComprobante = nuevoArchivo();
          break;
        }

        case 'confirmacion-terceros': {
          if (this.confirmacionTercerosForm.invalid || !idCapilla) {
            this.confirmacionTercerosForm.markAllAsTouched();
            throw new Error('Revisa los campos marcados en rojo.');
          }
          if (this.confirmacionBloqueado()) {
            throw new Error('Esta persona no cumple con el certificado de Primera Comunión requerido. No se puede enviar la solicitud.');
          }
          if (!this.confirmacionTercerosComprobante.dataUrl()) {
            throw new Error('El comprobante de pago es obligatorio.');
          }
          const datos = this.confirmacionTercerosForm.getRawValue();

          if (await this.verificarSolicitudDuplicada(datos.cedula!, 'Confirmacion')) {
            this.confirmacionDuplicado.set(true);
            throw new Error('Ya existe una solicitud de Confirmación aceptada para esta cédula. No se puede enviar otra mientras siga vigente.');
          }

          const idPersonaTercero = await this.obtenerOCrearPersonaTercero(
            datos.cedula!, datos.nombres!, datos.apellidos!, datos.telefono
          );

          if (!this.confirmacionCertificadoValidado() && this.confirmacionArchivo.dataUrl()) {
            await firstValueFrom(this.certificadosService.crear({
              tipo: 'Primera Comunion', id_persona: idPersonaTercero,
              archivo_nombre: this.confirmacionArchivo.nombre(),
              archivo_url: this.confirmacionArchivo.dataUrl(), mime_type: this.confirmacionArchivo.mime()
            }));
          }

          const idDocumento = await this.subirComprobante(
            this.confirmacionTercerosComprobante,
            `Comprobante Confirmación - Terceros (${datos.nombres} ${datos.apellidos}, cédula ${datos.cedula})`
          );

          const solicitud = await firstValueFrom(this.solicitudesService.crear({
            sacramento: 'Confirmacion', modalidad: 'Terceros', id_capilla: idCapilla, id_documento: idDocumento
          }));
          await firstValueFrom(this.beneficiariosService.crear({
            id_solicitud: solicitud.id_solicitud, rol_beneficiario: 'Tercero',
            nombres: datos.nombres!, apellidos: datos.apellidos!,
            cedula: datos.cedula!, telefono: datos.telefono!,
            id_persona: idPersonaTercero
          }));

          this.confirmacionTercerosForm.reset();
          this.confirmacionArchivo = nuevoArchivo();
          this.confirmacionTercerosComprobante = nuevoArchivo();
          this.confirmacionBusqueda.set('');
          this.confirmacionPersonaEnSistema.set(false);
          this.confirmacionTieneCuenta.set(false);
          this.confirmacionCertificadoValidado.set(false);
          this.confirmacionDuplicado.set(false);
          this.confirmacionBloqueado.set(false);
          break;
        }

        case 'matrimonio': {
          if (this.matrimonioForm.invalid) {
            this.matrimonioForm.markAllAsTouched();
            throw new Error('Revisa los campos marcados en rojo.');
          }
          const { cedula1, cedula2, nombre1, apellidos1, nombre2, apellidos2, telefono1, telefono2 } = this.matrimonioForm.getRawValue();

          if (await this.verificarSolicitudDuplicada(cedula1!, 'Matrimonio')) {
            this.matrimonioDuplicado1.set(true);
            throw new Error('Ya existe una solicitud de Matrimonio aceptada para la cédula de la Persona 1. No se puede enviar otra mientras siga vigente.');
          }
          if (await this.verificarSolicitudDuplicada(cedula2!, 'Matrimonio')) {
            this.matrimonioDuplicado2.set(true);
            throw new Error('Ya existe una solicitud de Matrimonio aceptada para la cédula de la Persona 2. No se puede enviar otra mientras siga vigente.');
          }

          // El prerrequisito de Confirmación ya se validó al momento de buscar cada
          // cédula (ver buscarPrimerContrayente/buscarSegundoContrayente); aquí solo
          // se exige el certificado adjunto como respaldo si no quedó verificado.
          const enSistema1 = this.matrimonioPersona1EnSistema();
          const enSistema2 = this.matrimonioPersona2EnSistema();

          if (!this.matrimonioCertificado1() && !this.matrimonioArchivo1.dataUrl()) {
            throw new Error(
              enSistema1
                ? 'Persona 1: no tiene el certificado de Confirmación emitido. Adjúntalo como respaldo.'
                : 'Persona 1 no está registrada. Adjunta su certificado de Confirmación como respaldo.'
            );
          }

          if (!this.matrimonioCertificado2() && !this.matrimonioArchivo2.dataUrl()) {
            throw new Error(
              enSistema2
                ? 'Persona 2: no tiene el certificado de Confirmación emitido. Adjúntalo como respaldo.'
                : 'Persona 2 no está registrada. Adjunta su certificado de Confirmación como respaldo.'
            );
          }

          // Subir certificados adjuntos de externos
          if (this.matrimonioArchivo1.dataUrl()) {
            await firstValueFrom(this.documentosService.crear({
              tipo: `Confirmación - Matrimonio (${nombre1}, cédula ${cedula1})`,
              archivo_nombre: this.matrimonioArchivo1.nombre(),
              archivo_url: this.matrimonioArchivo1.dataUrl(), mime_type: this.matrimonioArchivo1.mime()
            }));
          }
          if (this.matrimonioArchivo2.dataUrl()) {
            await firstValueFrom(this.documentosService.crear({
              tipo: `Confirmación - Matrimonio (${nombre2}, cédula ${cedula2})`,
              archivo_nombre: this.matrimonioArchivo2.nombre(),
              archivo_url: this.matrimonioArchivo2.dataUrl(), mime_type: this.matrimonioArchivo2.mime()
            }));
          }

          // Busca la persona por cédula o, si no está registrada, la crea (para que
          // el cónyuge quede como un registro real y no solo como texto suelto).
          const idPersona1 = await this.obtenerOCrearPersonaTercero(cedula1!, nombre1!, apellidos1!, telefono1);
          const idPersona2 = await this.obtenerOCrearPersonaTercero(cedula2!, nombre2!, apellidos2!, telefono2);

          const solicitud = await firstValueFrom(this.solicitudesService.crear({
            sacramento: 'Matrimonio', id_capilla: idCapilla
          }));
          await firstValueFrom(this.beneficiariosService.crear({
            id_solicitud: solicitud.id_solicitud, rol_beneficiario: 'Conyuge',
            nombres: nombre1!, apellidos: apellidos1!, cedula: cedula1!, telefono: telefono1!, id_persona: idPersona1
          }));
          await firstValueFrom(this.beneficiariosService.crear({
            id_solicitud: solicitud.id_solicitud, rol_beneficiario: 'Conyuge',
            nombres: nombre2!, apellidos: apellidos2!, cedula: cedula2!, telefono: telefono2!, id_persona: idPersona2
          }));

          this.matrimonioForm.reset();
          this.matrimonioBusqueda1.set('');
          this.matrimonioBusqueda2.set('');
          this.matrimonioPersona1EnSistema.set(false);
          this.matrimonioPersona2EnSistema.set(false);
          this.matrimonioCertificado1.set(false);
          this.matrimonioCertificado2.set(false);
          this.matrimonioDuplicado1.set(false);
          this.matrimonioDuplicado2.set(false);
          this.matrimonioArchivo1 = nuevoArchivo();
          this.matrimonioArchivo2 = nuevoArchivo();
          break;
        }

        case 'certificado': {
          if (this.certificadoForm.invalid || !this.certificadoArchivo.dataUrl()) {
            this.certificadoForm.markAllAsTouched();
            throw new Error('Selecciona el sacramento y adjunta el archivo.');
          }
          const sacramento = this.certificadoForm.getRawValue().sacramento ?? '';
          const existentes = await firstValueFrom(this.certificadosService.listar({ tipo: sacramento }));
          if (existentes.length > 0) {
            this.certificadoDuplicado.set(true);
            throw new Error(`Ya subiste un certificado de ${sacramento} anteriormente. No puedes subir otro del mismo tipo.`);
          }
          await firstValueFrom(this.documentosService.crear({
            tipo: `Certificado - ${sacramento}`, archivo_nombre: this.certificadoArchivo.nombre(),
            archivo_url: this.certificadoArchivo.dataUrl(), mime_type: this.certificadoArchivo.mime()
          }));
          await firstValueFrom(this.certificadosService.crear({
            tipo: sacramento, id_capilla: null,
            archivo_nombre: this.certificadoArchivo.nombre(),
            archivo_url: this.certificadoArchivo.dataUrl(),
            mime_type: this.certificadoArchivo.mime()
          }));
          this.certificadoForm.reset();
          this.certificadoArchivo = nuevoArchivo();
          this.certificadoDuplicado.set(false);
          break;
        }
      }

      this.mensajeExitoModal = this.activeModal === 'certificado' ? 'CERTIFICADO\nGUARDADO' : 'SOLICITUD\nENVIADA';
      this.activeModal = null;
      this.showSuccess = true;
    } catch (error: any) {
      this.mensajeError.set(error?.error?.mensaje ?? error?.message ?? 'No se pudo enviar la solicitud.');
    } finally {
      this.guardando.set(false);
    }
  }

  close() {
    this.activeModal = null;
    this.mensajeError.set('');
    this.resetFormularios();
  }

  /** Limpia todos los formularios y su estado de búsqueda al cancelar/cerrar un modal. */
  private resetFormularios() {
    this.bautizoForm.reset();
    this.bautizoBusqueda.set('');
    this.bautizoRepresentanteEnSistema.set(false);
    this.bautizoDuplicado.set(false);
    this.bautizoCertificadoExistente.set(false);

    this.comunionPropiaForm.reset();
    this.comunionPropiaComprobante = nuevoArchivo();

    this.comunionTercerosForm.reset();
    this.comunionArchivo = nuevoArchivo();
    this.comunionTercerosComprobante = nuevoArchivo();
    this.comunionBusqueda.set('');
    this.comunionPersonaEnSistema.set(false);
    this.comunionTieneCuenta.set(false);
    this.comunionCertificadoValidado.set(false);
    this.comunionDuplicado.set(false);
    this.comunionBloqueado.set(false);

    this.confirmacionPropiaForm.reset();
    this.confirmacionPropiaComprobante = nuevoArchivo();

    this.confirmacionTercerosForm.reset();
    this.confirmacionArchivo = nuevoArchivo();
    this.confirmacionTercerosComprobante = nuevoArchivo();
    this.confirmacionBusqueda.set('');
    this.confirmacionPersonaEnSistema.set(false);
    this.confirmacionTieneCuenta.set(false);
    this.confirmacionCertificadoValidado.set(false);
    this.confirmacionDuplicado.set(false);
    this.confirmacionBloqueado.set(false);

    this.matrimonioForm.reset();
    this.matrimonioBusqueda1.set('');
    this.matrimonioBusqueda2.set('');
    this.matrimonioPersona1EnSistema.set(false);
    this.matrimonioPersona2EnSistema.set(false);
    this.matrimonioCertificado1.set(false);
    this.matrimonioCertificado2.set(false);
    this.matrimonioDuplicado1.set(false);
    this.matrimonioDuplicado2.set(false);
    this.matrimonioArchivo1 = nuevoArchivo();
    this.matrimonioArchivo2 = nuevoArchivo();

    this.certificadoForm.reset();
    this.certificadoArchivo = nuevoArchivo();
    this.certificadoDuplicado.set(false);
  }

  closeOnOverlay(event: MouseEvent) {
    if (event.target === event.currentTarget) this.close();
  }
}
