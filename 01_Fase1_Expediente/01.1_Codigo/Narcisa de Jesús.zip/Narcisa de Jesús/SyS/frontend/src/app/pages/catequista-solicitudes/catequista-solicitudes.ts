import { Component, inject, OnInit, signal } from '@angular/core';
import { SlicePipe } from '@angular/common';
import { firstValueFrom } from 'rxjs';
import { FormAlertComponent } from '../../components/form-alert/form-alert';
import { AuthService } from '../../services/auth.service';
import { InscripcionesCatequesisService } from '../../services/inscripciones-catequesis.service';
import { InscritosCatequesisService } from '../../services/inscritos-catequesis.service';
import { SolicitudesSacramentoService } from '../../services/solicitudes-sacramento.service';
import { BeneficiariosSolicitudService } from '../../services/beneficiarios-solicitud.service';
import { CertificadosService } from '../../services/certificados.service';
import { DocumentosService, abrirDocumentoEnNuevaPestana, abrirPestanaEnBlanco } from '../../services/documentos.service';
import { InscripcionCatequesis } from '../../models/inscripcion-catequesis.model';
import { SolicitudSacramento } from '../../models/solicitud-sacramento.model';
import { mensajesTemporales } from '../../shared/utils/mensajes-temporales';
import { autoRecarga } from '../../shared/utils/auto-recarga';

type EstadoCertificadoTercero = 'Emitido' | 'Pendiente' | 'Rechazado' | 'No subido';
type SeccionSolicitudes = 'propias' | 'terceros';

interface SolicitudTerceroConBeneficiario extends SolicitudSacramento {
  beneficiario_nombres?: string;
  beneficiario_apellidos?: string;
  beneficiario_cedula?: string;
  beneficiario_id_persona?: number | null;
  certificadoEstado: EstadoCertificadoTercero;
}

/** Certificado del que depende cada sacramento de catequesis, para saber cuál validar. */
const PRERREQUISITO_POR_SACRAMENTO: Record<string, string> = {
  'Primera Comunion': 'Bautismo',
  'Confirmacion': 'Primera Comunion'
};

@Component({
  selector: 'app-catequista-solicitudes',
  standalone: true,
  imports: [SlicePipe, FormAlertComponent],
  templateUrl: './catequista-solicitudes.html',
  styleUrl: './catequista-solicitudes.css'
})
export class CatequistaSolicitudesComponent implements OnInit {
  private authService = inject(AuthService);
  private inscripcionesService = inject(InscripcionesCatequesisService);
  private inscritosService = inject(InscritosCatequesisService);
  private solicitudesSacramentoService = inject(SolicitudesSacramentoService);
  private beneficiariosService = inject(BeneficiariosSolicitudService);
  private certificadosService = inject(CertificadosService);
  private documentosService = inject(DocumentosService);

  get catequista() { return (this.authService.user()?.nombres ?? '') + ' ' + (this.authService.user()?.apellidos ?? ''); }
  get capilla() { return this.authService.user()?.capilla ?? ''; }

  // Sección visible: igual que en Catequesis del Sacerdote, pestañas pequeñas con una
  // sección predeterminada visible al entrar, en vez de mostrar ambas tablas a la vez.
  seccionActiva = signal<SeccionSolicitudes>('propias');

  solicitudes = signal<InscripcionCatequesis[]>([]);
  solicitudesTerceros = signal<SolicitudTerceroConBeneficiario[]>([]);
  mensajeError = mensajesTemporales(signal(''));
  mensajeExito = mensajesTemporales(signal(''));
  procesando = signal<number | null>(null);
  procesandoTercero = signal<number | null>(null);

  private refrescar() {
    this.cargar(false);
    this.cargarTerceros(false);
  }

  constructor() {
    autoRecarga(() => this.refrescar());
  }

  ngOnInit() {
    this.cargar();
    this.cargarTerceros();
  }

  private cargar(mostrarError = true) {
    this.inscripcionesService.listar().subscribe({
      next: (data) => this.solicitudes.set(data),
      error: (error) => { if (mostrarError) this.mensajeError.set(error?.error?.mensaje ?? 'No se pudieron cargar las solicitudes.'); }
    });
  }

  /**
   * Solicitudes de Primera Comunión/Confirmación registradas para un tercero (el backend
   * ya filtra por estos dos sacramentos y por la capilla del catequista). Se completa el
   * nombre del beneficiario real (no del Laico que las envió) consultando cada solicitud.
   */
  private async cargarTerceros(mostrarError = true) {
    try {
      const solicitudes = await firstValueFrom(this.solicitudesSacramentoService.listar());
      const conBeneficiario = await Promise.all(
        solicitudes.map(async(s) => {
          const beneficiarios = await firstValueFrom(this.beneficiariosService.listarPorSolicitud(s.id_solicitud)).catch(() => []);
          const beneficiario = beneficiarios[0];
          const certificadoEstado = await this.obtenerEstadoCertificado(s.sacramento, beneficiario?.id_persona);
          return {
            ...s,
            beneficiario_nombres: beneficiario?.nombres,
            beneficiario_apellidos: beneficiario?.apellidos,
            beneficiario_cedula: beneficiario?.cedula,
            beneficiario_id_persona: beneficiario?.id_persona,
            certificadoEstado
          };
        })
      );
      this.solicitudesTerceros.set(conBeneficiario);
    } catch (error: any) {
      if (mostrarError) this.mensajeError.set(error?.error?.mensaje ?? 'No se pudieron cargar las solicitudes de terceros.');
    }
  }

  /**
   * El Catequista solo puede validar el comprobante de pago; el certificado prerrequisito
   * lo valida el Sacerdote por separado (en otro momento, de forma asíncrona). Por eso acá
   * se consulta su estado real en vez de asumir que "ya se revisó" al momento de enviar
   * la solicitud: solo "Emitido" habilita el botón Aprobar.
   */
  private async obtenerEstadoCertificado(sacramento: string, idPersona?: number | null): Promise<EstadoCertificadoTercero> {
    const tipoPrerrequisito = PRERREQUISITO_POR_SACRAMENTO[sacramento];
    if (!idPersona || !tipoPrerrequisito) return 'No subido';

    const certificados = await firstValueFrom(
      this.certificadosService.listar({ id_persona: idPersona, tipo: tipoPrerrequisito })
    ).catch(() => []);

    if (certificados.some(c => c.estado === 'Emitido')) return 'Emitido';
    if (certificados.some(c => c.estado === 'Pendiente')) return 'Pendiente';
    if (certificados.some(c => c.estado === 'Rechazado')) return 'Rechazado';
    return 'No subido';
  }

  beneficiarioNombre(s: SolicitudTerceroConBeneficiario): string {
    return `${s.beneficiario_nombres ?? ''} ${s.beneficiario_apellidos ?? ''}`.trim() || '—';
  }

  /**
   * Aprueba la solicitud y de una vez genera el inscrito en "Mi Catequesis" (con los
   * datos del beneficiario ya validados al momento de la solicitud: cédula, prerrequisito
   * y comprobante de pago), sin exigirle cuenta de usuario al tercero.
   */
  puedeAprobarTercero(s: SolicitudTerceroConBeneficiario): boolean {
    return s.certificadoEstado === 'Emitido';
  }

  async aprobarTercero(s: SolicitudTerceroConBeneficiario) {
    if (!this.puedeAprobarTercero(s)) {
      this.mensajeError.set('No se puede aprobar: el certificado prerrequisito todavía no ha sido validado por el Sacerdote.');
      return;
    }
    this.mensajeError.set('');
    this.mensajeExito.set('');
    this.procesandoTercero.set(s.id_solicitud);
    try {
      await firstValueFrom(this.solicitudesSacramentoService.aprobar(s.id_solicitud));

      const u = this.authService.user();
      await firstValueFrom(this.inscritosService.crear({
        cedula: s.beneficiario_cedula!,
        nombres: this.beneficiarioNombre(s),
        nivel: s.sacramento as InscripcionCatequesis['nivel'],
        id_capilla: s.id_capilla!,
        id_catequista: u?.id_usuario,
        fecha_inscripcion: new Date().toISOString().slice(0, 10),
        monto: 5
      }));

      this.procesandoTercero.set(null);
      this.mensajeExito.set('Solicitud aprobada: el inscrito ya está disponible en Mi Catequesis.');
      this.cargarTerceros();
    } catch (error: any) {
      this.procesandoTercero.set(null);
      this.mensajeError.set(error?.error?.mensaje ?? 'No se pudo aprobar la solicitud.');
    }
  }

  verComprobanteTercero(s: SolicitudTerceroConBeneficiario) {
    if (!s.id_documento) return;
    const ventana = abrirPestanaEnBlanco();
    this.documentosService.obtenerPorId(s.id_documento).subscribe({
      next: (doc) => abrirDocumentoEnNuevaPestana(doc, ventana),
      error: () => {
        ventana?.close();
        this.mensajeError.set('No se pudo cargar el comprobante.');
      }
    });
  }

  rechazarTercero(s: SolicitudTerceroConBeneficiario) {
    if (!confirm(`¿Rechazar la solicitud de ${s.sacramento} de ${this.beneficiarioNombre(s)}?`)) return;
    this.mensajeError.set('');
    this.mensajeExito.set('');
    this.procesandoTercero.set(s.id_solicitud);
    this.solicitudesSacramentoService.rechazar(s.id_solicitud).subscribe({
      next: () => {
        this.procesandoTercero.set(null);
        this.mensajeExito.set('Solicitud rechazada correctamente.');
        this.cargarTerceros();
      },
      error: (error) => {
        this.procesandoTercero.set(null);
        this.mensajeError.set(error?.error?.mensaje ?? 'No se pudo rechazar la solicitud.');
      }
    });
  }

  aprobar(s: InscripcionCatequesis) {
    this.mensajeError.set('');
    this.mensajeExito.set('');
    this.procesando.set(s.id_inscripcion);
    this.inscripcionesService.aprobar(s.id_inscripcion).subscribe({
      next: () => {
        this.procesando.set(null);
        this.mensajeExito.set('Solicitud aprobada correctamente.');
        this.cargar();
      },
      error: (error) => {
        this.procesando.set(null);
        this.mensajeError.set(error?.error?.error ?? error?.error?.mensaje ?? 'No se pudo aprobar la solicitud.');
      }
    });
  }

  verComprobante(s: InscripcionCatequesis) {
    if (!s.id_documento) return;
    const ventana = abrirPestanaEnBlanco();
    this.documentosService.obtenerPorId(s.id_documento).subscribe({
      next: (doc) => abrirDocumentoEnNuevaPestana(doc, ventana),
      error: () => {
        ventana?.close();
        this.mensajeError.set('No se pudo cargar el comprobante.');
      }
    });
  }

  rechazar(s: InscripcionCatequesis) {
    this.mensajeError.set('');
    this.mensajeExito.set('');
    this.procesando.set(s.id_inscripcion);
    this.inscripcionesService.rechazar(s.id_inscripcion).subscribe({
      next: () => {
        this.procesando.set(null);
        this.mensajeExito.set('Solicitud rechazada correctamente.');
        this.cargar();
      },
      error: (error) => {
        this.procesando.set(null);
        this.mensajeError.set(error?.error?.error ?? error?.error?.mensaje ?? 'No se pudo rechazar la solicitud.');
      }
    });
  }
}
