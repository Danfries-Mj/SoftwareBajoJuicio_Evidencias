import { Component, inject, OnInit, signal } from '@angular/core';
import { AuthService } from '../../services/auth.service';
import { EucaristiasService } from '../../services/eucaristias.service';
import { EventosService } from '../../services/eventos.service';
import { CapillasService } from '../../services/capillas.service';
import { Evento } from '../../models/evento.model';
import { mensajesTemporales } from '../../shared/utils/mensajes-temporales';
import { CATEGORIA_COLOR, claseBadgeCategoria, claseDotCategoria } from '../../shared/constants/categoria-colors';

interface MasaCapilla {
  nombre: string;
  horarios: { fecha: string; hora: string }[];
}

@Component({
  selector: 'app-home',
  standalone: true,
  imports: [],
  templateUrl: './home.html',
  styleUrl: './home.css'
})
export class HomeComponent implements OnInit {
  protected authService = inject(AuthService);
  private eucaristiasService = inject(EucaristiasService);
  private eventosService = inject(EventosService);
  private capillasService = inject(CapillasService);
  protected claseBadgeCategoria = claseBadgeCategoria;
  protected claseDotCategoria = claseDotCategoria;
  protected categoriasLeyenda = Object.keys(CATEGORIA_COLOR);

  masas = signal<MasaCapilla[]>([]);
  mensajeError = mensajesTemporales(signal(''));

  private eventos = signal<Evento[]>([]);
  private today = new Date();
  private displayYear = this.today.getFullYear();
  private displayMonth = this.today.getMonth();

  calendarWeeks = signal<(number | null)[][]>([]);
  monthLabel = signal('');

  ngOnInit() {
    this.cargarHorarios();
    this.cargarEventos();
    this.recalcularCalendario();
  }

  private cargarHorarios() {
    this.capillasService.listar().subscribe({
      next: (capillas) => {
        this.eucaristiasService.listar({ estado: 'Activa' }).subscribe({
          next: (eucaristias) => {
            const masas = capillas
              .map((c): MasaCapilla => ({
                nombre: c.nombre,
                horarios: eucaristias
                  .filter(e => e.id_capilla === c.id_capilla)
                  .sort((a, b) => {
                    const diferenciaFecha = new Date(a.fecha).getTime() - new Date(b.fecha).getTime();
                    return diferenciaFecha !== 0 ? diferenciaFecha : a.hora_inicio.localeCompare(b.hora_inicio);
                  })
                  .map(e => ({ fecha: this.formatearFechaMisa(e.fecha), hora: this.formatearHora(e.hora_inicio) }))
              }))
              .filter(m => m.horarios.length > 0);
            this.masas.set(masas);
          },
          error: () => this.mensajeError.set('No se pudieron cargar los horarios de misa.')
        });
      }
    });
  }

  private formatearHora(hora: string): string {
    const [h, m] = hora.split(':').map(Number);
    const periodo = h >= 12 ? 'P.M.' : 'A.M.';
    const h12 = h % 12 === 0 ? 12 : h % 12;
    return `${h12.toString().padStart(2, '0')}:${m.toString().padStart(2, '0')} ${periodo}`;
  }

  // La fecha de la eucaristía es un DATE de Postgres, que llega como medianoche
  // UTC; se formatea con timeZone 'UTC' para no correr el día hacia atrás en
  // zonas horarias negativas (p. ej. Ecuador, GMT-5).
  private formatearFechaMisa(fecha: string): string {
    const partes = new Intl.DateTimeFormat('es-EC', {
      weekday: 'long', day: 'numeric', month: 'long', timeZone: 'UTC'
    }).formatToParts(new Date(fecha));

    const obtener = (tipo: string) => partes.find(p => p.type === tipo)?.value ?? '';
    const capitalizar = (s: string) => s.charAt(0).toUpperCase() + s.slice(1);

    return `${capitalizar(obtener('weekday'))} - ${obtener('day')} ${capitalizar(obtener('month'))}`;
  }

  private cargarEventos() {
    this.eventosService.listar().subscribe({
      next: (eventos) => {
        this.eventos.set(eventos);
        this.recalcularCalendario();
      }
    });
  }

  private recalcularCalendario() {
    this.calendarWeeks.set(this.construirCalendario(this.displayYear, this.displayMonth));
    const fecha = new Date(this.displayYear, this.displayMonth, 1);
    this.monthLabel.set(fecha.toLocaleDateString('es-ES', { month: 'long', year: 'numeric' }));
  }

  private construirCalendario(year: number, month: number): (number | null)[][] {
    const primerDia = new Date(year, month, 1);
    const offsetInicio = (primerDia.getDay() + 6) % 7;
    const diasDelMes = new Date(year, month + 1, 0).getDate();

    const semanas: (number | null)[][] = [];
    let semana: (number | null)[] = new Array(offsetInicio).fill(null);

    for (let dia = 1; dia <= diasDelMes; dia++) {
      semana.push(dia);
      if (semana.length === 7) {
        semanas.push(semana);
        semana = [];
      }
    }
    if (semana.length) {
      while (semana.length < 7) semana.push(null);
      semanas.push(semana);
    }
    return semanas;
  }

  mesAnterior() {
    this.displayMonth--;
    if (this.displayMonth < 0) { this.displayMonth = 11; this.displayYear--; }
    this.recalcularCalendario();
  }

  mesSiguiente() {
    this.displayMonth++;
    if (this.displayMonth > 11) { this.displayMonth = 0; this.displayYear++; }
    this.recalcularCalendario();
  }

  isToday(day: number | null): boolean {
    if (!day) return false;
    return this.displayYear === this.today.getFullYear()
      && this.displayMonth === this.today.getMonth()
      && day === this.today.getDate();
  }

  categoriasDelDia(day: number | null): string[] {
    if (!day) return [];
    const fechaStr = `${this.displayYear}-${(this.displayMonth + 1).toString().padStart(2, '0')}-${day.toString().padStart(2, '0')}`;
    const categorias = this.eventos()
      .filter(e => e.fecha?.slice(0, 10) === fechaStr)
      .map(e => e.categoria);
    return Array.from(new Set(categorias));
  }

  hasEvent(day: number | null): boolean {
    return this.categoriasDelDia(day).length > 0;
  }

  /** Pinta la celda del día con el color de su categoría (la primera, si hay varias ese día). El día de hoy no se pinta: ya tiene su propio resalte. */
  claseCeldaDia(day: number | null): string {
    if (this.isToday(day)) return '';
    const categorias = this.categoriasDelDia(day);
    return categorias.length > 0 ? this.claseBadgeCategoria(categorias[0]) : '';
  }
}
