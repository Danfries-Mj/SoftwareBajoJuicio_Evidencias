import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, map } from 'rxjs';
import { API_URL } from '../core/config/api.config';
import { Capilla } from '../models/capilla.model';

@Injectable({ providedIn: 'root' })
export class CapillasService {
  private apiUrl = `${API_URL}/capillas`;

  constructor(private http: HttpClient) {}

  listar(): Observable<Capilla[]> {
    return this.http.get<{ mensaje: string; total: number; capillas: Capilla[] }>(this.apiUrl)
      .pipe(map(respuesta => respuesta.capillas));
  }

  obtenerPorId(id: number): Observable<Capilla> {
    return this.http.get<{ mensaje: string; capilla: Capilla }>(`${this.apiUrl}/${id}`)
      .pipe(map(respuesta => respuesta.capilla));
  }
}
