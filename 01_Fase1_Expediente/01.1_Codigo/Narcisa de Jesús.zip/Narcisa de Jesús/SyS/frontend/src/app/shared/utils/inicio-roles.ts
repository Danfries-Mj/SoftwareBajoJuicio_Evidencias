export const RUTA_POR_ROL: Record<string, string> = {
  Sacerdote: '/sacerdote/dashboard',
  Coordinador: '/coordinador/inicio',
  Tesorero: '/tesorero/fondos',
  Catequista: '/catequista/inicio'
};
