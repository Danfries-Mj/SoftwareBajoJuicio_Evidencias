export interface Persona {
  id_persona: number;
  cedula: string;
  nombres: string;
  apellidos: string;
  telefono?: string;
}
