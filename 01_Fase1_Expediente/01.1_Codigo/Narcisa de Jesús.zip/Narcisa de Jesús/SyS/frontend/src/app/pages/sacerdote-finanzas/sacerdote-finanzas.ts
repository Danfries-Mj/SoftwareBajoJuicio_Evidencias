import { Component, inject, OnInit, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { FondosService } from '../../services/fondos.service';
import { MovimientosFinancierosService } from '../../services/movimientos-financieros.service';
import { Fondo } from '../../models/fondo.model';
import { MovimientoFinanciero } from '../../models/movimiento-financiero.model';
import { mensajesTemporales } from '../../shared/utils/mensajes-temporales';
import { autoRecarga } from '../../shared/utils/auto-recarga';
import { formatearFecha } from '../../shared/utils/date-format';
import { categoriasPorTipo, justificacionesPorTipo } from '../../shared/constants/movimiento-financiero-options';
const COLORES = ['blue', 'green', 'purple', 'orange', 'red', 'teal'];

@Component({
  selector: 'app-sacerdote-finanzas',
  standalone: true,
  imports: [FormsModule],
  templateUrl: './sacerdote-finanzas.html',
  styleUrl: './sacerdote-finanzas.css'
})
export class SacerdoteFinanzasComponent implements OnInit {
  private fondosService = inject(FondosService);
  private movimientosService = inject(MovimientosFinancierosService);
  protected formatearFecha = formatearFecha;

  showModal = false;
  editando: MovimientoFinanciero | null = null;
  guardando = signal(false);
  mensajeError = mensajesTemporales(signal(''));
  mensajeExito = mensajesTemporales(signal(''));

  fondos = signal<Fondo[]>([]);
  movimientos = signal<MovimientoFinanciero[]>([]);

  tiposMov = ['Ingreso', 'Egreso'];

  busquedaMov = '';
  filtroTipo: '' | 'Ingreso' | 'Egreso' = '';
  filtroFondo: number | '' = '';

  nuevo: { tipo: string; id_fondo: number | ''; categoria: string; descripcion: string; monto: number | null; fecha: string; justificacion: string } = {
    tipo: 'Ingreso', id_fondo: '', categoria: '', descripcion: '', monto: null, fecha: '', justificacion: ''
  };

  constructor() {
    autoRecarga(() => this.refrescar());
  }

  ngOnInit() {
    this.cargarFondos();
    this.cargarMovimientos();
  }

  private cargarFondos(mostrarError = true) {
    this.fondosService.listar().subscribe({
      next: (fondos) => this.fondos.set(fondos),
      error: () => { if (mostrarError) this.mensajeError.set('No se pudieron cargar los fondos.'); }
    });
  }

  private cargarMovimientos(mostrarError = true) {
    this.movimientosService.listar().subscribe({
      next: (movimientos) => this.movimientos.set(movimientos),
      error: () => { if (mostrarError) this.mensajeError.set('No se pudieron cargar los movimientos.'); }
    });
  }

  private refrescar() {
    this.cargarFondos(false);
    this.cargarMovimientos(false);
  }

  colorFondo(index: number): string {
    return COLORES[index % COLORES.length];
  }

  get categorias(): string[] {
    return categoriasPorTipo(this.nuevo.tipo);
  }

  get justificaciones(): string[] {
    return justificacionesPorTipo(this.nuevo.tipo);
  }

  onTipoChange() {
    if (this.nuevo.categoria && !this.categorias.includes(this.nuevo.categoria)) {
      this.nuevo.categoria = '';
    }
    if (this.nuevo.justificacion && !this.justificaciones.includes(this.nuevo.justificacion)) {
      this.nuevo.justificacion = '';
    }
  }

  get totalBalance(): number {
    return this.fondos().reduce((s, f) => s + Number(f.saldo_actual), 0);
  }

  get movimientosFiltrados(): MovimientoFinanciero[] {
    const texto = this.busquedaMov.toLowerCase();
    return this.movimientos().filter(m => {
      const coincideTexto = !texto || (m.descripcion ?? '').toLowerCase().includes(texto);
      const coincideTipo = !this.filtroTipo || m.tipo === this.filtroTipo;
      const coincideFondo = !this.filtroFondo || m.id_fondo === this.filtroFondo;
      return coincideTexto && coincideTipo && coincideFondo;
    });
  }

  fondoNombre(m: MovimientoFinanciero): string {
    return m.fondo_nombre ?? this.fondos().find(f => f.id_fondo === m.id_fondo)?.nombre ?? '—';
  }

  formatMonto(valor: number): string {
    return `$${Number(valor).toLocaleString('es-EC', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
  }

  openModal() {
    this.editando = null;
    this.nuevo = { tipo: 'Ingreso', id_fondo: '', categoria: '', descripcion: '', monto: null, fecha: '', justificacion: '' };
    this.mensajeError.set('');
    this.showModal = true;
  }

  editar(m: MovimientoFinanciero) {
    this.editando = m;
    this.nuevo = {
      tipo: m.tipo,
      id_fondo: m.id_fondo,
      categoria: m.categoria ?? '',
      descripcion: m.descripcion ?? '',
      monto: m.monto,
      fecha: m.fecha?.slice(0, 10) ?? '',
      justificacion: m.justificacion ?? ''
    };
    this.mensajeError.set('');
    this.showModal = true;
  }

  guardar() {
    this.mensajeError.set('');

    if (!this.nuevo.descripcion.trim() || !this.nuevo.id_fondo || !this.nuevo.tipo || !this.nuevo.monto || !this.nuevo.fecha) {
      this.mensajeError.set('Fondo, tipo, descripción, monto y fecha son obligatorios.');
      return;
    }
    if (this.nuevo.monto <= 0) {
      this.mensajeError.set('Ingresa un monto válido mayor a cero.');
      return;
    }

    const datos = {
      tipo: this.nuevo.tipo as 'Ingreso' | 'Egreso',
      categoria: this.nuevo.categoria || undefined,
      descripcion: this.nuevo.descripcion,
      id_fondo: Number(this.nuevo.id_fondo),
      monto: this.nuevo.monto,
      fecha: this.nuevo.fecha,
      justificacion: this.nuevo.justificacion || undefined
    };

    const esEdicion = !!this.editando;
    this.guardando.set(true);
    const peticion = this.editando
      ? this.movimientosService.editar(this.editando.id_movimiento, datos)
      : this.movimientosService.crear(datos);

    peticion.subscribe({
      next: () => {
        this.guardando.set(false);
        this.showModal = false;
        this.editando = null;
        this.mensajeExito.set(esEdicion ? 'Movimiento actualizado correctamente.' : 'Movimiento registrado correctamente.');
        this.cargarMovimientos();
        this.cargarFondos();
      },
      error: (error) => {
        this.guardando.set(false);
        this.mensajeError.set(error?.error?.mensaje ?? 'No se pudo guardar el movimiento.');
      }
    });
  }

  closeOnOverlay(e: MouseEvent) {
    if (e.target === e.currentTarget) this.showModal = false;
  }
}
