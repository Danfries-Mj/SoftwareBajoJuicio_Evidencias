export interface Fondo {
  id_fondo: number;
  nombre: string;
  descripcion?: string;
  saldo_actual: number;
  id_capilla?: number | null;
  capilla_nombre?: string;
}
