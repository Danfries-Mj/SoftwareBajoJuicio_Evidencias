import { Component, OnInit, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { AuthService } from '../../services/auth.service';
import { UsuariosService } from '../../services/usuarios.service';
import { NotificacionesService } from '../../services/notificaciones.service';
import { Usuario } from '../../models/usuario.model';
import { mensajesTemporales } from '../../shared/utils/mensajes-temporales';
import { autoRecarga } from '../../shared/utils/auto-recarga';

@Component({
  selector: 'app-coordinador-directorio',
  standalone: true,
  imports: [FormsModule],
  templateUrl: './coordinador-directorio.html',
  styleUrl: './coordinador-directorio.css'
})
export class CoordinadorDirectorioComponent implements OnInit {
  private authService = inject(AuthService);
  private usuariosService = inject(UsuariosService);
  private notificacionesService = inject(NotificacionesService);

  get capilla() { return this.authService.user()?.capilla ?? ''; }

  busqueda = '';
  cargando = signal(true);
  mensajeError = mensajesTemporales(signal(''));
  miembros = signal<Usuario[]>([]);

  showNotificar = false;
  notificarTarget: Usuario | null = null;
  formNotificar = { titulo: '', mensaje: '' };
  enviandoNotificacion = signal(false);
  errorNotificar = mensajesTemporales(signal(''));
  mensajeExito = mensajesTemporales(signal(''));

  constructor() {
    autoRecarga(() => this.refrescar());
  }

  ngOnInit() {
    this.cargar();
  }

  private cargar(mostrarError = true) {
    const idCapilla = this.authService.user()?.id_capilla ?? undefined;
    this.usuariosService.listar({ id_capilla: idCapilla }).subscribe({
      next: (data) => {
        this.miembros.set(data);
        this.cargando.set(false);
      },
      error: (error) => {
        this.cargando.set(false);
        if (mostrarError) this.mensajeError.set(
          error?.error?.mensaje ?? 'No tienes permiso para ver el directorio de usuarios (esta consulta está restringida al rol Sacerdote).'
        );
      }
    });
  }

  private refrescar() {
    this.cargar(false);
  }

  get filtrados() {
    if (!this.busqueda) return this.miembros();
    const q = this.busqueda.toLowerCase();
    return this.miembros().filter(m =>
      `${m.nombres} ${m.apellidos}`.toLowerCase().includes(q) ||
      m.cedula.includes(q) ||
      m.rol.toLowerCase().includes(q)
    );
  }

  /** Sin target: notifica a todos los miembros de la capilla. Con target: solo a esa persona. */
  abrirNotificar(target: Usuario | null = null) {
    this.notificarTarget = target;
    this.formNotificar = { titulo: '', mensaje: '' };
    this.errorNotificar.set('');
    this.showNotificar = true;
  }

  cerrarNotificar() {
    this.showNotificar = false;
    this.notificarTarget = null;
  }

  enviarNotificacion() {
    this.errorNotificar.set('');
    if (!this.formNotificar.titulo.trim() || !this.formNotificar.mensaje.trim()) {
      this.errorNotificar.set('El título y el mensaje son obligatorios.');
      return;
    }

    this.enviandoNotificacion.set(true);
    this.notificacionesService.enviarAMiembros({
      id_usuario: this.notificarTarget?.id_usuario ?? null,
      titulo: this.formNotificar.titulo.trim(),
      mensaje: this.formNotificar.mensaje.trim()
    }).subscribe({
      next: () => {
        this.enviandoNotificacion.set(false);
        this.mensajeExito.set(
          this.notificarTarget
            ? `Notificación enviada a ${this.notificarTarget.nombres} ${this.notificarTarget.apellidos}.`
            : 'Notificación enviada a todos los miembros de la capilla.'
        );
        this.cerrarNotificar();
      },
      error: (error) => {
        this.enviandoNotificacion.set(false);
        this.errorNotificar.set(error?.error?.mensaje ?? 'No se pudo enviar la notificación.');
      }
    });
  }

  closeOnOverlay(e: MouseEvent) {
    if (e.target === e.currentTarget) this.cerrarNotificar();
  }
}
