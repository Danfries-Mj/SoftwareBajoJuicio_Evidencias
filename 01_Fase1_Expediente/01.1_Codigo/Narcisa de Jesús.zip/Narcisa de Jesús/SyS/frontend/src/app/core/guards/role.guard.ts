import { inject } from '@angular/core';
import { CanActivateFn, Router } from '@angular/router';
import { AuthService } from '../../services/auth.service';
import { ModalService } from '../../services/modal.service';
import { RUTA_POR_ROL } from '../../shared/utils/inicio-roles';

export const requireRoles = (...roles: string[]): CanActivateFn => {
  return () => {
    const authService = inject(AuthService);
    const router = inject(Router);
    const modalService = inject(ModalService);

    const usuario = authService.user();

    if (!authService.isLoggedIn() || !usuario) {
      modalService.openLogin();
      return router.createUrlTree(['/']);
    }

    if (roles.includes(usuario.rol)) {
      return true;
    }

    return router.createUrlTree([RUTA_POR_ROL[usuario.rol] ?? '/']);
  };
};
