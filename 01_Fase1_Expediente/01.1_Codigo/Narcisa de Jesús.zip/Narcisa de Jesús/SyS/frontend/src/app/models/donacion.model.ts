export type EstadoDonacion = 'Pendiente' | 'Aprobado' | 'Rechazado';

export interface Donacion {
  id_donacion: number;
  id_usuario: number;
  id_capilla?: number | null;
  capilla_nombre?: string;
  fecha: string;
  monto: number;
  estado: EstadoDonacion;
  id_documento?: number | null;
  id_fondo?: number | null;
}
