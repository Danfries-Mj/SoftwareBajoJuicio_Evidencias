export type TipoAmbito = 'Parroquial' | 'Capilla';
export type CategoriaEvento = 'Eucaristia' | 'Evento' | 'Reunion' | 'Catequesis' | 'Retiro' | 'Procesion' | 'Formacion' | 'Otro';
export type EstadoEvento = 'Proximo' | 'Realizado';

export interface Evento {
  id_evento: number;
  nombre: string;
  descripcion?: string;
  tipo_ambito: TipoAmbito;
  categoria: CategoriaEvento;
  id_capilla?: number | null;
  capilla_nombre?: string;
  fecha: string;
  hora_inicio?: string;
  hora_fin?: string;
  lugar?: string;
  capacidad?: number;
  estado: EstadoEvento;
  creado_por?: number;
}
