import { Component, inject, OnInit, signal } from '@angular/core';
import { RouterLink } from '@angular/router';
import { InscritosCatequesisService } from '../../services/inscritos-catequesis.service';
import { EventosService } from '../../services/eventos.service';
import { FondosService } from '../../services/fondos.service';
import { EucaristiasService } from '../../services/eucaristias.service';
import { SolicitudesSacramentoService } from '../../services/solicitudes-sacramento.service';
import { MovimientosFinancierosService } from '../../services/movimientos-financieros.service';
import { CapillasService } from '../../services/capillas.service';
import { SolicitudSacramento } from '../../models/solicitud-sacramento.model';
import { MovimientoFinanciero } from '../../models/movimiento-financiero.model';
import { mensajesTemporales } from '../../shared/utils/mensajes-temporales';
import { autoRecarga } from '../../shared/utils/auto-recarga';
interface SolicitudConNombre extends SolicitudSacramento {
  solicitante_nombres?: string;
  solicitante_apellidos?: string;
}

interface CatequesisCapilla {
  capilla: string;
  inscritos: number;
  porcentaje: number;
}

@Component({
  selector: 'app-sacerdote-dashboard',
  standalone: true,
  imports: [RouterLink],
  templateUrl: './sacerdote-dashboard.html',
  styleUrl: './sacerdote-dashboard.css'
})
export class SacerdoteDashboardComponent implements OnInit {
  private inscritosService = inject(InscritosCatequesisService);
  private eventosService = inject(EventosService);
  private fondosService = inject(FondosService);
  private eucaristiasService = inject(EucaristiasService);
  private solicitudesService = inject(SolicitudesSacramentoService);
  private movimientosService = inject(MovimientosFinancierosService);
  private capillasService = inject(CapillasService);

  totalInscritos = signal(0);
  totalEventos = signal(0);
  balanceTotal = signal(0);
  totalEucaristias = signal(0);

  solicitudes = signal<SolicitudConNombre[]>([]);
  movimientos = signal<MovimientoFinanciero[]>([]);
  catequesisCapillas = signal<CatequesisCapilla[]>([]);

  mensajeError = mensajesTemporales(signal(''));

  constructor() {
    autoRecarga(() => this.refrescar());
  }

  ngOnInit() {
    this.cargar();
  }

  private cargar(mostrarError = true) {
    this.inscritosService.listar().subscribe({
      next: (inscritos) => {
        this.totalInscritos.set(inscritos.length);
        this.capillasService.listar().subscribe({
          next: (capillas) => {
            const grupos = capillas
              .map(c => ({
                capilla: c.nombre,
                inscritos: inscritos.filter(i => i.id_capilla === c.id_capilla).length
              }))
              .filter(g => g.inscritos > 0);
            const max = Math.max(1, ...grupos.map(g => g.inscritos));
            this.catequesisCapillas.set(
              grupos.map(g => ({ ...g, porcentaje: Math.round((g.inscritos / max) * 100) }))
            );
          }
        });
      },
      error: () => { if (mostrarError) this.mensajeError.set('No se pudieron cargar los datos de catequesis.'); }
    });

    this.eventosService.listar().subscribe({
      next: (eventos) => this.totalEventos.set(eventos.length)
    });

    this.fondosService.listar().subscribe({
      next: (fondos) => this.balanceTotal.set(fondos.reduce((s, f) => s + Number(f.saldo_actual), 0))
    });

    this.eucaristiasService.listar().subscribe({
      next: (eucaristias) => this.totalEucaristias.set(eucaristias.length)
    });

    this.solicitudesService.listar({ estado: 'Pendiente' }).subscribe({
      next: (solicitudes) => this.solicitudes.set(solicitudes as SolicitudConNombre[]),
      error: () => { if (mostrarError) this.mensajeError.set('No se pudieron cargar las solicitudes pendientes.'); }
    });

    this.movimientosService.listar().subscribe({
      next: (movimientos) => this.movimientos.set(movimientos.slice(0, 5))
    });
  }

  private refrescar() {
    this.cargar(false);
  }

  formatMonto(valor: number): string {
    return `$${Number(valor).toLocaleString('es-EC', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
  }

  formatFecha(fecha: string): string {
    if (!fecha) return '—';
    const [y, m, d] = fecha.slice(0, 10).split('-');
    return `${d}/${m}/${y}`;
  }
}
