import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable, map } from 'rxjs';
import { API_URL } from '../core/config/api.config';
import { IntencionMisa } from '../models/intencion-misa.model';

@Injectable({ providedIn: 'root' })
export class IntencionesMisaService {
  private apiUrl = `${API_URL}/intenciones-misa`;

  constructor(private http: HttpClient) {}

  listar(filtros: { estado?: string } = {}): Observable<IntencionMisa[]> {
    let params = new HttpParams();
    if (filtros.estado) params = params.set('estado', filtros.estado);

    return this.http.get<{ mensaje: string; total: number; intenciones: IntencionMisa[] }>(this.apiUrl, { params })
      .pipe(map(respuesta => respuesta.intenciones));
  }

  obtenerPorId(id: number): Observable<IntencionMisa> {
    return this.http.get<{ mensaje: string; intencion: IntencionMisa }>(`${this.apiUrl}/${id}`)
      .pipe(map(respuesta => respuesta.intencion));
  }

  crear(datos: { nombre_mencionar: string; tipo: string; fecha_deseada: string; id_eucaristia?: number | null }): Observable<IntencionMisa> {
    return this.http.post<{ mensaje: string; intencion: IntencionMisa }>(this.apiUrl, datos)
      .pipe(map(respuesta => respuesta.intencion));
  }

  asignar(id: number, idEucaristia: number): Observable<IntencionMisa> {
    return this.http.put<{ mensaje: string; intencion: IntencionMisa }>(`${this.apiUrl}/${id}/asignar`, { id_eucaristia: idEucaristia })
      .pipe(map(respuesta => respuesta.intencion));
  }

  rechazar(id: number): Observable<IntencionMisa> {
    return this.http.put<{ mensaje: string; intencion: IntencionMisa }>(`${this.apiUrl}/${id}/rechazar`, {})
      .pipe(map(respuesta => respuesta.intencion));
  }

  eliminar(id: number): Observable<{ mensaje: string; intencion: IntencionMisa }> {
    return this.http.delete<{ mensaje: string; intencion: IntencionMisa }>(`${this.apiUrl}/${id}`);
  }
}
