import { Component, inject, OnInit, signal } from '@angular/core';
import { Router } from '@angular/router';
import { AbstractControl, FormBuilder, ReactiveFormsModule, ValidationErrors, Validators } from '@angular/forms';
import { AuthService } from '../../services/auth.service';
import { UsuariosService } from '../../services/usuarios.service';
import { FormAlertComponent } from '../../components/form-alert/form-alert';
import { soloTextoValidator, nombresValidator, apellidosValidator, telefonoEcuadorValidator, passwordSeguraValidator, mensajeDeError } from '../../shared/utils/validaciones';
import { mensajesTemporales } from '../../shared/utils/mensajes-temporales';
/**
 * El backend no soporta verificar la contraseña actual (PerfilUsuario no tiene ese campo),
 * así que solo se puede exigir del lado del cliente como paso previo a cambiar la contraseña.
 */
function cambioContrasenaValidator() {
  return (group: AbstractControl): ValidationErrors | null => {
    const actual = group.get('contrasenaActual')?.value;
    const nueva = group.get('nuevaContrasena')?.value;
    const confirmar = group.get('confirmContrasena')?.value;
    if (!nueva && !confirmar) return null;

    const errores: ValidationErrors = {};
    if (!actual) errores['contrasenaActualRequerida'] = true;
    if (nueva !== confirmar) errores['passwordsNoCoinciden'] = true;
    return Object.keys(errores).length ? errores : null;
  };
}

@Component({
  selector: 'app-mi-perfil',
  standalone: true,
  imports: [ReactiveFormsModule, FormAlertComponent],
  templateUrl: './mi-perfil.html',
  styleUrl: './mi-perfil.css'
})
export class MiPerfilComponent implements OnInit {
  private authService = inject(AuthService);
  private usuariosService = inject(UsuariosService);
  private router = inject(Router);
  private fb = inject(FormBuilder);

  cedula = '';
  capilla = '';

  showActual = false;
  showNueva = false;
  showConfirm = false;
  mostrarCambioPassword = false;

  guardando = signal(false);
  mensajeError = mensajesTemporales(signal(''));
  mensajeExito = mensajesTemporales(signal(''));
  mensajeDeError = mensajeDeError;

  form = this.fb.group(
    {
      nombres: ['', [Validators.required, soloTextoValidator(), nombresValidator()]],
      apellidos: ['', [Validators.required, soloTextoValidator(), apellidosValidator()]],
      email: ['', [Validators.required, Validators.email]],
      telefono: ['', [Validators.required, telefonoEcuadorValidator()]],
      contrasenaActual: [''],
      nuevaContrasena: ['', [passwordSeguraValidator()]],
      confirmContrasena: ['']
    },
    { validators: cambioContrasenaValidator() }
  );

  get initials(): string {
    const u = this.authService.user();
    if (!u) return '';
    return (u.nombres[0] + u.apellidos[0]).toUpperCase();
  }

  get rol(): string {
    return this.authService.user()?.rol ?? '';
  }

  ngOnInit() {
    this.cargarDatos();
  }

  private cargarDatos() {
    const u = this.authService.user();
    if (!u) { this.router.navigate(['/']); return; }
    this.cedula = u.cedula;
    this.capilla = u.capilla;
    this.form.patchValue({
      nombres: u.nombres,
      apellidos: u.apellidos,
      email: u.email,
      telefono: u.telefono
    });
  }

  toggleCambioPassword() {
    this.mostrarCambioPassword = !this.mostrarCambioPassword;
    if (!this.mostrarCambioPassword) {
      this.form.patchValue({ contrasenaActual: '', nuevaContrasena: '', confirmContrasena: '' });
    }
  }

  descartar() {
    this.cargarDatos();
    this.form.patchValue({ contrasenaActual: '', nuevaContrasena: '', confirmContrasena: '' });
    this.form.markAsPristine();
    this.form.markAsUntouched();
    this.mensajeError.set('');
    this.mensajeExito.set('');
  }

  guardar() {
    const u = this.authService.user();
    if (!u) return;

    this.mensajeError.set('');
    this.mensajeExito.set('');

    if (this.form.invalid) {
      this.form.markAllAsTouched();
      if (this.form.errors?.['contrasenaActualRequerida']) {
        this.mensajeError.set('Ingresa tu contraseña actual para poder cambiarla.');
      } else if (this.form.errors?.['passwordsNoCoinciden']) {
        this.mensajeError.set('La nueva contraseña y su confirmación no coinciden.');
      } else {
        this.mensajeError.set('Revisa los campos marcados en rojo.');
      }
      return;
    }

    const { nombres, apellidos, email, telefono, nuevaContrasena } = this.form.getRawValue();

    this.guardando.set(true);
    this.usuariosService.editarPerfil(u.id_usuario, {
      nombres: nombres!,
      apellidos: apellidos!,
      telefono: telefono!,
      correo: email!,
      contrasena: nuevaContrasena || undefined
    }).subscribe({
      next: () => {
        this.guardando.set(false);
        this.authService.login({
          ...u,
          nombres: nombres!,
          apellidos: apellidos!,
          email: email!,
          telefono: telefono!,
        });
        this.form.patchValue({ contrasenaActual: '', nuevaContrasena: '', confirmContrasena: '' });
        this.mensajeExito.set('Perfil actualizado correctamente.');
      },
      error: (error) => {
        this.guardando.set(false);
        this.mensajeError.set(error?.error?.mensaje ?? 'No se pudo actualizar el perfil.');
      }
    });
  }

  get capillaLabel(): string {
    return this.authService.user()?.rol === 'Sacerdote' ? 'Parroquia' : 'Capilla';
  }

  goBack() {
    const rol = this.authService.user()?.rol;
    if (rol === 'Sacerdote') this.router.navigate(['/sacerdote/dashboard']);
    else if (rol === 'Coordinador') this.router.navigate(['/coordinador/inicio']);
    else if (rol === 'Catequista') this.router.navigate(['/catequista/inicio']);
    else if (rol === 'Tesorero') this.router.navigate(['/tesorero/fondos']);
    else this.router.navigate(['/']);
  }
}
