export interface Auditoria {
  id_auditoria: number;
  id_usuario?: number | null;
  accion: string;
  tabla_afectada?: string;
  fecha: string;
  detalle?: unknown;
}
