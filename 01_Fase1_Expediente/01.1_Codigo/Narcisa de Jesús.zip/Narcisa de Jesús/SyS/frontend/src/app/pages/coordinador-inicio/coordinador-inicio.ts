import { Component, inject, OnInit, signal } from '@angular/core';
import { SlicePipe } from '@angular/common';
import { AuthService } from '../../services/auth.service';
import { InscritosCatequesisService } from '../../services/inscritos-catequesis.service';
import { EventosService } from '../../services/eventos.service';
import { InscripcionesCatequesisService } from '../../services/inscripciones-catequesis.service';
import { Evento } from '../../models/evento.model';
import { mensajesTemporales } from '../../shared/utils/mensajes-temporales';
import { autoRecarga } from '../../shared/utils/auto-recarga';

interface CatequesisNivel {
  nivel: string;
  inscritos: number;
  total: number;
}

@Component({
  selector: 'app-coordinador-inicio',
  standalone: true,
  imports: [SlicePipe],
  templateUrl: './coordinador-inicio.html',
  styleUrl: './coordinador-inicio.css'
})
export class CoordinadorInicioComponent implements OnInit {
  private authService = inject(AuthService);
  private inscritosCatequesisService = inject(InscritosCatequesisService);
  private eventosService = inject(EventosService);
  private inscripcionesCatequesisService = inject(InscripcionesCatequesisService);

  get capilla() { return this.authService.user()?.capilla ?? ''; }

  mensajeError = mensajesTemporales(signal(''));

  totalInscritos = signal(0);
  totalEventosMes = signal(0);
  totalPendientes = signal(0);

  eventos = signal<Evento[]>([]);
  catequesis = signal<CatequesisNivel[]>([]);

  constructor() {
    autoRecarga(() => this.refrescar());
  }

  ngOnInit() {
    this.cargar();
  }

  private cargar(mostrarError = true) {
    this.inscritosCatequesisService.listar({ estado: 'Activo' }).subscribe({
      next: (inscritos) => {
        this.totalInscritos.set(inscritos.length);
        const porNivel = new Map<string, number>();
        for (const i of inscritos) {
          porNivel.set(i.nivel, (porNivel.get(i.nivel) ?? 0) + 1);
        }
        const total = inscritos.length || 1;
        this.catequesis.set(
          Array.from(porNivel.entries()).map(([nivel, count]) => ({ nivel, inscritos: count, total }))
        );
      },
      error: () => { if (mostrarError) this.mensajeError.set('No se pudieron cargar los inscritos de catequesis.'); }
    });

    const idCapilla = this.authService.user()?.id_capilla ?? undefined;
    this.eventosService.listar().subscribe({
      next: (todos) => {
        this.eventos.set(todos.filter(e => e.id_capilla === idCapilla));

        const mesActual = new Date().toISOString().slice(0, 7);
        const relevantes = todos.filter(e => (e.id_capilla ?? null) === null || e.id_capilla === idCapilla);
        this.totalEventosMes.set(relevantes.filter(e => e.fecha?.slice(0, 7) === mesActual).length);
      },
      error: () => { if (mostrarError) this.mensajeError.set('No se pudieron cargar los eventos de la capilla.'); }
    });

    this.inscripcionesCatequesisService.listar({ estado: 'Pendiente' }).subscribe({
      next: (inscripciones) => this.totalPendientes.set(inscripciones.length),
      error: () => { if (mostrarError) this.mensajeError.set('No se pudieron cargar las solicitudes pendientes.'); }
    });
  }

  private refrescar() {
    this.cargar(false);
  }

  pct(c: CatequesisNivel) {
    return Math.round((c.inscritos / c.total) * 100);
  }
}
