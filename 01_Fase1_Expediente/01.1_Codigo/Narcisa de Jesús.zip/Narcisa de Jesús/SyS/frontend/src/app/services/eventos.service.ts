import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable, map } from 'rxjs';
import { API_URL } from '../core/config/api.config';
import { Evento } from '../models/evento.model';

@Injectable({ providedIn: 'root' })
export class EventosService {
  private apiUrl = `${API_URL}/eventos`;

  constructor(private http: HttpClient) {}

  listar(filtros: { id_capilla?: number; tipo_ambito?: string; estado?: string } = {}): Observable<Evento[]> {
    let params = new HttpParams();
    if (filtros.id_capilla) params = params.set('id_capilla', filtros.id_capilla);
    if (filtros.tipo_ambito) params = params.set('tipo_ambito', filtros.tipo_ambito);
    if (filtros.estado) params = params.set('estado', filtros.estado);

    return this.http.get<{ mensaje: string; total: number; eventos: Evento[] }>(this.apiUrl, { params })
      .pipe(map(respuesta => respuesta.eventos));
  }

  obtenerPorId(id: number): Observable<Evento> {
    return this.http.get<{ mensaje: string; evento: Evento }>(`${this.apiUrl}/${id}`)
      .pipe(map(respuesta => respuesta.evento));
  }

  crear(datos: Partial<Evento>): Observable<Evento> {
    return this.http.post<{ mensaje: string; evento: Evento }>(this.apiUrl, datos)
      .pipe(map(respuesta => respuesta.evento));
  }

  editar(id: number, datos: Partial<Evento>): Observable<Evento> {
    return this.http.put<{ mensaje: string; evento: Evento }>(`${this.apiUrl}/${id}`, datos)
      .pipe(map(respuesta => respuesta.evento));
  }

  eliminar(id: number): Observable<{ mensaje: string; evento: Evento }> {
    return this.http.delete<{ mensaje: string; evento: Evento }>(`${this.apiUrl}/${id}`);
  }
}
