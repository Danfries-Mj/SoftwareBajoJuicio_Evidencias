import { Component, Input, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-success-modal',
  standalone: true,
  templateUrl: './success-modal.html',
  styleUrl: './success-modal.css'
})
export class SuccessModalComponent {
  @Input() visible = false;
  @Input() message = '';
  @Output() closed = new EventEmitter<void>();
}
