import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable, map } from 'rxjs';
import { API_URL } from '../core/config/api.config';
import { Acta } from '../models/acta.model';

@Injectable({ providedIn: 'root' })
export class ActasService {
  private apiUrl = `${API_URL}/actas`;

  constructor(private http: HttpClient) {}

  listar(filtros: { id_capilla?: number; tipo?: string } = {}): Observable<Acta[]> {
    let params = new HttpParams();
    if (filtros.id_capilla) params = params.set('id_capilla', filtros.id_capilla);
    if (filtros.tipo) params = params.set('tipo', filtros.tipo);

    return this.http.get<{ mensaje: string; total: number; actas: Acta[] }>(this.apiUrl, { params })
      .pipe(map(respuesta => respuesta.actas));
  }

  obtenerPorId(id: number): Observable<Acta> {
    return this.http.get<{ mensaje: string; acta: Acta }>(`${this.apiUrl}/${id}`)
      .pipe(map(respuesta => respuesta.acta));
  }

  crear(datos: Partial<Acta>): Observable<Acta> {
    return this.http.post<{ mensaje: string; acta: Acta }>(this.apiUrl, datos)
      .pipe(map(respuesta => respuesta.acta));
  }

  editar(id: number, datos: Partial<Acta>): Observable<Acta> {
    return this.http.put<{ mensaje: string; acta: Acta }>(`${this.apiUrl}/${id}`, datos)
      .pipe(map(respuesta => respuesta.acta));
  }

  eliminar(id: number): Observable<{ mensaje: string; acta: Acta }> {
    return this.http.delete<{ mensaje: string; acta: Acta }>(`${this.apiUrl}/${id}`);
  }
}
