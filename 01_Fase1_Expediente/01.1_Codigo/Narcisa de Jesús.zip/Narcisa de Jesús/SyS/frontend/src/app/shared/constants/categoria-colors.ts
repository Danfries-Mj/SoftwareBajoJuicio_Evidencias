/**
 * Un color de Bootstrap por cada categoría de evento, reutilizado en todos los lugares
 * donde se muestra una categoría (calendario, próximos eventos, tabla) para que el mismo
 * tipo de evento siempre se vea igual.
 */
export const CATEGORIA_COLOR: Record<string, string> = {
  Eucaristia: 'primary',
  Evento: 'warning',
  Reunion: 'info',
  Catequesis: 'success',
  Retiro: 'secondary',
  Procesion: 'danger',
  Formacion: 'dark',
  Otro: 'light'
};

export function claseBadgeCategoria(categoria: string | null | undefined): string {
  const color = CATEGORIA_COLOR[categoria ?? ''] ?? 'secondary';
  return `bg-${color}-subtle text-${color}-emphasis`;
}

export function claseDotCategoria(categoria: string | null | undefined): string {
  const color = CATEGORIA_COLOR[categoria ?? ''] ?? 'secondary';
  return `bg-${color}`;
}
