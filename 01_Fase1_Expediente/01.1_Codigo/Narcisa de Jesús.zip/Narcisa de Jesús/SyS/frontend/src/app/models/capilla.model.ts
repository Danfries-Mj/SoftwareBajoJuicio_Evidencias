export interface Capilla {
  id_capilla: number;
  nombre: string;
  direccion?: string;
  telefono?: string;
  activa?: boolean;
}
