import { Component, inject, OnInit, signal } from '@angular/core';
import { InscritosCatequesisService } from '../../services/inscritos-catequesis.service';
import { EventosService } from '../../services/eventos.service';
import { MovimientosFinancierosService } from '../../services/movimientos-financieros.service';
import { CapillasService } from '../../services/capillas.service';
import { mensajesTemporales } from '../../shared/utils/mensajes-temporales';
import { autoRecarga } from '../../shared/utils/auto-recarga';

interface CapillaResumen {
  capilla: string;
  inscritos: number;
  activos: number;
  finalizados: number;
}

interface MesResumen {
  mes: string;
  total: number;
}

interface FinanzaMes {
  mes: string;
  ingresos: number;
  egresos: number;
}

const MESES = ['Ene', 'Feb', 'Mar', 'Abr', 'May', 'Jun', 'Jul', 'Ago', 'Sep', 'Oct', 'Nov', 'Dic'];

@Component({
  selector: 'app-sacerdote-reportes',
  standalone: true,
  imports: [],
  templateUrl: './sacerdote-reportes.html',
  styleUrl: './sacerdote-reportes.css'
})
export class SacerdoteReportesComponent implements OnInit {
  private inscritosService = inject(InscritosCatequesisService);
  private eventosService = inject(EventosService);
  private movimientosService = inject(MovimientosFinancierosService);
  private capillasService = inject(CapillasService);

  anio = new Date().getFullYear().toString();

  catequesisPrimera = signal<CapillaResumen[]>([]);
  catequesisConfirmacion = signal<CapillaResumen[]>([]);
  eventosPorMes = signal<MesResumen[]>([]);
  finanzas = signal<FinanzaMes[]>([]);

  totalInscritos = signal(0);
  totalEventos = signal(0);
  balanceTotal = signal(0);

  mensajeError = mensajesTemporales(signal(''));

  constructor() {
    autoRecarga(() => this.refrescar());
  }

  ngOnInit() {
    this.cargar();
  }

  private cargar(mostrarError = true) {
    this.capillasService.listar().subscribe({
      next: (capillas) => {
        this.inscritosService.listar().subscribe({
          next: (inscritos) => {
            this.totalInscritos.set(inscritos.length);

            const construir = (nivel: string): CapillaResumen[] => capillas
              .map(c => {
                const deCapilla = inscritos.filter(i => i.id_capilla === c.id_capilla && i.nivel === nivel);
                return {
                  capilla: c.nombre,
                  inscritos: deCapilla.length,
                  activos: deCapilla.filter(i => i.estado === 'Activo').length,
                  finalizados: deCapilla.filter(i => i.estado === 'Finalizado').length
                };
              })
              .filter(r => r.inscritos > 0);

            this.catequesisPrimera.set(construir('Primera Comunion'));
            this.catequesisConfirmacion.set(construir('Confirmacion'));
          },
          error: () => { if (mostrarError) this.mensajeError.set('No se pudieron cargar los datos de catequesis.'); }
        });
      }
    });

    this.eventosService.listar().subscribe({
      next: (eventos) => {
        const delAnio = eventos.filter(e => e.fecha?.slice(0, 4) === this.anio);
        this.totalEventos.set(delAnio.length);
        this.eventosPorMes.set(MESES.map((mes, i) => ({
          mes,
          total: delAnio.filter(e => Number(e.fecha.slice(5, 7)) === i + 1).length
        })));
      },
      error: () => { if (mostrarError) this.mensajeError.set('No se pudieron cargar los eventos.'); }
    });

    this.movimientosService.listar().subscribe({
      next: (movimientos) => {
        const delAnio = movimientos.filter(m => m.fecha?.slice(0, 4) === this.anio);
        const finanzasPorMes = MESES.map((mes, i) => {
          const delMes = delAnio.filter(m => Number(m.fecha.slice(5, 7)) === i + 1);
          return {
            mes,
            ingresos: delMes.filter(m => m.tipo === 'Ingreso').reduce((s, m) => s + Number(m.monto), 0),
            egresos: delMes.filter(m => m.tipo === 'Egreso').reduce((s, m) => s + Number(m.monto), 0)
          };
        });
        this.finanzas.set(finanzasPorMes);
        this.balanceTotal.set(finanzasPorMes.reduce((s, f) => s + f.ingresos - f.egresos, 0));
      },
      error: () => { if (mostrarError) this.mensajeError.set('No se pudieron cargar los movimientos financieros.'); }
    });
  }

  private refrescar() {
    this.cargar(false);
  }

  get maxPrimera(): number {
    return Math.max(1, ...this.catequesisPrimera().map(c => c.inscritos));
  }

  get maxConfirmacion(): number {
    return Math.max(1, ...this.catequesisConfirmacion().map(c => c.inscritos));
  }

  get maxEventos(): number {
    return Math.max(1, ...this.eventosPorMes().map(e => e.total));
  }

  get maxFinanzas(): number {
    return Math.max(1, ...this.finanzas().map(f => Math.max(f.ingresos, f.egresos)));
  }

  pctBarra(n: number, max: number): number {
    return Math.round((n / max) * 100);
  }

  /** Exporta el reporte usando el diálogo de impresión del navegador ("Guardar como PDF"). */
  exportarPDF() {
    window.print();
  }
}
