import { Routes } from '@angular/router';
import { requireAuth } from './core/guards/auth.guard';
import { requireRoles } from './core/guards/role.guard';
import { HomeComponent } from './pages/home/home';
import { SobreNosotrosComponent } from './pages/sobre-nosotros/sobre-nosotros';
import { ContactoComponent } from './pages/contacto/contacto';
import { DonacionesComponent } from './pages/donaciones/donaciones';
import { IntencionMisaComponent } from './pages/intenciones-misa/intenciones-misa';
import { InscripcionesComponent } from './pages/inscripciones/inscripciones';
import { MiPerfilComponent } from './pages/mi-perfil/mi-perfil';
import { MisDocumentosComponent } from './pages/mis-documentos/mis-documentos';
import { SacerdoteDashboardComponent } from './pages/sacerdote-dashboard/sacerdote-dashboard';
import { SacerdoteEucaristiasComponent } from './pages/sacerdote-eucaristias/sacerdote-eucaristias';
import { SacerdoteEventosComponent } from './pages/sacerdote-eventos/sacerdote-eventos';
import { SacerdoteCatequesisComponent } from './pages/sacerdote-catequesis/sacerdote-catequesis';
import { SacerdoteActasComponent } from './pages/sacerdote-actas/sacerdote-actas';
import { SacerdoteFinanzasComponent } from './pages/sacerdote-finanzas/sacerdote-finanzas';
import { SacerdoteUsuariosComponent } from './pages/sacerdote-usuarios/sacerdote-usuarios';
import { SacerdoteSolicitudComponent } from './pages/sacerdote-solicitud/sacerdote-solicitud';
import { SacerdoteIntencionesComponent } from './pages/sacerdote-intenciones/sacerdote-intenciones';
import { CoordinadorInicioComponent } from './pages/coordinador-inicio/coordinador-inicio';
import { CoordinadorSolicitudesComponent } from './pages/coordinador-solicitudes/coordinador-solicitudes';
import { CoordinadorEventosComponent } from './pages/coordinador-eventos/coordinador-eventos';
import { CoordinadorCatequesisComponent } from './pages/coordinador-catequesis/coordinador-catequesis';
import { CoordinadorActasComponent } from './pages/coordinador-actas/coordinador-actas';
import { CatequistaInicioComponent } from './pages/catequista-inicio/catequista-inicio';
import { CatequistaSolicitudesComponent } from './pages/catequista-solicitudes/catequista-solicitudes';
import { CatequistaCatequesisComponent } from './pages/catequista-catequesis/catequista-catequesis';
import { CatequistaEventosComponent } from './pages/catequista-eventos/catequista-eventos';
import { TesoreroFondosComponent } from './pages/tesorero-fondos/tesorero-fondos';
import { TesoreroDonacionesComponent } from './pages/tesorero-donaciones/tesorero-donaciones';
import { TesoreroCatequesisComponent } from './pages/tesorero-catequesis/tesorero-catequesis';
import { TesoreroMovimientoComponent } from './pages/tesorero-movimiento/tesorero-movimiento';
import { TesoreroReportesComponent } from './pages/tesorero-reportes/tesorero-reportes';
import { TesoreroCierreComponent } from './pages/tesorero-cierre/tesorero-cierre';
import { SacerdoteComunicadosComponent } from './pages/sacerdote-comunicados/sacerdote-comunicados';
import { SacerdoteReportesComponent } from './pages/sacerdote-reportes/sacerdote-reportes';
import { MisSolicitudesComponent } from './pages/mis-solicitudes/mis-solicitudes';
import { MisCertificadosComponent } from './pages/mis-certificados/mis-certificados';
import { EventosParroquiaComponent } from './pages/eventos-parroquia/eventos-parroquia';
import { CoordinadorDirectorioComponent } from './pages/coordinador-directorio/coordinador-directorio';
import { CoordinadorComunicadosComponent } from './pages/coordinador-comunicados/coordinador-comunicados';
import { CoordinadorReportesComponent } from './pages/coordinador-reportes/coordinador-reportes';
import { ComunicadosComponent } from './pages/comunicados/comunicados';

export const routes: Routes = [
  { path: '', component: HomeComponent },
  { path: 'sobre-nosotros', component: SobreNosotrosComponent },
  { path: 'contacto', component: ContactoComponent },
  { path: 'donaciones', component: DonacionesComponent },
  { path: 'intenciones-misa', component: IntencionMisaComponent, canActivate: [requireAuth] },
  { path: 'inscripciones', component: InscripcionesComponent, canActivate: [requireAuth] },
  { path: 'mi-perfil', component: MiPerfilComponent, canActivate: [requireAuth] },
  { path: 'mis-documentos', component: MisDocumentosComponent, canActivate: [requireAuth] },
  { path: 'sacerdote/dashboard', component: SacerdoteDashboardComponent, canActivate: [requireRoles('Sacerdote')] },
  { path: 'sacerdote/eucaristias', component: SacerdoteEucaristiasComponent, canActivate: [requireRoles('Sacerdote')] },
  { path: 'sacerdote/eventos', component: SacerdoteEventosComponent, canActivate: [requireRoles('Sacerdote')] },
  { path: 'sacerdote/catequesis', component: SacerdoteCatequesisComponent, canActivate: [requireRoles('Sacerdote')] },
  { path: 'sacerdote/actas', component: SacerdoteActasComponent, canActivate: [requireRoles('Sacerdote')] },
  { path: 'sacerdote/finanzas', component: SacerdoteFinanzasComponent, canActivate: [requireRoles('Sacerdote')] },
  { path: 'sacerdote/usuarios', component: SacerdoteUsuariosComponent, canActivate: [requireRoles('Sacerdote')] },
  { path: 'sacerdote/solicitud', component: SacerdoteSolicitudComponent, canActivate: [requireRoles('Sacerdote')] },
  { path: 'sacerdote/intenciones', component: SacerdoteIntencionesComponent, canActivate: [requireRoles('Sacerdote')] },
  { path: 'coordinador/inicio', component: CoordinadorInicioComponent, canActivate: [requireRoles('Coordinador')] },
  { path: 'coordinador/solicitudes', component: CoordinadorSolicitudesComponent, canActivate: [requireRoles('Coordinador')] },
  { path: 'coordinador/eventos', component: CoordinadorEventosComponent, canActivate: [requireRoles('Coordinador')] },
  { path: 'coordinador/catequesis', component: CoordinadorCatequesisComponent, canActivate: [requireRoles('Coordinador')] },
  { path: 'coordinador/actas', component: CoordinadorActasComponent, canActivate: [requireRoles('Coordinador')] },
  { path: 'catequista/inicio', component: CatequistaInicioComponent, canActivate: [requireRoles('Catequista')] },
  { path: 'catequista/solicitudes', component: CatequistaSolicitudesComponent, canActivate: [requireRoles('Catequista')] },
  { path: 'catequista/catequesis', component: CatequistaCatequesisComponent, canActivate: [requireRoles('Catequista')] },
  { path: 'catequista/eventos', component: CatequistaEventosComponent, canActivate: [requireRoles('Catequista')] },
  { path: 'tesorero/fondos', component: TesoreroFondosComponent, canActivate: [requireRoles('Tesorero')] },
  { path: 'tesorero/donaciones', component: TesoreroDonacionesComponent, canActivate: [requireRoles('Tesorero')] },
  { path: 'tesorero/catequesis', component: TesoreroCatequesisComponent, canActivate: [requireRoles('Tesorero')] },
  { path: 'tesorero/movimiento', component: TesoreroMovimientoComponent, canActivate: [requireRoles('Tesorero')] },
  { path: 'tesorero/reportes', component: TesoreroReportesComponent, canActivate: [requireRoles('Tesorero')] },
  { path: 'tesorero/cierre', component: TesoreroCierreComponent, canActivate: [requireRoles('Tesorero')] },
  { path: 'sacerdote/comunicados', component: SacerdoteComunicadosComponent, canActivate: [requireRoles('Sacerdote')] },
  { path: 'sacerdote/reportes', component: SacerdoteReportesComponent, canActivate: [requireRoles('Sacerdote')] },
  { path: 'mis-solicitudes', component: MisSolicitudesComponent, canActivate: [requireAuth] },
  { path: 'mis-certificados', component: MisCertificadosComponent, canActivate: [requireAuth] },
  { path: 'eventos', component: EventosParroquiaComponent },
  { path: 'coordinador/directorio', component: CoordinadorDirectorioComponent, canActivate: [requireRoles('Coordinador')] },
  { path: 'coordinador/comunicados', component: CoordinadorComunicadosComponent, canActivate: [requireRoles('Coordinador')] },
  { path: 'coordinador/reportes', component: CoordinadorReportesComponent, canActivate: [requireRoles('Coordinador')] },
  { path: 'comunicados', component: ComunicadosComponent },
  { path: '**', redirectTo: '' }
];
