import { Component, OnInit, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { SlicePipe } from '@angular/common';
import { firstValueFrom } from 'rxjs';
import { AuthService } from '../../services/auth.service';
import { InscritosCatequesisService } from '../../services/inscritos-catequesis.service';
import { PersonasService } from '../../services/personas.service';
import { CertificadosService } from '../../services/certificados.service';
import { DocumentosService } from '../../services/documentos.service';
import { InscritoCatequesis } from '../../models/inscrito-catequesis.model';
import { mensajesTemporales } from '../../shared/utils/mensajes-temporales';
import { autoRecarga } from '../../shared/utils/auto-recarga';
import { soloDigitos, validarArchivo } from '../../shared/utils/validaciones';

interface InscritoConCatequista extends InscritoCatequesis {
  catequista_nombres?: string;
  catequista_apellidos?: string;
}

interface NuevoInscrito {
  cedula?: string;
  nombres?: string;
  nivel?: string;
  id_catequista?: number | null;
  fecha_inscripcion?: string;
  monto?: number;
  comprobante?: string;
  estado?: string;
}

function nuevoArchivo() {
  return { nombre: signal(''), dataUrl: signal(''), mime: signal(''), error: signal('') };
}

@Component({
  selector: 'app-coordinador-catequesis',
  standalone: true,
  imports: [FormsModule, SlicePipe],
  templateUrl: './coordinador-catequesis.html',
  styleUrl: './coordinador-catequesis.css'
})
export class CoordinadorCatequesisComponent implements OnInit {
  private authService = inject(AuthService);
  private inscritosService = inject(InscritosCatequesisService);
  private personasService = inject(PersonasService);
  private certificadosService = inject(CertificadosService);
  private documentosService = inject(DocumentosService);

  /**
   * Certificado prerrequisito inmediato de cada nivel (igual que en "Mi catequesis" del
   * Catequista): para inscribir a Primera Comunión hace falta el de Bautismo emitido;
   * para Confirmación, el de Primera Comunión.
   */
  private readonly prerrequisitoInmediato: Record<string, string> = {
    'Primera Comunion': 'Bautismo',
    'Confirmacion': 'Primera Comunion'
  };

  showModal = false;
  guardando = signal(false);
  mensajeError = mensajesTemporales(signal(''));
  mensajeExito = mensajesTemporales(signal(''));

  inscritos = signal<InscritoConCatequista[]>([]);

  niveles = [
    { value: 'Primera Comunion', label: 'Primera Comunión' },
    { value: 'Confirmacion', label: 'Confirmación' }
  ];
  estados = ['Pendiente', 'Activo', 'Finalizado'];

  nuevo: NuevoInscrito = {};
  editando: InscritoConCatequista | null = null;

  buscandoCedula = signal(false);
  busquedaCedulaMsg = signal('');
  personaEnSistema = signal(false);
  certificadoValidado = signal(false);
  private personaIdPersona: number | null = null;
  comprobanteArchivo = nuevoArchivo();
  certificadoNuevoArchivo = nuevoArchivo();

  // Si el inscrito ya está Finalizado y la persona ya tiene el certificado de ese nivel
  // emitido, el Coordinador ya no puede modificar su estado.
  estadoBloqueadoPorCertificado = signal(false);
  verificandoCertificado = signal(false);

  get capilla() { return this.authService.user()?.capilla ?? ''; }

  get totalInscritos() { return this.inscritos().length; }
  get totalPrimeraComunion() { return this.inscritos().filter(i => i.nivel === 'Primera Comunion').length; }
  get totalConfirmacion() { return this.inscritos().filter(i => i.nivel === 'Confirmacion').length; }

  constructor() {
    autoRecarga(() => this.refrescar());
  }

  ngOnInit() {
    this.cargar();
  }

  private cargar(mostrarError = true) {
    this.inscritosService.listar().subscribe({
      next: (data) => this.inscritos.set(data as InscritoConCatequista[]),
      error: () => { if (mostrarError) this.mensajeError.set('No se pudieron cargar los inscritos de catequesis.'); }
    });
  }

  private refrescar() {
    this.cargar(false);
  }

  nombreNivel(valor: string): string {
    return this.niveles.find(n => n.value === valor)?.label ?? valor;
  }

  nombreCatequista(i: InscritoConCatequista): string {
    if (i.catequista_nombres || i.catequista_apellidos) {
      return `${i.catequista_nombres ?? ''} ${i.catequista_apellidos ?? ''}`.trim();
    }
    return i.id_catequista ? `Catequista #${i.id_catequista}` : '—';
  }

  openModal() {
    this.nuevo = { estado: 'Pendiente', nivel: 'Primera Comunion', fecha_inscripcion: new Date().toISOString().slice(0, 10) };
    this.editando = null;
    this.mensajeError.set('');
    this.busquedaCedulaMsg.set('');
    this.personaEnSistema.set(false);
    this.certificadoValidado.set(false);
    this.personaIdPersona = null;
    this.comprobanteArchivo = nuevoArchivo();
    this.certificadoNuevoArchivo = nuevoArchivo();
    this.showModal = true;
  }

  onCedulaChange(valor: string) {
    this.nuevo.cedula = soloDigitos(valor, 10);
    this.personaEnSistema.set(false);
    this.certificadoValidado.set(false);
    this.personaIdPersona = null;
    this.busquedaCedulaMsg.set('');
  }

  onNivelChange(valor: string) {
    this.nuevo.nivel = valor;
    this.personaEnSistema.set(false);
    this.certificadoValidado.set(false);
    this.personaIdPersona = null;
    this.busquedaCedulaMsg.set('');
  }

  onFileSelect(event: Event, target: 'comprobanteArchivo' | 'certificadoNuevoArchivo' = 'comprobanteArchivo') {
    const input = event.target as HTMLInputElement;
    const file = input.files?.[0];
    if (!file) return;

    const archivo = this[target];
    const error = validarArchivo(file, { tipos: ['application/pdf', 'image/png', 'image/jpeg'] });
    if (error) {
      archivo.error.set(error);
      archivo.nombre.set('');
      archivo.dataUrl.set('');
      input.value = '';
      return;
    }

    archivo.error.set('');
    const reader = new FileReader();
    reader.onload = () => {
      archivo.nombre.set(file.name);
      archivo.dataUrl.set(reader.result as string);
      archivo.mime.set(file.type);
    };
    reader.readAsDataURL(file);
  }

  /**
   * Busca la persona por cédula (tenga o no cuenta de usuario) para autocompletar su
   * nombre y verificar de una vez su certificado prerrequisito del nivel seleccionado.
   * Igual que en "Mi catequesis" del Catequista.
   */
  async buscarPorCedula() {
    const cedula = (this.nuevo.cedula ?? '').trim();
    if (!cedula || !/^\d{10}$/.test(cedula)) {
      this.busquedaCedulaMsg.set('Ingresa una cédula válida (10 dígitos) para buscar.');
      return;
    }
    if (!this.nuevo.nivel) {
      this.busquedaCedulaMsg.set('Selecciona primero el nivel de catequesis.');
      return;
    }

    this.buscandoCedula.set(true);
    this.busquedaCedulaMsg.set('');
    this.personaEnSistema.set(false);
    this.certificadoValidado.set(false);
    this.personaIdPersona = null;

    const tipoPrerrequisito = this.prerrequisitoInmediato[this.nuevo.nivel];

    try {
      const persona = await firstValueFrom(this.personasService.buscarPorCedula(cedula));
      this.personaEnSistema.set(true);
      this.personaIdPersona = persona.id_persona;
      this.nuevo.nombres = `${persona.nombres} ${persona.apellidos}`;

      const tieneCertificado = await firstValueFrom(
        this.certificadosService.tienePrerrequisitoEmitido(persona.id_persona, tipoPrerrequisito)
      );
      this.certificadoValidado.set(tieneCertificado);
      this.buscandoCedula.set(false);
      this.busquedaCedulaMsg.set(
        tieneCertificado
          ? `Persona encontrada: tiene el certificado de ${tipoPrerrequisito} emitido.`
          : `Persona encontrada: sube su certificado de ${tipoPrerrequisito} para poder inscribirla (quedará pendiente hasta que el Sacerdote lo valide).`
      );
    } catch (error: any) {
      this.buscandoCedula.set(false);
      this.personaEnSistema.set(false);
      this.nuevo.nombres = '';
      this.busquedaCedulaMsg.set(
        error?.status === 404
          ? `No se encontró una persona registrada con esa cédula. Completa el nombre manualmente y adjunta su certificado de ${tipoPrerrequisito}.`
          : (error?.error?.mensaje ?? 'No se pudo buscar la cédula. Intenta de nuevo.')
      );
    }
  }

  editar(i: InscritoConCatequista) {
    this.nuevo = {
      cedula: i.cedula,
      nombres: i.nombres,
      nivel: i.nivel,
      id_catequista: i.id_catequista,
      fecha_inscripcion: (i.fecha_inscripcion || '').slice(0, 10),
      monto: i.monto,
      comprobante: i.comprobante,
      estado: i.estado
    };
    this.editando = i;
    this.mensajeError.set('');
    this.estadoBloqueadoPorCertificado.set(false);
    this.showModal = true;

    // Solo tiene sentido bloquear el estado si ya está Finalizado; de lo contrario no
    // hace falta ni consultar el certificado.
    if (i.estado !== 'Finalizado') return;

    this.verificandoCertificado.set(true);
    this.personasService.buscarPorCedula(i.cedula).subscribe({
      next: (persona) => {
        this.certificadosService.tienePrerrequisitoEmitido(persona.id_persona, i.nivel).subscribe({
          next: (tiene) => {
            this.verificandoCertificado.set(false);
            this.estadoBloqueadoPorCertificado.set(tiene);
          },
          error: () => this.verificandoCertificado.set(false)
        });
      },
      error: () => this.verificandoCertificado.set(false)
    });
  }

  async guardar() {
    this.mensajeError.set('');

    if (this.editando) {
      if (!this.nuevo.estado) {
        this.mensajeError.set('El estado es obligatorio.');
        return;
      }
      // El <select> de estado queda deshabilitado en la plantilla cuando ya está
      // bloqueado; se fuerza el valor original por si acaso llega alterado.
      if (this.estadoBloqueadoPorCertificado()) {
        this.nuevo.estado = this.editando.estado;
      }
      this.guardando.set(true);
      this.inscritosService.editar(this.editando.id_inscrito, {
        id_catequista: this.nuevo.id_catequista ?? undefined,
        estado: this.nuevo.estado
      }).subscribe({
        next: () => {
          this.guardando.set(false);
          this.mensajeExito.set('Inscrito actualizado correctamente.');
          this.editando = null;
          this.nuevo = {};
          this.showModal = false;
          this.cargar();
        },
        error: (error) => {
          this.guardando.set(false);
          this.mensajeError.set(error?.error?.mensaje ?? 'No se pudo actualizar el inscrito.');
        }
      });
      return;
    }

    if (!this.nuevo.cedula?.trim() || !this.nuevo.nombres?.trim() || !this.nuevo.nivel || !this.nuevo.fecha_inscripcion) {
      this.mensajeError.set('Cédula, nombre, nivel y fecha de inscripción son obligatorios.');
      return;
    }
    if (!/^\d{10}$/.test(this.nuevo.cedula.trim())) {
      this.mensajeError.set('La cédula debe tener exactamente 10 dígitos.');
      return;
    }
    if (!this.certificadoValidado() && !this.certificadoNuevoArchivo.dataUrl()) {
      this.mensajeError.set('Adjunta el certificado prerrequisito, o busca la cédula y verifica que la persona ya lo tenga emitido.');
      return;
    }
    if (!this.comprobanteArchivo.dataUrl()) {
      this.mensajeError.set('La foto o PDF del comprobante de pago es obligatorio.');
      return;
    }

    const idCapilla = this.authService.user()?.id_capilla;
    if (!idCapilla) {
      this.mensajeError.set('No tienes una capilla asignada.');
      return;
    }

    const nombreCompleto = this.nuevo.nombres.trim();
    const cedula = this.nuevo.cedula.trim();

    this.guardando.set(true);
    try {
      // Resuelve (o crea) la persona, igual que en "Mi catequesis" del Catequista.
      let idPersona = this.personaIdPersona;
      if (!idPersona) {
        try {
          const personaExistente = await firstValueFrom(this.personasService.buscarPorCedula(cedula));
          idPersona = personaExistente.id_persona;
        } catch {
          const partes = nombreCompleto.split(/\s+/);
          const personaCreada = await firstValueFrom(this.personasService.crear({
            cedula, nombres: partes.slice(0, Math.ceil(partes.length / 2)).join(' ') || nombreCompleto,
            apellidos: partes.slice(Math.ceil(partes.length / 2)).join(' ') || nombreCompleto
          }));
          idPersona = personaCreada.id_persona;
        }
      }

      // El Coordinador no valida certificados: el que suba aquí queda "Pendiente" hasta
      // que el Sacerdote lo revise (igual que cuando lo sube un Catequista o un Laico).
      if (!this.certificadoValidado() && this.certificadoNuevoArchivo.dataUrl()) {
        await firstValueFrom(this.certificadosService.crear({
          tipo: this.prerrequisitoInmediato[this.nuevo.nivel], id_persona: idPersona,
          archivo_nombre: this.certificadoNuevoArchivo.nombre(),
          archivo_url: this.certificadoNuevoArchivo.dataUrl(), mime_type: this.certificadoNuevoArchivo.mime()
        }));
      }

      const documento = await firstValueFrom(this.documentosService.crear({
        tipo: `Comprobante de catequesis - ${nombreCompleto} (cédula ${cedula})`,
        archivo_nombre: this.comprobanteArchivo.nombre(),
        archivo_url: this.comprobanteArchivo.dataUrl(),
        mime_type: this.comprobanteArchivo.mime()
      }));

      await firstValueFrom(this.inscritosService.crear({
        cedula,
        nombres: nombreCompleto,
        nivel: this.nuevo.nivel as InscritoCatequesis['nivel'],
        id_capilla: idCapilla,
        id_catequista: this.nuevo.id_catequista ?? undefined,
        fecha_inscripcion: this.nuevo.fecha_inscripcion,
        monto: this.nuevo.monto,
        comprobante: documento.archivo_nombre,
        estado: this.certificadoValidado() ? 'Activo' : 'Pendiente'
      }));

      this.guardando.set(false);
      this.mensajeExito.set(
        this.certificadoValidado()
          ? 'Inscrito registrado correctamente.'
          : 'Inscrito registrado como Pendiente: se activará solo cuando el Sacerdote valide el certificado.'
      );
      this.nuevo = {};
      this.showModal = false;
      this.cargar();
    } catch (error: any) {
      this.guardando.set(false);
      this.mensajeError.set(error?.error?.mensaje ?? 'No se pudo registrar el inscrito.');
    }
  }

  closeOnOverlay(e: MouseEvent) {
    if (e.target === e.currentTarget) this.showModal = false;
  }
}
