import { Component, OnInit, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { CierresMesService } from '../../services/cierres-mes.service';
import { MovimientosFinancierosService } from '../../services/movimientos-financieros.service';
import { AuthService } from '../../services/auth.service';
import { CierreMes } from '../../models/cierre-mes.model';
import { mensajesTemporales } from '../../shared/utils/mensajes-temporales';
import { autoRecarga } from '../../shared/utils/auto-recarga';

interface FondoDesglose {
  nombre: string;
  ingresos: number;
  egresos: number;
}

@Component({
  selector: 'app-tesorero-cierre',
  standalone: true,
  imports: [FormsModule],
  templateUrl: './tesorero-cierre.html',
  styleUrl: './tesorero-cierre.css'
})
export class TesoreroCierreComponent implements OnInit {
  protected Number = Number;

  private cierresMesService = inject(CierresMesService);
  private movimientosService = inject(MovimientosFinancierosService);
  private authService = inject(AuthService);

  meses = ['Enero','Febrero','Marzo','Abril','Mayo','Junio','Julio','Agosto','Septiembre','Octubre','Noviembre','Diciembre'];
  mes = 'Enero';
  anio = new Date().getFullYear().toString();

  historial = signal<CierreMes[]>([]);
  cierreActual = signal<CierreMes | null>(null);
  fondosDetalle = signal<FondoDesglose[]>([]);

  generando = signal(false);
  mensajeError = mensajesTemporales(signal(''));
  mensajeExito = mensajesTemporales(signal(''));

  constructor() {
    autoRecarga(() => this.refrescar());
  }

  ngOnInit() {
    this.cargarHistorial();
  }

  private cargarHistorial(mostrarError = true) {
    this.cierresMesService.listar().subscribe({
      next: (cierres) => this.historial.set(cierres),
      error: () => { if (mostrarError) this.mensajeError.set('No se pudo cargar el historial de cierres.'); }
    });
  }

  private refrescar() {
    this.cargarHistorial(false);
  }

  get totalIngresos() { return Number(this.cierreActual()?.total_ingresos ?? 0); }
  get totalEgresos() { return Number(this.cierreActual()?.total_egresos ?? 0); }
  get balance() { return this.totalIngresos - this.totalEgresos; }

  nombreMes(numero: number): string {
    return this.meses[numero - 1] ?? String(numero);
  }

  /** Alcance del cierre que este tesorero puede generar: su capilla, o la parroquia si no tiene una asignada. */
  get alcanceUsuario(): string {
    return this.authService.user()?.capilla ?? 'Parroquia';
  }

  alcanceCierre(cierre: CierreMes): string {
    return cierre.capilla_nombre ?? 'Parroquia';
  }

  generarCierre() {
    this.mensajeError.set('');
    this.mensajeExito.set('');

    const numeroMes = this.meses.indexOf(this.mes) + 1;
    const numeroAnio = Number(this.anio);

    if (!numeroMes || !numeroAnio) {
      this.mensajeError.set('Selecciona un mes y un año válidos.');
      return;
    }

    const hoy = new Date();
    const mesActual = hoy.getMonth() + 1;
    const anioActual = hoy.getFullYear();
    if (numeroAnio > anioActual || (numeroAnio === anioActual && numeroMes >= mesActual)) {
      this.mensajeError.set('No se puede cerrar un mes que todavía está en curso o que no ha comenzado.');
      return;
    }

    this.generando.set(true);
    this.cierresMesService.crear({ mes: numeroMes, anio: numeroAnio }).subscribe({
      next: (cierre) => {
        this.cierreActual.set(cierre);
        this.mensajeExito.set('Cierre generado correctamente.');
        this.cargarHistorial();
        this.cargarDesglosePorFondo(numeroMes, numeroAnio);
      },
      error: (error) => {
        this.generando.set(false);
        this.mensajeError.set(error?.error?.mensaje ?? error?.error?.error ?? 'No se pudo generar el cierre.');
      }
    });
  }

  private cargarDesglosePorFondo(mes: number, anio: number) {
    const ultimoDia = new Date(anio, mes, 0).getDate();
    const fechaDesde = `${anio}-${String(mes).padStart(2, '0')}-01`;
    const fechaHasta = `${anio}-${String(mes).padStart(2, '0')}-${String(ultimoDia).padStart(2, '0')}`;

    this.movimientosService.listar({ fecha_desde: fechaDesde, fecha_hasta: fechaHasta }).subscribe({
      next: (movimientos) => {
        this.generando.set(false);
        const mapa = new Map<string, FondoDesglose>();
        for (const m of movimientos) {
          const nombre = m.fondo_nombre ?? `Fondo ${m.id_fondo}`;
          const actual = mapa.get(nombre) ?? { nombre, ingresos: 0, egresos: 0 };
          if (m.tipo === 'Ingreso') actual.ingresos += Number(m.monto);
          else actual.egresos += Number(m.monto);
          mapa.set(nombre, actual);
        }
        this.fondosDetalle.set(Array.from(mapa.values()));
      },
      error: () => {
        this.generando.set(false);
        this.fondosDetalle.set([]);
      }
    });
  }

  cancelar() {
    this.cierreActual.set(null);
    this.fondosDetalle.set([]);
    this.mensajeExito.set('');
  }
}
