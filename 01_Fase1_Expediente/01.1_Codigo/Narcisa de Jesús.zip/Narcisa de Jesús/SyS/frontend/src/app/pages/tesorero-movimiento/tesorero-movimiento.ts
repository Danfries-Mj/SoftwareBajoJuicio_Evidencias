import { Component, OnInit, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { FondosService } from '../../services/fondos.service';
import { MovimientosFinancierosService } from '../../services/movimientos-financieros.service';
import { AuthService } from '../../services/auth.service';
import { Fondo } from '../../models/fondo.model';
import { mensajesTemporales } from '../../shared/utils/mensajes-temporales';
import { autoRecarga } from '../../shared/utils/auto-recarga';
import { categoriasPorTipo, justificacionesPorTipo } from '../../shared/constants/movimiento-financiero-options';

@Component({
  selector: 'app-tesorero-movimiento',
  standalone: true,
  imports: [FormsModule],
  templateUrl: './tesorero-movimiento.html',
  styleUrl: './tesorero-movimiento.css'
})
export class TesoreroMovimientoComponent implements OnInit {
  private fondosService = inject(FondosService);
  private movimientosService = inject(MovimientosFinancierosService);
  private authService = inject(AuthService);

  tipos = ['Ingreso', 'Egreso'];

  fondos = signal<Fondo[]>([]);

  mov = { tipo: '', categoria: '', id_fondo: null as number | null, monto: null as number | null, fecha: '', justificacion: '' };

  guardando = signal(false);
  guardado = signal(false);
  mensajeError = mensajesTemporales(signal(''));

  constructor() {
    autoRecarga(() => this.refrescar());
  }

  ngOnInit() {
    this.cargar();
  }

  private cargar(mostrarError = true) {
    this.fondosService.listar().subscribe({
      next: (fondos) => this.fondos.set(fondos),
      error: () => { if (mostrarError) this.mensajeError.set('No se pudieron cargar los fondos.'); }
    });
  }

  private refrescar() {
    this.cargar(false);
  }

  puedeEditarFondo(f: Fondo): boolean {
    return (f.id_capilla ?? null) === (this.authService.user()?.id_capilla ?? null);
  }

  get categorias(): string[] {
    return categoriasPorTipo(this.mov.tipo);
  }

  get justificaciones(): string[] {
    return justificacionesPorTipo(this.mov.tipo);
  }

  onTipoChange() {
    if (this.mov.categoria && !this.categorias.includes(this.mov.categoria)) {
      this.mov.categoria = '';
    }
    if (this.mov.justificacion && !this.justificaciones.includes(this.mov.justificacion)) {
      this.mov.justificacion = '';
    }
  }

  guardar() {
    this.mensajeError.set('');

    if (!this.mov.tipo || !this.mov.id_fondo || !this.mov.fecha) {
      this.mensajeError.set('Tipo, fondo destino y fecha son obligatorios.');
      return;
    }
    if (!this.mov.monto || this.mov.monto <= 0) {
      this.mensajeError.set('Ingresa un monto válido mayor a cero.');
      return;
    }

    this.guardando.set(true);
    this.movimientosService.crear({
      tipo: this.mov.tipo as 'Ingreso' | 'Egreso',
      categoria: this.mov.categoria || undefined,
      id_fondo: this.mov.id_fondo,
      monto: this.mov.monto,
      fecha: this.mov.fecha,
      justificacion: this.mov.justificacion || undefined
    }).subscribe({
      next: () => {
        this.guardando.set(false);
        this.guardado.set(true);
        this.mov = { tipo: '', categoria: '', id_fondo: null, monto: null, fecha: '', justificacion: '' };
        setTimeout(() => this.guardado.set(false), 3000);
      },
      error: (error) => {
        this.guardando.set(false);
        this.mensajeError.set(error?.error?.mensaje ?? 'No se pudo registrar el movimiento.');
      }
    });
  }
}
