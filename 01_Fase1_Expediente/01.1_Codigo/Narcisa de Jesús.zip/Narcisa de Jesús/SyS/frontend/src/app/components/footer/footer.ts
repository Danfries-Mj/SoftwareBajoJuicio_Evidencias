import { Component, ElementRef, AfterViewInit, OnDestroy, inject } from '@angular/core';

@Component({
  selector: 'app-footer',
  standalone: true,
  templateUrl: './footer.html',
  styleUrl: './footer.css'
})
export class FooterComponent implements AfterViewInit, OnDestroy {
  private elementRef = inject(ElementRef<HTMLElement>);
  private resizeObserver?: ResizeObserver;

  /**
   * El footer es position:fixed (queda estático aunque el contenido tenga
   * scroll propio). El sidebar y el panel de contenido necesitan saber su
   * alto real para reservar exactamente ese espacio, así que se mide y se
   * publica como variable CSS en vez de asumir un valor fijo.
   */
  ngAfterViewInit() {
    const el = this.elementRef.nativeElement;
    this.resizeObserver = new ResizeObserver((entries) => {
      const alto = entries[0]?.contentRect.height ?? el.offsetHeight;
      document.documentElement.style.setProperty('--footer-height', `${alto}px`);
    });
    this.resizeObserver.observe(el);
  }

  ngOnDestroy() {
    this.resizeObserver?.disconnect();
  }
}
