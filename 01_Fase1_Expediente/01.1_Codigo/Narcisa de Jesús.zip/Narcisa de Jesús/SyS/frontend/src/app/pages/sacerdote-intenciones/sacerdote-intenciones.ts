import { Component, inject, OnInit, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { IntencionesMisaService } from '../../services/intenciones-misa.service';
import { EucaristiasService } from '../../services/eucaristias.service';
import { IntencionMisa } from '../../models/intencion-misa.model';
import { Eucaristia } from '../../models/eucaristia.model';
import { mensajesTemporales } from '../../shared/utils/mensajes-temporales';
import { autoRecarga } from '../../shared/utils/auto-recarga';

@Component({
  selector: 'app-sacerdote-intenciones',
  standalone: true,
  imports: [FormsModule],
  templateUrl: './sacerdote-intenciones.html',
  styleUrl: './sacerdote-intenciones.css'
})
export class SacerdoteIntencionesComponent implements OnInit {
  private intencionesService = inject(IntencionesMisaService);
  private eucaristiasService = inject(EucaristiasService);

  guardando = signal(false);
  mensajeError = mensajesTemporales(signal(''));
  mensajeExito = mensajesTemporales(signal(''));

  intenciones = signal<IntencionMisa[]>([]);
  misas = signal<Eucaristia[]>([]);

  showModal = false;
  intencionSeleccionada: IntencionMisa | null = null;
  idEucaristiaElegida: number | '' = '';

  constructor() {
    autoRecarga(() => this.refrescar());
  }

  ngOnInit() {
    this.eucaristiasService.listar().subscribe({ next: (m) => this.misas.set(m) });
    this.cargarIntenciones();
  }

  private cargarIntenciones(mostrarError = true) {
    this.intencionesService.listar().subscribe({
      next: (i) => this.intenciones.set(i),
      error: () => { if (mostrarError) this.mensajeError.set('No se pudieron cargar las intenciones de misa.'); }
    });
  }

  private refrescar() {
    this.cargarIntenciones(false);
  }

  get pendientes(): IntencionMisa[] {
    return this.intenciones().filter(i => i.estado === 'Pendiente');
  }

  get atendidas(): IntencionMisa[] {
    return this.intenciones().filter(i => i.estado !== 'Pendiente');
  }

  solicitanteNombre(i: IntencionMisa): string {
    if (!i.solicitante_nombres) return '—';
    return `${i.solicitante_nombres} ${i.solicitante_apellidos ?? ''}`.trim();
  }

  misaLabel(i: IntencionMisa): string {
    if (!i.id_eucaristia) return '—';
    const m = this.misas().find(x => x.id_eucaristia === i.id_eucaristia);
    return m ? `${m.capilla_nombre ?? ''} · ${m.fecha?.slice(0, 10)} ${m.hora_inicio?.slice(0, 5)}` : `#${i.id_eucaristia}`;
  }

  /**
   * Solo se puede asignar una intención a una misa próxima (fecha >= hoy), con estado
   * Activa, y de la MISMA capilla del solicitante — no tiene sentido ofrecer una misa
   * de otra capilla.
   */
  get misasDisponibles(): Eucaristia[] {
    const hoy = new Date().toISOString().slice(0, 10);
    const idCapilla = this.intencionSeleccionada?.id_capilla ?? null;
    return this.misas().filter(m =>
      m.estado === 'Activa' &&
      m.fecha?.slice(0, 10) >= hoy &&
      (idCapilla == null || m.id_capilla === idCapilla)
    );
  }

  abrirAsignar(i: IntencionMisa) {
    this.intencionSeleccionada = i;
    this.idEucaristiaElegida = '';
    this.mensajeError.set('');
    this.showModal = true;
  }

  /** Igual que asignar, pero para una intención que ya tenía una misa asignada: se abre con la misa actual preseleccionada. */
  editarAsignacion(i: IntencionMisa) {
    this.intencionSeleccionada = i;
    this.idEucaristiaElegida = i.id_eucaristia ?? '';
    this.mensajeError.set('');
    this.showModal = true;
  }

  cerrarModal() {
    this.showModal = false;
    this.intencionSeleccionada = null;
    this.idEucaristiaElegida = '';
  }

  asignar() {
    if (!this.intencionSeleccionada) return;
    if (!this.idEucaristiaElegida) {
      this.mensajeError.set('Selecciona la misa a la que se asignará la intención.');
      return;
    }

    this.guardando.set(true);
    this.intencionesService.asignar(this.intencionSeleccionada.id_intencion, Number(this.idEucaristiaElegida)).subscribe({
      next: () => {
        this.guardando.set(false);
        this.mensajeExito.set('Intención asignada correctamente a la misa.');
        this.cerrarModal();
        this.cargarIntenciones();
      },
      error: (error) => {
        this.guardando.set(false);
        this.mensajeError.set(error?.error?.mensaje ?? 'No se pudo asignar la intención.');
      }
    });
  }

  rechazar(i: IntencionMisa) {
    if (!confirm('¿Rechazar esta intención de misa?')) return;
    this.mensajeError.set('');
    this.mensajeExito.set('');
    this.intencionesService.rechazar(i.id_intencion).subscribe({
      next: () => {
        this.mensajeExito.set('Intención rechazada.');
        this.cargarIntenciones();
      },
      error: (error) => this.mensajeError.set(error?.error?.mensaje ?? 'No se pudo rechazar la intención.')
    });
  }

  closeOnOverlay(e: MouseEvent) {
    if (e.target === e.currentTarget) this.cerrarModal();
  }
}
