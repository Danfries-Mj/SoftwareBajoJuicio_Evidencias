import { effect, WritableSignal } from '@angular/core';

const AUTO_DISMISS_MS = 10000;

/**
 * Envuelve un signal de mensaje (éxito/error) para que se limpie solo a los 10s
 * de mostrarse, sin necesidad de recargar la página ni gestionar el timer a mano.
 */
export function mensajesTemporales(mensaje: WritableSignal<string>, ms = AUTO_DISMISS_MS): WritableSignal<string> {
  effect((onCleanup) => {
    if (mensaje()) {
      const timer = setTimeout(() => mensaje.set(''), ms);
      onCleanup(() => clearTimeout(timer));
    }
  });
  return mensaje;
}
