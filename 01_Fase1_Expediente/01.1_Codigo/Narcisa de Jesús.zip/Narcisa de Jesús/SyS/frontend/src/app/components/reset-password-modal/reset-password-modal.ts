import { Component, effect, inject, signal } from '@angular/core';
import { FormBuilder, ReactiveFormsModule, Validators } from '@angular/forms';
import { ModalService } from '../../services/modal.service';
import { AuthService } from '../../services/auth.service';
import { FormAlertComponent } from '../form-alert/form-alert';
import { codigoRecuperacionValidator, passwordSeguraValidator, passwordsIgualesValidator, mensajeDeError } from '../../shared/utils/validaciones';
import { mensajesTemporales } from '../../shared/utils/mensajes-temporales';

@Component({
  selector: 'app-reset-password-modal',
  standalone: true,
  imports: [ReactiveFormsModule, FormAlertComponent],
  templateUrl: './reset-password-modal.html',
  styleUrl: './reset-password-modal.css'
})
export class ResetPasswordModalComponent {
  protected modalService = inject(ModalService);
  private authService = inject(AuthService);
  private fb = inject(FormBuilder);

  showNueva = false;
  showConfirm = false;
  cargando = signal(false);
  mensajeError = mensajesTemporales(signal(''));
  mensajeExito = mensajesTemporales(signal(''));
  mensajeDeError = mensajeDeError;

  form = this.fb.group(
    {
      correo: ['', [Validators.required, Validators.email]],
      codigo: ['', [Validators.required, codigoRecuperacionValidator()]],
      nuevaContrasena: ['', [Validators.required, passwordSeguraValidator()]],
      confirmContrasena: ['', [Validators.required]]
    },
    { validators: passwordsIgualesValidator('nuevaContrasena', 'confirmContrasena') }
  );

  constructor() {
    effect(() => {
      const correo = this.modalService.correoRecuperacion();
      if (correo) this.form.controls.correo.setValue(correo);
    });
  }

  confirmar() {
    if (this.form.invalid) {
      this.form.markAllAsTouched();
      this.mensajeError.set(
        this.form.errors?.['passwordsNoCoinciden']
          ? 'Las contraseñas no coinciden.'
          : 'Revisa los campos marcados en rojo.'
      );
      return;
    }

    const { correo, codigo, nuevaContrasena } = this.form.getRawValue();
    this.mensajeError.set('');
    this.cargando.set(true);
    this.authService.restablecerContrasena({ correo: correo!, codigo: codigo!, contrasena: nuevaContrasena! }).subscribe({
      next: (respuesta) => {
        this.cargando.set(false);
        this.mensajeExito.set(respuesta?.mensaje ?? 'Contraseña actualizada correctamente.');
        setTimeout(() => {
          this.form.reset();
          this.showNueva = false;
          this.showConfirm = false;
          this.modalService.openLogin();
        }, 1200);
      },
      error: (error) => {
        this.cargando.set(false);
        this.mensajeError.set(error?.error?.mensaje ?? 'El código es inválido o expiró. Solicita uno nuevo.');
      }
    });
  }

  volverASolicitar() {
    this.modalService.openForgotPassword();
  }

  cerrar() {
    this.form.reset();
    this.showNueva = false;
    this.showConfirm = false;
    this.mensajeError.set('');
    this.mensajeExito.set('');
    this.modalService.closeAll();
  }

  closeOnOverlay(event: MouseEvent) {
    if (event.target === event.currentTarget) {
      this.cerrar();
    }
  }
}
