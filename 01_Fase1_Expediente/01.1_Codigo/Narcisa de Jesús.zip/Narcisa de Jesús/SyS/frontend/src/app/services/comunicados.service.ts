import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable, map } from 'rxjs';
import { API_URL } from '../core/config/api.config';
import { Comunicado } from '../models/comunicado.model';

@Injectable({ providedIn: 'root' })
export class ComunicadosService {
  private apiUrl = `${API_URL}/comunicados`;
  private adminUrl = `${API_URL}/admin/comunicados`;

  constructor(private http: HttpClient) {}

  listarPublicos(idCapilla?: number): Observable<Comunicado[]> {
    let params = new HttpParams();
    if (idCapilla) params = params.set('id_capilla', idCapilla);

    return this.http.get<{ mensaje: string; total: number; comunicados: Comunicado[] }>(this.apiUrl, { params })
      .pipe(map(respuesta => respuesta.comunicados));
  }

  listar(filtros: { id_capilla?: number; estado?: string } = {}): Observable<Comunicado[]> {
    let params = new HttpParams();
    if (filtros.id_capilla) params = params.set('id_capilla', filtros.id_capilla);
    if (filtros.estado) params = params.set('estado', filtros.estado);

    return this.http.get<{ mensaje: string; total: number; comunicados: Comunicado[] }>(this.adminUrl, { params })
      .pipe(map(respuesta => respuesta.comunicados));
  }

  obtenerPorId(id: number): Observable<Comunicado> {
    return this.http.get<{ mensaje: string; comunicado: Comunicado }>(`${this.adminUrl}/${id}`)
      .pipe(map(respuesta => respuesta.comunicado));
  }

  crear(datos: { titulo: string; mensaje: string; id_capilla?: number | null; estado?: string }): Observable<Comunicado> {
    return this.http.post<{ mensaje: string; comunicado: Comunicado }>(this.adminUrl, datos)
      .pipe(map(respuesta => respuesta.comunicado));
  }

  editar(id: number, datos: { titulo: string; mensaje: string; id_capilla?: number | null; estado?: string }): Observable<Comunicado> {
    return this.http.put<{ mensaje: string; comunicado: Comunicado }>(`${this.adminUrl}/${id}`, datos)
      .pipe(map(respuesta => respuesta.comunicado));
  }

  eliminar(id: number): Observable<{ mensaje: string; comunicado: Comunicado }> {
    return this.http.delete<{ mensaje: string; comunicado: Comunicado }>(`${this.adminUrl}/${id}`);
  }
}
