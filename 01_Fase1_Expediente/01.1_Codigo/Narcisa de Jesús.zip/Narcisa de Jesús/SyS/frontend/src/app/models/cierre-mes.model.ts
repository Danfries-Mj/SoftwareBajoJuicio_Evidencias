export interface CierreMes {
  id_cierre: number;
  mes: number;
  anio: number;
  total_ingresos?: number;
  total_egresos?: number;
  estado: string;
  fecha_generacion?: string;
  generado_por?: number;
  id_capilla?: number | null;
  capilla_nombre?: string | null;
}
