import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable, map } from 'rxjs';
import { API_URL } from '../core/config/api.config';
import { Eucaristia } from '../models/eucaristia.model';

@Injectable({ providedIn: 'root' })
export class EucaristiasService {
  private apiUrl = `${API_URL}/eucaristias`;

  constructor(private http: HttpClient) {}

  listar(filtros: { id_capilla?: number; dia_semana?: string; estado?: string } = {}): Observable<Eucaristia[]> {
    let params = new HttpParams();
    if (filtros.id_capilla) params = params.set('id_capilla', filtros.id_capilla);
    if (filtros.dia_semana) params = params.set('dia_semana', filtros.dia_semana);
    if (filtros.estado) params = params.set('estado', filtros.estado);

    return this.http.get<{ mensaje: string; total: number; eucaristias: Eucaristia[] }>(this.apiUrl, { params })
      .pipe(map(respuesta => respuesta.eucaristias));
  }

  obtenerPorId(id: number): Observable<Eucaristia> {
    return this.http.get<{ mensaje: string; eucaristia: Eucaristia }>(`${this.apiUrl}/${id}`)
      .pipe(map(respuesta => respuesta.eucaristia));
  }

  crear(datos: Partial<Eucaristia>): Observable<Eucaristia> {
    return this.http.post<{ mensaje: string; eucaristia: Eucaristia }>(this.apiUrl, datos)
      .pipe(map(respuesta => respuesta.eucaristia));
  }

  editar(id: number, datos: Partial<Eucaristia>): Observable<Eucaristia> {
    return this.http.put<{ mensaje: string; eucaristia: Eucaristia }>(`${this.apiUrl}/${id}`, datos)
      .pipe(map(respuesta => respuesta.eucaristia));
  }

  eliminar(id: number): Observable<{ mensaje: string; eucaristia: Eucaristia }> {
    return this.http.delete<{ mensaje: string; eucaristia: Eucaristia }>(`${this.apiUrl}/${id}`);
  }

  /** Marca en bloque como "Realizada" toda misa Activa/Programada cuya fecha y hora ya pasaron. */
  marcarRealizadas(): Observable<{ mensaje: string; total: number }> {
    return this.http.put<{ mensaje: string; total: number }>(`${this.apiUrl}/marcar-realizadas`, {});
  }
}
