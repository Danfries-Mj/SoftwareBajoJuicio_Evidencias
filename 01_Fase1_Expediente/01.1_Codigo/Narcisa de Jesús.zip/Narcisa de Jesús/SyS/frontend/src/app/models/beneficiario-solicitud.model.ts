export type RolBeneficiario = 'Bautizando' | 'Tercero' | 'Conyuge';

export interface BeneficiarioSolicitud {
  id_beneficiario: number;
  id_solicitud: number;
  rol_beneficiario: RolBeneficiario;
  nombres?: string;
  apellidos?: string;
  cedula?: string;
  id_persona?: number | null;
}
