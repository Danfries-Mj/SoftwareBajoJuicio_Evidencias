export type TipoIntencion = 'Por Difunto' | 'Por matrimonio' | 'Por nacimiento';
export type EstadoIntencion = 'Pendiente' | 'Asignada' | 'Rechazada';

export interface IntencionMisa {
  id_intencion: number;
  id_usuario: number;
  nombre_mencionar: string;
  tipo: TipoIntencion;
  fecha_deseada: string;
  id_eucaristia?: number | null;
  estado: EstadoIntencion;
  solicitante_nombres?: string;
  solicitante_apellidos?: string;
  id_capilla?: number | null;
}
