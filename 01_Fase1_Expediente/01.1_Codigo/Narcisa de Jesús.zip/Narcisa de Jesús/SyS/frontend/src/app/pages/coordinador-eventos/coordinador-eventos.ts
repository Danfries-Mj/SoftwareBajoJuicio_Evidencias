import { Component, OnInit, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { SlicePipe } from '@angular/common';
import { AuthService } from '../../services/auth.service';
import { EventosService } from '../../services/eventos.service';
import { Evento } from '../../models/evento.model';
import { mensajesTemporales } from '../../shared/utils/mensajes-temporales';
import { autoRecarga } from '../../shared/utils/auto-recarga';
import { OPCIONES_HORA } from '../../shared/utils/horarios-disponibles';

@Component({
  selector: 'app-coordinador-eventos',
  standalone: true,
  imports: [FormsModule, SlicePipe],
  templateUrl: './coordinador-eventos.html',
  styleUrl: './coordinador-eventos.css'
})
export class CoordinadorEventosComponent implements OnInit {
  private authService = inject(AuthService);
  private eventosService = inject(EventosService);

  showModal = false;
  guardando = signal(false);
  mensajeError = mensajesTemporales(signal(''));
  mensajeExito = mensajesTemporales(signal(''));

  semana = ['LU', 'MA', 'MI', 'JU', 'VI', 'SÁ', 'DO'];

  private today = new Date();
  private displayYear = this.today.getFullYear();
  private displayMonth = this.today.getMonth();

  diasCalendario: (number | null)[] = [];
  monthLabel = '';
  diasConEvento = new Set<number>();
  hoy = this.today.getDate();

  eventos = signal<Evento[]>([]);
  proximos = signal<Evento[]>([]);

  tipos = ['Capilla'];
  opcionesHora = OPCIONES_HORA;
  nuevo: Partial<Evento> = {};
  editando: Evento | null = null;

  get capilla() { return this.authService.user()?.capilla ?? ''; }

  constructor() {
    autoRecarga(() => this.refrescar());
  }

  ngOnInit() {
    this.recalcularCalendario();
    this.cargarEventos();
  }

  private refrescar() {
    this.cargarEventos(false);
  }

  private fechaISO(e: Evento): string {
    return (e.fecha || '').slice(0, 10);
  }

  private cargarEventos(mostrarError = true) {
    const idCapilla = this.authService.user()?.id_capilla ?? undefined;
    this.eventosService.listar({ id_capilla: idCapilla }).subscribe({
      next: (eventos) => {
        this.eventos.set(eventos);
        this.actualizarDerivados();
      },
      error: () => { if (mostrarError) this.mensajeError.set('No se pudieron cargar los eventos de la capilla.'); }
    });
  }

  private actualizarDerivados() {
    this.diasConEvento.clear();
    for (const e of this.eventos()) {
      const f = this.fechaISO(e);
      const fecha = new Date(f + 'T00:00:00');
      if (fecha.getFullYear() === this.displayYear && fecha.getMonth() === this.displayMonth) {
        this.diasConEvento.add(fecha.getDate());
      }
    }

    const hoyStr = new Date().toISOString().slice(0, 10);
    this.proximos.set(
      this.eventos()
        .filter(e => this.fechaISO(e) >= hoyStr)
        .sort((a, b) => this.fechaISO(a).localeCompare(this.fechaISO(b)))
        .slice(0, 3)
    );
  }

  private recalcularCalendario() {
    this.diasCalendario = this.construirCalendario(this.displayYear, this.displayMonth);
    const fecha = new Date(this.displayYear, this.displayMonth, 1);
    this.monthLabel = fecha.toLocaleDateString('es-ES', { month: 'long', year: 'numeric' });
  }

  private construirCalendario(year: number, month: number): (number | null)[] {
    const primerDia = new Date(year, month, 1);
    const offsetInicio = (primerDia.getDay() + 6) % 7;
    const diasDelMes = new Date(year, month + 1, 0).getDate();

    const dias: (number | null)[] = new Array(offsetInicio).fill(null);
    for (let dia = 1; dia <= diasDelMes; dia++) dias.push(dia);
    while (dias.length % 7 !== 0) dias.push(null);
    return dias;
  }

  colorProximo(index: number): string {
    return ['purple', 'lavender', 'blue'][index % 3];
  }

  metaProximo(e: Evento): string {
    const fecha = new Date(this.fechaISO(e) + 'T00:00:00');
    const texto = fecha.toLocaleDateString('es-ES', { weekday: 'short', day: 'numeric', month: 'short' });
    const hora = e.hora_inicio ? ` · ${e.hora_inicio.slice(0, 5)}` : '';
    return `${texto}${hora} · ${e.tipo_ambito}`;
  }

  esEditable(e: Evento): boolean {
    const idCapilla = this.authService.user()?.id_capilla;
    return e.tipo_ambito === 'Capilla' && !!idCapilla && Number(e.id_capilla) === Number(idCapilla);
  }

  openModal() {
    this.nuevo = { tipo_ambito: 'Capilla', categoria: 'Evento' };
    this.editando = null;
    this.mensajeError.set('');
    this.showModal = true;
  }

  editar(e: Evento) {
    this.nuevo = { ...e, fecha: e.fecha?.slice(0, 10), hora_inicio: e.hora_inicio?.slice(0, 5), hora_fin: e.hora_fin?.slice(0, 5) };
    this.editando = e;
    this.mensajeError.set('');
    this.showModal = true;
  }

  guardar() {
    this.mensajeError.set('');

    if (!this.nuevo.nombre?.trim() || !this.nuevo.fecha) {
      this.mensajeError.set('El nombre del evento y la fecha son obligatorios.');
      return;
    }

    const hoy = new Date();
    hoy.setHours(0, 0, 0, 0);
    const fechaEvento = new Date(this.nuevo.fecha + 'T00:00:00');
    if (fechaEvento < hoy) {
      this.mensajeError.set('La fecha del evento no puede ser anterior a la fecha actual.');
      return;
    }
    if (this.nuevo.hora_inicio && this.nuevo.hora_fin && this.nuevo.hora_inicio >= this.nuevo.hora_fin) {
      this.mensajeError.set('La hora de inicio debe ser anterior a la hora de fin.');
      return;
    }

    const idCapilla = this.authService.user()?.id_capilla;
    if (!idCapilla) {
      this.mensajeError.set('No tienes una capilla asignada.');
      return;
    }

    const payload: Partial<Evento> = {
      nombre: this.nuevo.nombre.trim(),
      tipo_ambito: 'Capilla',
      categoria: this.nuevo.categoria || 'Evento',
      id_capilla: idCapilla,
      fecha: this.nuevo.fecha,
      hora_inicio: this.nuevo.hora_inicio || undefined,
      hora_fin: this.nuevo.hora_fin || undefined,
      lugar: this.nuevo.lugar || undefined,
      capacidad: this.nuevo.capacidad || undefined,
      descripcion: this.nuevo.descripcion || undefined
    };

    this.guardando.set(true);
    const obs = this.editando
      ? this.eventosService.editar(this.editando.id_evento, payload)
      : this.eventosService.crear(payload);

    obs.subscribe({
      next: () => {
        this.guardando.set(false);
        this.mensajeExito.set(this.editando ? 'Evento actualizado correctamente.' : 'Evento creado correctamente.');
        this.editando = null;
        this.nuevo = {};
        this.showModal = false;
        this.cargarEventos();
      },
      error: (error) => {
        this.guardando.set(false);
        this.mensajeError.set(error?.error?.mensaje ?? 'No se pudo guardar el evento.');
      }
    });
  }

  closeOnOverlay(e: MouseEvent) {
    if (e.target === e.currentTarget) this.showModal = false;
  }
}
