import { Component, inject, OnInit, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { CapillasService } from '../../services/capillas.service';
import { UsuariosService, NuevoUsuario } from '../../services/usuarios.service';
import { Capilla } from '../../models/capilla.model';
import { Usuario } from '../../models/usuario.model';
import { mensajesTemporales } from '../../shared/utils/mensajes-temporales';
import { autoRecarga } from '../../shared/utils/auto-recarga';
import { soloDigitos } from '../../shared/utils/validaciones';
@Component({
  selector: 'app-sacerdote-usuarios',
  standalone: true,
  imports: [FormsModule],
  templateUrl: './sacerdote-usuarios.html',
  styleUrl: './sacerdote-usuarios.css'
})
export class SacerdoteUsuariosComponent implements OnInit {
  private capillasService = inject(CapillasService);
  private usuariosService = inject(UsuariosService);
  protected soloDigitos = soloDigitos;

  showModal = false;
  editando: Usuario | null = null;
  guardando = signal(false);
  mensajeError = mensajesTemporales(signal(''));

  usuarios = signal<Usuario[]>([]);
  capillas = signal<Capilla[]>([]);

  // Para el filtro de la lista: incluye "Sacerdote" para poder ubicar esa cuenta.
  roles = ['Laico', 'Catequista', 'Coordinador', 'Tesorero', 'Sacerdote'];
  // Para "Nuevo usuario" y "Editar": el rol Sacerdote es único e irrepetible en la
  // parroquia y ya está asignado desde el sistema, así que no se ofrece aquí.
  rolesAsignables = ['Laico', 'Catequista', 'Coordinador', 'Tesorero'];

  nuevo: Partial<NuevoUsuario> = {};
  edicion: { rol: string; id_capilla: number | null; activo: boolean } = { rol: 'Laico', id_capilla: null, activo: true };

  filtroNombre = '';
  filtroApellido = '';
  filtroRol = '';
  filtroCapilla: number | null = null;

  constructor() {
    autoRecarga(() => this.refrescar());
  }

  ngOnInit() {
    this.capillasService.listar().subscribe({ next: (c) => this.capillas.set(c) });
    this.cargarUsuarios();
  }

  private cargarUsuarios(mostrarError = true) {
    this.usuariosService.listar().subscribe({
      next: (u) => this.usuarios.set(u),
      error: () => { if (mostrarError) this.mensajeError.set('No se pudieron cargar los usuarios.'); }
    });
  }

  private refrescar() {
    this.cargarUsuarios(false);
  }

  get totalUsuarios(): number {
    return this.usuarios().length;
  }

  get totalLaicos(): number {
    return this.usuarios().filter(u => u.rol === 'Laico').length;
  }

  get totalCatequistas(): number {
    return this.usuarios().filter(u => u.rol === 'Catequista').length;
  }

  get nuevosEsteMes(): number {
    const hoy = new Date();
    return this.usuarios().filter(u => {
      if (!u.fecha_registro) return false;
      const f = new Date(u.fecha_registro);
      return f.getFullYear() === hoy.getFullYear() && f.getMonth() === hoy.getMonth();
    }).length;
  }

  capillaNombre(u: Usuario): string {
    return u.capilla_nombre ?? this.capillas().find(c => c.id_capilla === u.id_capilla)?.nombre ?? '—';
  }

  /**
   * Opciones del select "Rol" al editar: nunca se puede asignar "Sacerdote" a nadie
   * (es único e irrepetible). Si la cuenta que se está editando YA es el Sacerdote,
   * se muestra esa única opción (bloqueada más abajo) para no dejar el select vacío.
   */
  get opcionesRolEdicion(): string[] {
    return this.editando?.rol === 'Sacerdote' ? ['Sacerdote'] : this.rolesAsignables;
  }

  get usuariosFiltrados(): Usuario[] {
    const nombre = this.filtroNombre.trim().toLowerCase();
    const apellido = this.filtroApellido.trim().toLowerCase();

    return this.usuarios().filter(u => {
      if (nombre && !u.nombres.toLowerCase().includes(nombre)) return false;
      if (apellido && !u.apellidos.toLowerCase().includes(apellido)) return false;
      if (this.filtroRol && u.rol !== this.filtroRol) return false;
      if (this.filtroCapilla !== null && u.id_capilla !== this.filtroCapilla) return false;
      return true;
    });
  }

  get hayFiltrosActivos(): boolean {
    return !!(this.filtroNombre || this.filtroApellido || this.filtroRol || this.filtroCapilla !== null);
  }

  limpiarFiltros() {
    this.filtroNombre = '';
    this.filtroApellido = '';
    this.filtroRol = '';
    this.filtroCapilla = null;
  }

  openModal() {
    this.editando = null;
    this.nuevo = { rol: 'Laico', id_capilla: null };
    this.mensajeError.set('');
    this.showModal = true;
  }

  editar(u: Usuario) {
    this.editando = u;
    this.edicion = { rol: u.rol, id_capilla: u.id_capilla, activo: u.activo };
    this.mensajeError.set('');
    this.showModal = true;
  }

  toggleActivo(u: Usuario) {
    const accion = u.activo ? this.usuariosService.desactivar(u.id_usuario) : this.usuariosService.activar(u.id_usuario);
    accion.subscribe({
      next: () => this.cargarUsuarios(),
      error: (error) => this.mensajeError.set(error?.error?.mensaje ?? 'No se pudo cambiar el estado del usuario.')
    });
  }

  guardar() {
    this.mensajeError.set('');

    if (this.editando) {
      if (!this.edicion.rol) {
        this.mensajeError.set('El rol es obligatorio.');
        return;
      }
      this.guardando.set(true);
      this.usuariosService.editar(this.editando.id_usuario, {
        rol: this.edicion.rol,
        id_capilla: this.edicion.id_capilla,
        activo: this.edicion.activo
      }).subscribe({
        next: () => {
          this.guardando.set(false);
          this.showModal = false;
          this.editando = null;
          this.cargarUsuarios();
        },
        error: (error) => {
          this.guardando.set(false);
          this.mensajeError.set(error?.error?.mensaje ?? 'No se pudo actualizar el usuario.');
        }
      });
      return;
    }

    if (!this.nuevo.nombres || !this.nuevo.apellidos || !this.nuevo.cedula || !this.nuevo.correo || !this.nuevo.contrasena || !this.nuevo.rol) {
      this.mensajeError.set('Nombres, apellidos, cédula, correo, contraseña y rol son obligatorios.');
      return;
    }
    if (!/^\d{10}$/.test(this.nuevo.cedula)) {
      this.mensajeError.set('La cédula debe tener exactamente 10 dígitos.');
      return;
    }

    const cantidadNombres = this.nuevo.nombres.trim().split(/\s+/).filter(Boolean).length;
    if (cantidadNombres < 1 || cantidadNombres > 2) {
      this.mensajeError.set('Ingresa 1 o 2 nombres.');
      return;
    }
    const cantidadApellidos = this.nuevo.apellidos.trim().split(/\s+/).filter(Boolean).length;
    if (cantidadApellidos !== 2) {
      this.mensajeError.set('Ingresa los 2 apellidos.');
      return;
    }

    this.guardando.set(true);
    this.usuariosService.crear({
      cedula: this.nuevo.cedula,
      nombres: this.nuevo.nombres,
      apellidos: this.nuevo.apellidos,
      telefono: this.nuevo.telefono,
      correo: this.nuevo.correo,
      contrasena: this.nuevo.contrasena,
      rol: this.nuevo.rol,
      id_capilla: this.nuevo.id_capilla ?? null
    }).subscribe({
      next: () => {
        this.guardando.set(false);
        this.showModal = false;
        this.nuevo = {};
        this.cargarUsuarios();
      },
      error: (error) => {
        this.guardando.set(false);
        this.mensajeError.set(error?.error?.mensaje ?? 'No se pudo crear el usuario.');
      }
    });
  }

  closeOnOverlay(e: MouseEvent) {
    if (e.target === e.currentTarget) this.showModal = false;
  }
}
