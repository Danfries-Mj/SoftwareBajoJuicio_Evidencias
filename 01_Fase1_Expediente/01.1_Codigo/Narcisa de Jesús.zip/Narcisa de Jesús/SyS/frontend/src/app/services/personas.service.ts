import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, map } from 'rxjs';
import { API_URL } from '../core/config/api.config';
import { Persona } from '../models/persona.model';

@Injectable({ providedIn: 'root' })
export class PersonasService {
  private apiUrl = `${API_URL}/personas`;

  constructor(private http: HttpClient) {}

  listar(): Observable<Persona[]> {
    return this.http.get<{ mensaje: string; total: number; personas: Persona[] }>(this.apiUrl)
      .pipe(map(respuesta => respuesta.personas));
  }

  buscarPorId(id: number): Observable<Persona> {
    return this.http.get<{ mensaje: string; persona: Persona }>(`${this.apiUrl}/${id}`)
      .pipe(map(respuesta => respuesta.persona));
  }

  buscarPorCedula(cedula: string): Observable<Persona> {
    return this.http.get<{ mensaje: string; persona: Persona }>(`${this.apiUrl}/cedula/${cedula}`)
      .pipe(map(respuesta => respuesta.persona));
  }

  crear(datos: { cedula: string; nombres: string; apellidos: string; telefono?: string }): Observable<Persona> {
    return this.http.post<{ mensaje: string; persona: Persona }>(this.apiUrl, datos)
      .pipe(map(respuesta => respuesta.persona));
  }

  editar(id: number, datos: { nombres: string; apellidos: string; telefono?: string }): Observable<Persona> {
    return this.http.put<{ mensaje: string; persona: Persona }>(`${this.apiUrl}/${id}`, datos)
      .pipe(map(respuesta => respuesta.persona));
  }

  eliminar(id: number): Observable<{ mensaje: string; persona: Persona }> {
    return this.http.delete<{ mensaje: string; persona: Persona }>(`${this.apiUrl}/${id}`);
  }
}
