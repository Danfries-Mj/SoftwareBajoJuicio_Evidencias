import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable, map } from 'rxjs';
import { API_URL } from '../core/config/api.config';
import { SolicitudSacramento } from '../models/solicitud-sacramento.model';

@Injectable({ providedIn: 'root' })
export class SolicitudesSacramentoService {
  private apiUrl = `${API_URL}/solicitudes-sacramento`;

  constructor(private http: HttpClient) {}

  listar(filtros: { sacramento?: string; estado?: string } = {}): Observable<SolicitudSacramento[]> {
    let params = new HttpParams();
    if (filtros.sacramento) params = params.set('sacramento', filtros.sacramento);
    if (filtros.estado) params = params.set('estado', filtros.estado);

    return this.http.get<{ mensaje: string; total: number; solicitudes: SolicitudSacramento[] }>(this.apiUrl, { params })
      .pipe(map(respuesta => respuesta.solicitudes));
  }

  obtenerPorId(id: number): Observable<SolicitudSacramento> {
    return this.http.get<{ mensaje: string; solicitud: SolicitudSacramento }>(`${this.apiUrl}/${id}`)
      .pipe(map(respuesta => respuesta.solicitud));
  }

  crear(datos: { sacramento: string; modalidad?: string; id_capilla?: number | null; id_documento?: number | null }): Observable<SolicitudSacramento> {
    return this.http.post<{ mensaje: string; solicitud: SolicitudSacramento }>(this.apiUrl, datos)
      .pipe(map(respuesta => respuesta.solicitud));
  }

  asignar(id: number, datos: { fecha_asignada: string; hora_inicio?: string; hora_fin?: string; id_capilla?: number | null }): Observable<SolicitudSacramento> {
    return this.http.put<{ mensaje: string; solicitud: SolicitudSacramento }>(`${this.apiUrl}/${id}/asignar`, datos)
      .pipe(map(respuesta => respuesta.solicitud));
  }

  aprobar(id: number): Observable<SolicitudSacramento> {
    return this.http.put<{ mensaje: string; solicitud: SolicitudSacramento }>(`${this.apiUrl}/${id}/aprobar`, {})
      .pipe(map(respuesta => respuesta.solicitud));
  }

  rechazar(id: number): Observable<SolicitudSacramento> {
    return this.http.put<{ mensaje: string; solicitud: SolicitudSacramento }>(`${this.apiUrl}/${id}/rechazar`, {})
      .pipe(map(respuesta => respuesta.solicitud));
  }

  eliminar(id: number): Observable<{ mensaje: string; solicitud: SolicitudSacramento }> {
    return this.http.delete<{ mensaje: string; solicitud: SolicitudSacramento }>(`${this.apiUrl}/${id}`);
  }

  /** Indica si esa cédula ya tiene una solicitud de ese sacramento en estado 'Atendida'. */
  verificarDuplicada(cedula: string, sacramento: string): Observable<boolean> {
    const params = new HttpParams().set('cedula', cedula).set('sacramento', sacramento);
    return this.http.get<{ mensaje: string; duplicada: boolean }>(`${this.apiUrl}/verificar-duplicada`, { params })
      .pipe(map(respuesta => respuesta.duplicada));
  }
}
