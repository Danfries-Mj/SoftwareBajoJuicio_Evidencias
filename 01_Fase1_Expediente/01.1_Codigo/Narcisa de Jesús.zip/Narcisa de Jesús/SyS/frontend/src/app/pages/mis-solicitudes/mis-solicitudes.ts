import { Component, inject, OnInit, signal } from '@angular/core';
import { SlicePipe } from '@angular/common';
import { forkJoin } from 'rxjs';
import { InscripcionesCatequesisService } from '../../services/inscripciones-catequesis.service';
import { SolicitudesSacramentoService } from '../../services/solicitudes-sacramento.service';
import { IntencionesMisaService } from '../../services/intenciones-misa.service';
import { CapillasService } from '../../services/capillas.service';
import { mensajesTemporales } from '../../shared/utils/mensajes-temporales';

interface SolicitudUnificada {
  origen: 'Catequesis' | 'Sacramento' | 'Intención de misa';
  tipo: string;
  detalle: string;
  fecha: string;
  estado: string;
}

@Component({
  selector: 'app-mis-solicitudes',
  standalone: true,
  imports: [SlicePipe],
  templateUrl: './mis-solicitudes.html',
  styleUrl: './mis-solicitudes.css'
})
export class MisSolicitudesComponent implements OnInit {
  private inscripcionesService = inject(InscripcionesCatequesisService);
  private solicitudesSacramentoService = inject(SolicitudesSacramentoService);
  private intencionesService = inject(IntencionesMisaService);
  private capillasService = inject(CapillasService);

  solicitudes = signal<SolicitudUnificada[]>([]);
  mensajeError = mensajesTemporales(signal(''));
  private capillasMap = new Map<number, string>();

  ngOnInit() {
    this.capillasService.listar().subscribe({
      next: (capillas) => capillas.forEach(c => this.capillasMap.set(c.id_capilla, c.nombre))
    });

    forkJoin({
      catequesis: this.inscripcionesService.listar(),
      sacramentos: this.solicitudesSacramentoService.listar(),
      intenciones: this.intencionesService.listar()
    }).subscribe({
      next: ({ catequesis, sacramentos, intenciones }) => {
        const unificadas: SolicitudUnificada[] = [
          ...catequesis.map((c): SolicitudUnificada => ({
            origen: 'Catequesis',
            tipo: c.nivel,
            detalle: this.capillasMap.get(c.id_capilla) ?? '—',
            fecha: c.fecha_solicitud ?? '',
            estado: c.estado
          })),
          ...sacramentos.map((s): SolicitudUnificada => ({
            origen: 'Sacramento',
            tipo: s.sacramento,
            detalle: s.fecha_asignada ? `Fecha asignada: ${s.fecha_asignada.slice(0, 10)}` : (s.capilla_nombre ?? '—'),
            fecha: s.fecha_solicitud ?? '',
            estado: s.estado
          })),
          ...intenciones.map((i): SolicitudUnificada => ({
            origen: 'Intención de misa',
            tipo: i.tipo,
            detalle: `Por: ${i.nombre_mencionar} · Fecha deseada: ${i.fecha_deseada?.slice(0, 10)}`,
            fecha: i.fecha_deseada ?? '',
            estado: i.estado
          }))
        ].sort((a, b) => (b.fecha ?? '').localeCompare(a.fecha ?? ''));

        this.solicitudes.set(unificadas);
      },
      error: () => this.mensajeError.set('No se pudo cargar tus solicitudes.')
    });
  }
}
