import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, map } from 'rxjs';
import { API_URL } from '../core/config/api.config';
import { Documento } from '../models/documento.model';

@Injectable({ providedIn: 'root' })
export class DocumentosService {
  private apiUrl = `${API_URL}/documentos`;

  constructor(private http: HttpClient) {}

  listar(): Observable<Documento[]> {
    return this.http.get<{ mensaje: string; total: number; documentos: Documento[] }>(this.apiUrl)
      .pipe(map(respuesta => respuesta.documentos));
  }

  obtenerPorId(id: number): Observable<Documento> {
    return this.http.get<{ mensaje: string; documento: Documento }>(`${this.apiUrl}/${id}`)
      .pipe(map(respuesta => respuesta.documento));
  }

  crear(datos: { tipo?: string; archivo_nombre: string; archivo_url: string; mime_type?: string }): Observable<Documento> {
    return this.http.post<{ mensaje: string; documento: Documento }>(this.apiUrl, datos)
      .pipe(map(respuesta => respuesta.documento));
  }

  eliminar(id: number): Observable<{ mensaje: string; documento: Documento }> {
    return this.http.delete<{ mensaje: string; documento: Documento }>(`${this.apiUrl}/${id}`);
  }
}

interface ArchivoConDataUri {
  archivo_url?: string;
  mime_type?: string;
}

/**
 * Convierte el data URI (base64) de un archivo adjunto a un blob: URL.
 *
 * No se usa `window.open('', '_blank') + document.write(<iframe src="data:...">)`
 * ni un `<a href="data:...">` directo porque con archivos grandes (ej. un PDF de
 * un par de MB) ese patrón es poco confiable entre navegadores: el data URI
 * embebido como atributo puede fallar silenciosamente y la pestaña/descarga queda
 * en blanco o corrupta. Convertir a Blob es el patrón estándar y funciona igual
 * para imágenes y PDFs, sin importar el tamaño del archivo.
 */
function dataUriABlobUrl(archivo: ArchivoConDataUri): string | null {
  if (!archivo.archivo_url) return null;

  const separador = archivo.archivo_url.indexOf(',');
  if (separador === -1) return null;

  const meta = archivo.archivo_url.slice(0, separador);
  const base64 = archivo.archivo_url.slice(separador + 1);
  const mimeMatch = /data:([^;]+);base64/.exec(meta);
  const mime = mimeMatch?.[1] || archivo.mime_type || 'application/octet-stream';

  const binario = atob(base64);
  const bytes = new Uint8Array(binario.length);
  for (let i = 0; i < binario.length; i++) {
    bytes[i] = binario.charCodeAt(i);
  }

  const blob = new Blob([bytes], { type: mime });
  return URL.createObjectURL(blob);
}

/**
 * Abre una pestaña en blanco de forma síncrona (debe llamarse directamente dentro
 * del manejador de clic, antes de cualquier `await`/petición HTTP) para que el
 * navegador no la bloquee como pop-up. Úsala junto con `abrirDocumentoEnNuevaPestana`
 * pasándole la ventana ya abierta una vez llega la respuesta del backend.
 */
export function abrirPestanaEnBlanco(): Window | null {
  return window.open('', '_blank');
}

/** Abre el archivo (data URI base64) de un documento en una pestaña nueva. */
export function abrirDocumentoEnNuevaPestana(doc: ArchivoConDataUri, ventana?: Window | null): void {
  const url = dataUriABlobUrl(doc);
  if (!url) {
    ventana?.close();
    return;
  }

  if (ventana) {
    ventana.location.href = url;
  } else {
    window.open(url, '_blank');
  }
  setTimeout(() => URL.revokeObjectURL(url), 60_000);
}

/** Descarga el archivo (data URI base64) de un documento con el nombre indicado. */
export function descargarDocumento(doc: ArchivoConDataUri, nombreArchivo: string): void {
  const url = dataUriABlobUrl(doc);
  if (!url) return;

  const a = document.createElement('a');
  a.href = url;
  a.download = nombreArchivo;
  a.click();
  setTimeout(() => URL.revokeObjectURL(url), 60_000);
}
