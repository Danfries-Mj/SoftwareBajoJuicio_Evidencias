/** Horas disponibles en intervalos de 30 minutos (00:00 - 23:30). */
export const OPCIONES_HORA: string[] = Array.from({ length: 48 }, (_, i) => {
  const horas = Math.floor(i / 2);
  const minutos = i % 2 === 0 ? '00' : '30';
  return `${String(horas).padStart(2, '0')}:${minutos}`;
});
