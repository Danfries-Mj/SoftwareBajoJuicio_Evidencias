import { Component, inject, OnInit, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { CapillasService } from '../../services/capillas.service';
import { EucaristiasService } from '../../services/eucaristias.service';
import { Capilla } from '../../models/capilla.model';
import { Eucaristia } from '../../models/eucaristia.model';
import { mensajesTemporales } from '../../shared/utils/mensajes-temporales';
import { autoRecarga } from '../../shared/utils/auto-recarga';
import { OPCIONES_HORA } from '../../shared/utils/horarios-disponibles';
import { formatearFecha } from '../../shared/utils/date-format';
const DIAS_LABEL: Record<string, string> = {
  Domingo: 'Domingo', Lunes: 'Lunes', Martes: 'Martes',
  Miercoles: 'Miércoles', Jueves: 'Jueves', Viernes: 'Viernes', Sabado: 'Sábado'
};
const DIAS_POR_INDICE = ['Domingo', 'Lunes', 'Martes', 'Miercoles', 'Jueves', 'Viernes', 'Sabado'];
const DURACION_MISA_MINUTOS = 60;

@Component({
  selector: 'app-sacerdote-eucaristias',
  standalone: true,
  imports: [FormsModule],
  templateUrl: './sacerdote-eucaristias.html',
  styleUrl: './sacerdote-eucaristias.css'
})
export class SacerdoteEucaristiasComponent implements OnInit {
  private capillasService = inject(CapillasService);
  protected formatearFecha = formatearFecha;
  private eucaristiasService = inject(EucaristiasService);

  showModal = false;
  editando: Eucaristia | null = null;
  guardando = signal(false);
  marcandoRealizadas = signal(false);
  mensajeError = mensajesTemporales(signal(''));
  mensajeExito = mensajesTemporales(signal(''));

  misas = signal<Eucaristia[]>([]);
  capillas = signal<Capilla[]>([]);

  dias = Object.keys(DIAS_LABEL);
  // "Cancelada" ya no se ofrece al editar: se retira una misa eliminándola, no cancelándola.
  // "Realizada" se asigna normalmente en bloque (botón "Marcar pasadas"), pero también
  // queda disponible aquí por si hace falta corregirla a mano.
  estados = ['Activa', 'Programada', 'Realizada'];
  opcionesHora = OPCIONES_HORA;

  nueva: Partial<Eucaristia> = {};

  constructor() {
    autoRecarga(() => this.refrescar());
  }

  ngOnInit() {
    this.capillasService.listar().subscribe({ next: (c) => this.capillas.set(c) });
    this.cargarMisas();
  }

  private cargarMisas(mostrarError = true) {
    this.eucaristiasService.listar().subscribe({
      next: (m) => this.misas.set(m),
      error: () => { if (mostrarError) this.mensajeError.set('No se pudieron cargar las eucaristías.'); }
    });
  }

  private refrescar() {
    this.cargarMisas(false);
  }

  diaLabel(dia: string): string {
    return DIAS_LABEL[dia] ?? dia;
  }

  private diaSemanaDeFecha(fecha: string): string {
    return DIAS_POR_INDICE[new Date(fecha + 'T00:00:00').getDay()];
  }

  onFechaChange(fecha: string) {
    this.nueva.fecha = fecha;
    if (fecha) this.nueva.dia_semana = this.diaSemanaDeFecha(fecha);
  }

  /** La duración de la misa es fija (1 hora): al llenar la hora de inicio se calcula la de fin. */
  onHoraInicioChange(hora: string) {
    this.nueva.hora_inicio = hora;
    if (!hora) return;
    const [h, m] = hora.split(':').map(Number);
    const fin = new Date(2000, 0, 1, h, m + DURACION_MISA_MINUTOS);
    this.nueva.hora_fin = `${String(fin.getHours()).padStart(2, '0')}:${String(fin.getMinutes()).padStart(2, '0')}`;
  }

  capillaNombre(m: Eucaristia): string {
    return m.capilla_nombre ?? this.capillas().find(c => c.id_capilla === m.id_capilla)?.nombre ?? '—';
  }

  /** Si la misa que se está editando tiene un estado legado ("Cancelada") que ya no se
   *  ofrece para asignar, se agrega igual a las opciones para no dejar el select vacío. */
  get estadosEdicion(): string[] {
    const actual = this.nueva.estado;
    return actual && !this.estados.includes(actual) ? [...this.estados, actual] : this.estados;
  }

  openModal() {
    this.editando = null;
    this.nueva = { estado: 'Programada' };
    this.mensajeError.set('');
    this.showModal = true;
  }

  editar(m: Eucaristia) {
    this.editando = m;
    this.nueva = {
      ...m,
      fecha: m.fecha ? String(m.fecha).slice(0, 10) : undefined,
      hora_inicio: m.hora_inicio ? m.hora_inicio.slice(0, 5) : undefined,
      hora_fin: m.hora_fin ? m.hora_fin.slice(0, 5) : undefined
    };
    this.mensajeError.set('');
    this.showModal = true;
  }

  eliminar(m: Eucaristia) {
    if (!confirm('¿Eliminar este horario de eucaristía?')) return;
    this.eucaristiasService.eliminar(m.id_eucaristia).subscribe({
      next: () => this.cargarMisas(),
      error: (error) => this.mensajeError.set(error?.error?.mensaje ?? 'No se pudo eliminar el horario.')
    });
  }

  guardar() {
    this.mensajeError.set('');

    if (!this.nueva.id_capilla || !this.nueva.fecha || !this.nueva.hora_inicio) {
      this.mensajeError.set('Capilla, fecha y hora de inicio son obligatorios.');
      return;
    }
    if (!this.nueva.dia_semana) {
      this.nueva.dia_semana = this.diaSemanaDeFecha(this.nueva.fecha);
    }

    const hoy = new Date();
    hoy.setHours(0, 0, 0, 0);
    const fechaEucaristia = new Date(this.nueva.fecha + 'T00:00:00');
    if (fechaEucaristia < hoy) {
      this.mensajeError.set('La fecha de la eucaristía no puede ser anterior a la fecha actual.');
      return;
    }
    if (this.nueva.hora_inicio && this.nueva.hora_fin && this.nueva.hora_inicio >= this.nueva.hora_fin) {
      this.mensajeError.set('La hora de inicio debe ser anterior a la hora de fin.');
      return;
    }

    const esHoy = fechaEucaristia.getTime() === hoy.getTime();
    if (esHoy && this.nueva.hora_inicio) {
      const ahora = new Date();
      const horaActual = `${String(ahora.getHours()).padStart(2, '0')}:${String(ahora.getMinutes()).padStart(2, '0')}`;
      if (this.nueva.hora_inicio <= horaActual) {
        this.mensajeError.set('La hora de la eucaristía debe ser posterior a la hora actual.');
        return;
      }
    }

    if (this.nueva.estado === 'Realizada') {
      const horaYaPaso = () => {
        const ahora = new Date();
        const horaActual = `${String(ahora.getHours()).padStart(2, '0')}:${String(ahora.getMinutes()).padStart(2, '0')}`;
        return (this.nueva.hora_inicio ?? '') <= horaActual;
      };
      if (fechaEucaristia > hoy || (esHoy && !horaYaPaso())) {
        this.mensajeError.set('No se puede marcar como Realizada una misa cuya fecha u hora todavía no ha ocurrido.');
        return;
      }
    }

    const datos: Partial<Eucaristia> = {
      id_capilla: Number(this.nueva.id_capilla),
      dia_semana: this.nueva.dia_semana,
      fecha: this.nueva.fecha,
      hora_inicio: this.nueva.hora_inicio,
      hora_fin: this.nueva.hora_fin,
      estado: this.nueva.estado ?? 'Programada'
    };

    this.guardando.set(true);
    const peticion = this.editando
      ? this.eucaristiasService.editar(this.editando.id_eucaristia, datos)
      : this.eucaristiasService.crear(datos);

    peticion.subscribe({
      next: () => {
        this.guardando.set(false);
        this.showModal = false;
        this.editando = null;
        this.nueva = {};
        this.cargarMisas();
      },
      error: (error) => {
        this.guardando.set(false);
        this.mensajeError.set(error?.error?.mensaje ?? 'No se pudo guardar el horario de eucaristía.');
      }
    });
  }

  closeOnOverlay(e: MouseEvent) {
    if (e.target === e.currentTarget) this.showModal = false;
  }

  /** Marca en bloque como "Realizada" toda misa cuya fecha/hora ya pasó. Una misa de
   *  hoy programada más tarde en el día no se toca, aunque sea "hoy". */
  marcarRealizadas() {
    this.mensajeError.set('');
    this.mensajeExito.set('');
    this.marcandoRealizadas.set(true);
    this.eucaristiasService.marcarRealizadas().subscribe({
      next: ({ total }) => {
        this.marcandoRealizadas.set(false);
        this.mensajeExito.set(
          total > 0 ? `${total} misa(s) pasada(s) marcada(s) como Realizada.` : 'No había misas pasadas por marcar.'
        );
        this.cargarMisas();
      },
      error: (error) => {
        this.marcandoRealizadas.set(false);
        this.mensajeError.set(error?.error?.mensaje ?? 'No se pudo actualizar el estado de las misas pasadas.');
      }
    });
  }
}
