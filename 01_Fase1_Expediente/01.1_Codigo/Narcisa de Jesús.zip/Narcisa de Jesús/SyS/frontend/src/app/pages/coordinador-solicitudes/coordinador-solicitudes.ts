import { Component, OnInit, inject, signal, computed } from '@angular/core';
import { SlicePipe } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { FormAlertComponent } from '../../components/form-alert/form-alert';
import { InscripcionesCatequesisService } from '../../services/inscripciones-catequesis.service';
import { DocumentosService, abrirDocumentoEnNuevaPestana, abrirPestanaEnBlanco } from '../../services/documentos.service';
import { InscripcionCatequesis } from '../../models/inscripcion-catequesis.model';
import { mensajesTemporales } from '../../shared/utils/mensajes-temporales';
import { autoRecarga } from '../../shared/utils/auto-recarga';

interface InscripcionConLaico extends InscripcionCatequesis {
  laico_nombres?: string;
  laico_apellidos?: string;
  laico_cedula?: string;
}

@Component({
  selector: 'app-coordinador-solicitudes',
  standalone: true,
  imports: [SlicePipe, FormsModule, FormAlertComponent],
  templateUrl: './coordinador-solicitudes.html',
  styleUrl: './coordinador-solicitudes.css'
})
export class CoordinadorSolicitudesComponent implements OnInit {
  protected Number = Number;

  private inscripcionesService = inject(InscripcionesCatequesisService);
  private documentosService = inject(DocumentosService);

  solicitudes = signal<InscripcionConLaico[]>([]);
  mensajeError = mensajesTemporales(signal(''));
  mensajeExito = mensajesTemporales(signal(''));
  procesandoId = signal<number | null>(null);
  busquedaHistorial = signal('');

  pendientesLista = computed(() => this.solicitudes().filter(s => s.estado === 'Pendiente'));
  aprobadas = computed(() => this.solicitudes().filter(s => s.estado === 'Aprobada').length);
  rechazadas = computed(() => this.solicitudes().filter(s => s.estado === 'Rechazada').length);

  historial = computed(() => {
    const texto = this.busquedaHistorial().trim().toLowerCase();
    const resueltas = this.solicitudes().filter(s => s.estado !== 'Pendiente');
    if (!texto) return resueltas;
    return resueltas.filter(s =>
      this.nombreSolicitante(s).toLowerCase().includes(texto) ||
      this.cedulaSolicitante(s).toLowerCase().includes(texto)
    );
  });

  constructor() {
    autoRecarga(() => this.refrescar());
  }

  ngOnInit() {
    this.cargar();
  }

  private cargar(mostrarError = true) {
    this.inscripcionesService.listar().subscribe({
      next: (data) => this.solicitudes.set(data as InscripcionConLaico[]),
      error: () => { if (mostrarError) this.mensajeError.set('No se pudieron cargar las solicitudes.'); }
    });
  }

  private refrescar() {
    this.cargar(false);
  }

  get pendientes() {
    return this.pendientesLista().length;
  }

  nombreSolicitante(s: InscripcionConLaico): string {
    if (s.laico_nombres || s.laico_apellidos) {
      return `${s.laico_nombres ?? ''} ${s.laico_apellidos ?? ''}`.trim();
    }
    return `Laico #${s.id_laico}`;
  }

  cedulaSolicitante(s: InscripcionConLaico): string {
    return s.laico_cedula ?? `#${s.id_laico}`;
  }

  verComprobante(s: InscripcionConLaico) {
    if (!s.id_documento) return;
    const ventana = abrirPestanaEnBlanco();
    this.documentosService.obtenerPorId(s.id_documento).subscribe({
      next: (doc) => abrirDocumentoEnNuevaPestana(doc, ventana),
      error: () => {
        ventana?.close();
        this.mensajeError.set('No se pudo cargar el comprobante.');
      }
    });
  }

  aprobar(s: InscripcionConLaico) {
    this.mensajeError.set('');
    this.mensajeExito.set('');
    this.procesandoId.set(s.id_inscripcion);
    this.inscripcionesService.aprobar(s.id_inscripcion).subscribe({
      next: (actualizada) => {
        this.procesandoId.set(null);
        this.solicitudes.update(lista => lista.map(x => x.id_inscripcion === actualizada.id_inscripcion ? { ...x, ...actualizada } : x));
        this.mensajeExito.set('Solicitud aprobada correctamente.');
      },
      error: (error) => {
        this.procesandoId.set(null);
        this.mensajeError.set(error?.error?.mensaje ?? 'No se pudo aprobar la solicitud.');
      }
    });
  }

  rechazar(s: InscripcionConLaico) {
    this.mensajeError.set('');
    this.mensajeExito.set('');
    this.procesandoId.set(s.id_inscripcion);
    this.inscripcionesService.rechazar(s.id_inscripcion).subscribe({
      next: (actualizada) => {
        this.procesandoId.set(null);
        this.solicitudes.update(lista => lista.map(x => x.id_inscripcion === actualizada.id_inscripcion ? { ...x, ...actualizada } : x));
        this.mensajeExito.set('Solicitud rechazada.');
      },
      error: (error) => {
        this.procesandoId.set(null);
        this.mensajeError.set(error?.error?.mensaje ?? 'No se pudo rechazar la solicitud.');
      }
    });
  }
}
