import { Component, inject, OnInit, signal } from '@angular/core';
import { FormBuilder, ReactiveFormsModule, Validators } from '@angular/forms';
import { SolicitudesSacramentoService } from '../../services/solicitudes-sacramento.service';
import { BeneficiariosSolicitudService } from '../../services/beneficiarios-solicitud.service';
import { SolicitudSacramento } from '../../models/solicitud-sacramento.model';
import { BeneficiarioSolicitud } from '../../models/beneficiario-solicitud.model';
import { FormAlertComponent } from '../../components/form-alert/form-alert';
import { fechaNoPasadaValidator, rangoHorasValidoValidator, mensajeDeError } from '../../shared/utils/validaciones';
import { mensajesTemporales } from '../../shared/utils/mensajes-temporales';
import { autoRecarga } from '../../shared/utils/auto-recarga';
import { OPCIONES_HORA } from '../../shared/utils/horarios-disponibles';
interface SolicitudConNombre extends SolicitudSacramento {
  solicitante_nombres?: string;
  solicitante_apellidos?: string;
}

@Component({
  selector: 'app-sacerdote-solicitud',
  standalone: true,
  imports: [ReactiveFormsModule, FormAlertComponent],
  templateUrl: './sacerdote-solicitud.html',
  styleUrl: './sacerdote-solicitud.css'
})
export class SacerdoteSolicitudComponent implements OnInit {
  private solicitudesService = inject(SolicitudesSacramentoService);
  private beneficiariosService = inject(BeneficiariosSolicitudService);
  private fb = inject(FormBuilder);

  modalActivo: 'bautismo' | 'matrimonio' | null = null;
  solicitudSeleccionada: SolicitudConNombre | null = null;
  beneficiarios = signal<BeneficiarioSolicitud[]>([]);

  guardando = signal(false);
  mensajeError = mensajesTemporales(signal(''));
  mensajeExito = mensajesTemporales(signal(''));
  mensajeDeError = mensajeDeError;

  solicitudes = signal<SolicitudConNombre[]>([]);
  opcionesHora = OPCIONES_HORA;

  asignacionForm = this.fb.group(
    {
      fecha: ['', [Validators.required, fechaNoPasadaValidator()]],
      hInicio: ['', [Validators.required]],
      hFin: ['', [Validators.required]]
    },
    { validators: rangoHorasValidoValidator('hInicio', 'hFin') }
  );

  constructor() {
    autoRecarga(() => this.refrescar());

    // Misma lógica que al crear una eucaristía: la duración es fija (1 hora), así que
    // al elegir la hora de inicio se autocompleta la de fin.
    this.asignacionForm.controls.hInicio.valueChanges.subscribe((hora) => {
      if (!hora) return;
      const [h, m] = hora.split(':').map(Number);
      const fin = new Date(2000, 0, 1, h, m + 60);
      const horaFin = `${String(fin.getHours()).padStart(2, '0')}:${String(fin.getMinutes()).padStart(2, '0')}`;
      this.asignacionForm.controls.hFin.setValue(horaFin, { emitEvent: false });
    });
  }

  ngOnInit() {
    this.cargarSolicitudes();
  }

  private cargarSolicitudes(mostrarError = true) {
    this.solicitudesService.listar().subscribe({
      next: (s) => this.solicitudes.set(s as SolicitudConNombre[]),
      error: () => { if (mostrarError) this.mensajeError.set('No se pudieron cargar las solicitudes.'); }
    });
  }

  private refrescar() {
    this.cargarSolicitudes(false);
  }

  get pendientes(): number {
    return this.solicitudes().filter(s => s.estado === 'Pendiente').length;
  }

  get atendidas(): number {
    return this.solicitudes().filter(s => s.estado === 'Atendida').length;
  }

  get totalMes(): number {
    const hoy = new Date();
    return this.solicitudes().filter(s => {
      if (!s.fecha_solicitud) return false;
      const f = new Date(s.fecha_solicitud);
      return f.getFullYear() === hoy.getFullYear() && f.getMonth() === hoy.getMonth();
    }).length;
  }

  beneficiarioPorRol(rol: 'Bautizando' | 'Conyuge', indice = 0): BeneficiarioSolicitud | undefined {
    return this.beneficiarios().filter(b => b.rol_beneficiario === rol)[indice];
  }

  abrirModal(s: SolicitudConNombre) {
    this.mensajeError.set('');
    this.mensajeExito.set('');
    this.solicitudSeleccionada = s;
    this.asignacionForm.reset({
      fecha: s.fecha_asignada ? s.fecha_asignada.slice(0, 10) : '',
      hInicio: s.hora_inicio?.slice(0, 5) ?? '',
      hFin: s.hora_fin?.slice(0, 5) ?? ''
    });
    this.beneficiarios.set([]);
    this.modalActivo = s.sacramento === 'Matrimonio' ? 'matrimonio' : 'bautismo';

    this.beneficiariosService.listarPorSolicitud(s.id_solicitud).subscribe({
      next: (b) => this.beneficiarios.set(b),
      error: () => this.mensajeError.set('No se pudieron cargar los datos de los beneficiarios.')
    });
  }

  guardar() {
    this.mensajeError.set('');

    if (this.asignacionForm.invalid) {
      this.asignacionForm.markAllAsTouched();
      this.mensajeError.set(
        this.asignacionForm.errors?.['rangoHorasInvalido']
          ? 'La hora de inicio debe ser anterior a la hora de fin.'
          : 'Revisa los campos marcados en rojo.'
      );
      return;
    }
    if (!this.solicitudSeleccionada) return;

    const { fecha, hInicio, hFin } = this.asignacionForm.getRawValue();

    if (this.solicitudSeleccionada.sacramento === 'Bautizo') {
      const yaHayBautizo = this.solicitudes().some(s =>
        s.sacramento === 'Bautizo' &&
        s.estado === 'Atendida' &&
        s.id_solicitud !== this.solicitudSeleccionada!.id_solicitud &&
        s.fecha_asignada?.slice(0, 10) === fecha
      );
      if (yaHayBautizo) {
        this.mensajeError.set('Ya hay un bautizo agendado para esa fecha. Elige otra fecha.');
        return;
      }
    }

    this.guardando.set(true);
    this.solicitudesService.asignar(this.solicitudSeleccionada.id_solicitud, {
      fecha_asignada: fecha!,
      hora_inicio: hInicio!,
      hora_fin: hFin!
    }).subscribe({
      next: () => {
        this.guardando.set(false);
        this.modalActivo = null;
        this.solicitudSeleccionada = null;
        this.mensajeExito.set('Fecha asignada correctamente.');
        this.cargarSolicitudes();
      },
      error: (error) => {
        this.guardando.set(false);
        this.mensajeError.set(error?.error?.mensaje ?? 'No se pudo asignar la fecha.');
      }
    });
  }

  rechazar(s: SolicitudSacramento) {
    if (!confirm('¿Rechazar esta solicitud?')) return;
    this.mensajeError.set('');
    this.mensajeExito.set('');
    this.solicitudesService.rechazar(s.id_solicitud).subscribe({
      next: () => {
        this.mensajeExito.set('Solicitud rechazada.');
        this.cargarSolicitudes();
      },
      error: (error) => this.mensajeError.set(error?.error?.mensaje ?? 'No se pudo rechazar la solicitud.')
    });
  }

  closeOnOverlay(e: MouseEvent) {
    if (e.target === e.currentTarget) this.modalActivo = null;
  }
}
