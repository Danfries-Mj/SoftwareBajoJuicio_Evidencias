import { Component, inject, OnInit, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { CapillasService } from '../../services/capillas.service';
import { ComunicadosService } from '../../services/comunicados.service';
import { Capilla } from '../../models/capilla.model';
import { Comunicado } from '../../models/comunicado.model';
import { mensajesTemporales } from '../../shared/utils/mensajes-temporales';
import { autoRecarga } from '../../shared/utils/auto-recarga';

@Component({
  selector: 'app-sacerdote-comunicados',
  standalone: true,
  imports: [FormsModule],
  templateUrl: './sacerdote-comunicados.html',
  styleUrl: './sacerdote-comunicados.css'
})
export class SacerdoteComunicadosComponent implements OnInit {
  private capillasService = inject(CapillasService);
  private comunicadosService = inject(ComunicadosService);

  showModal = false;
  editando: Comunicado | null = null;
  guardando = signal(false);
  mensajeError = mensajesTemporales(signal(''));
  mensajeExito = mensajesTemporales(signal(''));

  comunicados = signal<Comunicado[]>([]);
  capillas = signal<Capilla[]>([]);

  nuevo: Partial<Comunicado> = {};

  constructor() {
    autoRecarga(() => this.refrescar());
  }

  ngOnInit() {
    this.capillasService.listar().subscribe({ next: (c) => this.capillas.set(c) });
    this.cargarComunicados();
  }

  private cargarComunicados(mostrarError = true) {
    this.comunicadosService.listar().subscribe({
      next: (c) => this.comunicados.set(c),
      error: () => { if (mostrarError) this.mensajeError.set('No se pudieron cargar los comunicados.'); }
    });
  }

  private refrescar() {
    this.cargarComunicados(false);
  }

  destinatarioNombre(c: Comunicado): string {
    if (!c.id_capilla) return 'Toda la parroquia';
    return c.capilla_nombre ?? this.capillas().find(cap => cap.id_capilla === c.id_capilla)?.nombre ?? '—';
  }

  formatFecha(fecha?: string): string {
    if (!fecha) return '—';
    return new Date(fecha).toLocaleDateString('es-ES', { day: 'numeric', month: 'short', year: 'numeric' });
  }

  openModal() {
    this.editando = null;
    this.nuevo = { id_capilla: null, estado: 'Enviado' };
    this.mensajeError.set('');
    this.showModal = true;
  }

  editar(c: Comunicado) {
    this.editando = c;
    this.nuevo = { ...c };
    this.mensajeError.set('');
    this.showModal = true;
  }

  eliminar(c: Comunicado) {
    if (!confirm('¿Eliminar este comunicado?')) return;
    this.comunicadosService.eliminar(c.id_comunicado).subscribe({
      next: () => this.cargarComunicados(),
      error: (error) => this.mensajeError.set(error?.error?.mensaje ?? 'No se pudo eliminar el comunicado.')
    });
  }

  guardar() {
    this.mensajeError.set('');

    if (!this.nuevo.titulo?.trim() || !this.nuevo.mensaje?.trim()) {
      this.mensajeError.set('Título y contenido son obligatorios.');
      return;
    }

    const datos = {
      titulo: this.nuevo.titulo,
      mensaje: this.nuevo.mensaje,
      id_capilla: this.nuevo.id_capilla ?? null,
      estado: this.nuevo.estado ?? 'Enviado'
    };
    const esEdicion = !!this.editando;

    this.guardando.set(true);
    const peticion = this.editando
      ? this.comunicadosService.editar(this.editando.id_comunicado, datos)
      : this.comunicadosService.crear(datos);

    peticion.subscribe({
      next: () => {
        this.guardando.set(false);
        this.showModal = false;
        this.editando = null;
        this.nuevo = {};
        this.mensajeExito.set(
          esEdicion
            ? 'Comunicado actualizado correctamente.'
            : datos.estado === 'Enviado' ? 'Comunicado enviado correctamente.' : 'Comunicado guardado como borrador.'
        );
        this.cargarComunicados();
      },
      error: (error) => {
        this.guardando.set(false);
        this.mensajeError.set(error?.error?.mensaje ?? 'No se pudo guardar el comunicado.');
      }
    });
  }

  closeOnOverlay(e: MouseEvent) {
    if (e.target === e.currentTarget) { this.showModal = false; this.editando = null; }
  }
}
