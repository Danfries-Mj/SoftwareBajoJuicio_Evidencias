import { Component, OnInit, inject, signal } from '@angular/core';
import { SlicePipe } from '@angular/common';
import { AuthService } from '../../services/auth.service';
import { InscritosCatequesisService } from '../../services/inscritos-catequesis.service';
import { EventosService } from '../../services/eventos.service';
import { InscripcionesCatequesisService } from '../../services/inscripciones-catequesis.service';
import { Evento } from '../../models/evento.model';
import { mensajesTemporales } from '../../shared/utils/mensajes-temporales';
import { autoRecarga } from '../../shared/utils/auto-recarga';

interface Stat { label: string; valor: number; sub: string; }
interface CatequesisNivel { nivel: string; inscritos: number; activos: number; finalizados: number; }
interface SolicitudMes { mes: string; pendientes: number; atendidas: number; }

const MESES = ['ene', 'feb', 'mar', 'abr', 'may', 'jun', 'jul', 'ago', 'sep', 'oct', 'nov', 'dic'];

@Component({
  selector: 'app-coordinador-reportes',
  standalone: true,
  imports: [SlicePipe],
  templateUrl: './coordinador-reportes.html',
  styleUrl: './coordinador-reportes.css'
})
export class CoordinadorReportesComponent implements OnInit {
  private authService = inject(AuthService);
  private inscritosCatequesisService = inject(InscritosCatequesisService);
  private eventosService = inject(EventosService);
  private inscripcionesCatequesisService = inject(InscripcionesCatequesisService);

  get capilla() { return this.authService.user()?.capilla ?? ''; }

  mensajeError = mensajesTemporales(signal(''));
  stats = signal<Stat[]>([]);
  catequesis = signal<CatequesisNivel[]>([]);
  eventosRealizados = signal<Evento[]>([]);
  solicitudesPorMes = signal<SolicitudMes[]>([]);

  private totalInscritos = 0;
  private totalActivos = 0;
  private totalEventosMes = 0;
  private totalSolicitudesAtendidasMes = 0;

  constructor() {
    autoRecarga(() => this.refrescar());
  }

  ngOnInit() {
    this.cargar();
  }

  private cargar(mostrarError = true) {
    this.inscritosCatequesisService.listar().subscribe({
      next: (inscritos) => {
        this.totalInscritos = inscritos.length;
        this.totalActivos = inscritos.filter(i => i.estado === 'Activo').length;

        const porNivel = new Map<string, { inscritos: number; activos: number; finalizados: number }>();
        for (const i of inscritos) {
          const actual = porNivel.get(i.nivel) ?? { inscritos: 0, activos: 0, finalizados: 0 };
          actual.inscritos++;
          if (i.estado === 'Activo') actual.activos++;
          if (i.estado === 'Finalizado') actual.finalizados++;
          porNivel.set(i.nivel, actual);
        }
        this.catequesis.set(Array.from(porNivel.entries()).map(([nivel, v]) => ({ nivel, ...v })));
        this.actualizarStats();
      },
      error: () => { if (mostrarError) this.mensajeError.set('No se pudieron cargar los datos de catequesis.'); }
    });

    const idCapilla = this.authService.user()?.id_capilla ?? undefined;
    this.eventosService.listar({ id_capilla: idCapilla }).subscribe({
      next: (eventos) => {
        this.eventosRealizados.set(eventos.filter(e => e.estado === 'Realizado'));

        const hoy = new Date();
        this.totalEventosMes = eventos.filter(e => {
          const f = new Date(e.fecha);
          return f.getFullYear() === hoy.getFullYear() && f.getMonth() === hoy.getMonth();
        }).length;
        this.actualizarStats();
      },
      error: () => { if (mostrarError) this.mensajeError.set('No se pudieron cargar los eventos de la capilla.'); }
    });

    this.inscripcionesCatequesisService.listar().subscribe({
      next: (inscripciones) => {
        const hoy = new Date();
        this.totalSolicitudesAtendidasMes = inscripciones.filter(s => {
          if (s.estado === 'Pendiente' || !s.fecha_solicitud) return false;
          const f = new Date(s.fecha_solicitud);
          return f.getFullYear() === hoy.getFullYear() && f.getMonth() === hoy.getMonth();
        }).length;
        this.actualizarStats();

        const porMes = new Map<string, SolicitudMes>();
        for (const s of inscripciones) {
          if (!s.fecha_solicitud) continue;
          const f = new Date(s.fecha_solicitud);
          const clave = `${f.getFullYear()}-${f.getMonth()}`;
          const actual = porMes.get(clave) ?? { mes: MESES[f.getMonth()], pendientes: 0, atendidas: 0 };
          if (s.estado === 'Pendiente') actual.pendientes++;
          else actual.atendidas++;
          porMes.set(clave, actual);
        }
        this.solicitudesPorMes.set(
          Array.from(porMes.entries())
            .sort(([a], [b]) => a.localeCompare(b))
            .map(([, v]) => v)
        );
      },
      error: () => { if (mostrarError) this.mensajeError.set('No se pudieron cargar las solicitudes de catequesis.'); }
    });
  }

  private refrescar() {
    this.cargar(false);
  }

  private actualizarStats() {
    this.stats.set([
      { label: 'INSCRITOS CAPILLA', valor: this.totalInscritos, sub: 'catequesis activa' },
      { label: 'ACTIVOS', valor: this.totalActivos, sub: 'al día' },
      { label: 'EVENTOS ESTE MES', valor: this.totalEventosMes, sub: this.capilla },
      { label: 'SOLICITUDES ATENDIDAS', valor: this.totalSolicitudesAtendidasMes, sub: 'este mes' }
    ]);
  }

  pct(finalizados: number, total: number) {
    return total > 0 ? Math.round((finalizados / total) * 100) : 0;
  }

  /** Exporta el reporte usando el diálogo de impresión del navegador ("Guardar como PDF"). */
  exportarPDF() {
    window.print();
  }
}
