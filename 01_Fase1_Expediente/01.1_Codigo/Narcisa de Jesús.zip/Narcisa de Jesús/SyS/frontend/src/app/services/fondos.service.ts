import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, map } from 'rxjs';
import { API_URL } from '../core/config/api.config';
import { Fondo } from '../models/fondo.model';

@Injectable({ providedIn: 'root' })
export class FondosService {
  private apiUrl = `${API_URL}/fondos`;

  constructor(private http: HttpClient) {}

  listar(): Observable<Fondo[]> {
    return this.http.get<{ mensaje: string; total: number; fondos: Fondo[] }>(this.apiUrl)
      .pipe(map(respuesta => respuesta.fondos));
  }

  obtenerPorId(id: number): Observable<Fondo> {
    return this.http.get<{ mensaje: string; fondo: Fondo }>(`${this.apiUrl}/${id}`)
      .pipe(map(respuesta => respuesta.fondo));
  }

  crear(datos: { nombre: string; descripcion?: string; saldo_actual?: number; id_capilla?: number | null }): Observable<Fondo> {
    return this.http.post<{ mensaje: string; fondo: Fondo }>(this.apiUrl, datos)
      .pipe(map(respuesta => respuesta.fondo));
  }

  editar(id: number, datos: { nombre: string; descripcion?: string; id_capilla?: number | null }): Observable<Fondo> {
    return this.http.put<{ mensaje: string; fondo: Fondo }>(`${this.apiUrl}/${id}`, datos)
      .pipe(map(respuesta => respuesta.fondo));
  }

  eliminar(id: number): Observable<{ mensaje: string; fondo: Fondo }> {
    return this.http.delete<{ mensaje: string; fondo: Fondo }>(`${this.apiUrl}/${id}`);
  }
}
