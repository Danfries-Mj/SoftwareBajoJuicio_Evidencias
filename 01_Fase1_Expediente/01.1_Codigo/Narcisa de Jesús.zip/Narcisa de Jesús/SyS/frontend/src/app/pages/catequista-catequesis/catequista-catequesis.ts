import { Component, inject, OnInit, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { SlicePipe } from '@angular/common';
import { firstValueFrom } from 'rxjs';
import { AuthService } from '../../services/auth.service';
import { InscritosCatequesisService } from '../../services/inscritos-catequesis.service';
import { HistorialInscritoService } from '../../services/historial-inscrito.service';
import { PersonasService } from '../../services/personas.service';
import { CertificadosService } from '../../services/certificados.service';
import { DocumentosService } from '../../services/documentos.service';
import { InscritoCatequesis } from '../../models/inscrito-catequesis.model';
import { HistorialInscrito } from '../../models/historial-inscrito.model';
import { mensajesTemporales } from '../../shared/utils/mensajes-temporales';
import { autoRecarga } from '../../shared/utils/auto-recarga';
import { soloDigitos, validarArchivo } from '../../shared/utils/validaciones';

interface NuevoInscritoForm {
  cedula: string;
  nombres: string;
  apellidos: string;
  nivel: string;
  fecha_inscripcion: string;
  monto: number;
}

function nuevoArchivo() {
  return { nombre: signal(''), dataUrl: signal(''), mime: signal(''), error: signal('') };
}

@Component({
  selector: 'app-catequista-catequesis',
  standalone: true,
  imports: [FormsModule, SlicePipe],
  templateUrl: './catequista-catequesis.html',
  styleUrl: './catequista-catequesis.css'
})
export class CatequistaCatequesisComponent implements OnInit {
  private authService = inject(AuthService);
  private inscritosService = inject(InscritosCatequesisService);
  private historialService = inject(HistorialInscritoService);
  private personasService = inject(PersonasService);
  private certificadosService = inject(CertificadosService);
  private documentosService = inject(DocumentosService);
  protected soloDigitos = soloDigitos;

  get catequista() { return (this.authService.user()?.nombres ?? '') + ' ' + (this.authService.user()?.apellidos ?? ''); }
  get capilla() { return this.authService.user()?.capilla ?? ''; }

  inscritos = signal<InscritoCatequesis[]>([]);
  mensajeError = mensajesTemporales(signal(''));
  mensajeExito = mensajesTemporales(signal(''));

  niveles = ['Primera Comunion', 'Confirmacion'];
  estados = ['Pendiente', 'Activo', 'Finalizado'];

  /**
   * Certificado prerrequisito inmediato de cada nivel. No hace falta revisar toda la
   * cadena: para tener el de Primera Comunión emitido, ya se exigió el de Bautismo al
   * emitirlo, así que basta con verificar el inmediato anterior.
   */
  private readonly prerrequisitoInmediato: Record<string, string> = {
    'Primera Comunion': 'Bautismo',
    'Confirmacion': 'Primera Comunion'
  };

  busqueda = '';
  filtroEstado = '';

  showNuevo = false;
  showEditar = false;
  showEliminar = false;
  showHistorial = false;

  guardando = signal(false);
  errorNuevo = mensajesTemporales(signal(''));
  errorEditar = mensajesTemporales(signal(''));
  errorEliminar = mensajesTemporales(signal(''));

  buscandoCedula = signal(false);
  busquedaCedulaMsg = signal('');
  personaEnSistema = signal(false);
  // Si el certificado prerrequisito ya está emitido (tenga o no cuenta la persona), no
  // hace falta subir nada. Si no, el Catequista puede adjuntarlo aquí (queda "Pendiente" de
  // validar por el Sacerdote: el inscrito nace "Pendiente" hasta que se valide).
  certificadoValidado = signal(false);
  private personaIdPersona: number | null = null;
  comprobanteArchivo = nuevoArchivo();
  certificadoNuevoArchivo = nuevoArchivo();

  nuevo: NuevoInscritoForm = this.formVacio();

  editando: InscritoCatequesis | null = null;
  formEditar: { estado: string; nota: string } = { estado: '', nota: '' };

  eliminarTarget: InscritoCatequesis | null = null;

  historialTarget: InscritoCatequesis | null = null;
  historial = signal<HistorialInscrito[]>([]);
  cargandoHistorial = signal(false);

  // Si la persona ya tiene el certificado de este nivel emitido, el estado ya no se puede editar
  estadoBloqueadoPorCertificado = signal(false);
  verificandoCertificado = signal(false);

  get filtrados(): InscritoCatequesis[] {
    const texto = this.busqueda.trim().toLowerCase();
    return this.inscritos().filter(i => {
      const matchSearch = !texto ||
        i.nombres.toLowerCase().includes(texto) ||
        i.cedula.includes(texto);
      return matchSearch;
    });
  }

  get puedeEliminar(): boolean {
    return this.eliminarTarget !== null;
  }

  constructor() {
    autoRecarga(() => this.refrescar());
  }

  ngOnInit() {
    this.cargarInscritos();
  }

  private refrescar() {
    this.cargarInscritos(false);
  }

  private formVacio(): NuevoInscritoForm {
    return {
      cedula: '',
      nombres: '',
      apellidos: '',
      nivel: 'Primera Comunion',
      fecha_inscripcion: new Date().toISOString().slice(0, 10),
      monto: 5
    };
  }

  nivelLabel(nivel: string): string {
    if (nivel === 'Primera Comunion') return 'Primera Comunión';
    if (nivel === 'Confirmacion') return 'Confirmación';
    return nivel;
  }

  cargarInscritos(mostrarError = true) {
    if (mostrarError) this.mensajeError.set('');
    this.inscritosService.listar({ estado: this.filtroEstado || undefined }).subscribe({
      next: (data) => this.inscritos.set(data),
      error: (error) => { if (mostrarError) this.mensajeError.set(error?.error?.mensaje ?? 'No se pudieron cargar los inscritos.'); }
    });
  }

  onFiltroEstadoChange() {
    this.cargarInscritos();
  }

  abrirNuevo() {
    this.resetNuevo();
    this.showNuevo = true;
  }

  cerrarNuevo() {
    this.showNuevo = false;
    this.resetNuevo();
  }

  private resetNuevo() {
    this.nuevo = this.formVacio();
    this.errorNuevo.set('');
    this.busquedaCedulaMsg.set('');
    this.personaEnSistema.set(false);
    this.certificadoValidado.set(false);
    this.personaIdPersona = null;
    this.comprobanteArchivo = nuevoArchivo();
    this.certificadoNuevoArchivo = nuevoArchivo();
  }

  onCedulaChange(valor: string) {
    this.nuevo.cedula = soloDigitos(valor, 10);
    this.personaEnSistema.set(false);
    this.certificadoValidado.set(false);
    this.personaIdPersona = null;
    this.busquedaCedulaMsg.set('');
  }

  onNivelChange(valor: string) {
    this.nuevo.nivel = valor;
    this.personaEnSistema.set(false);
    this.certificadoValidado.set(false);
    this.personaIdPersona = null;
    this.busquedaCedulaMsg.set('');
  }

  onFileSelect(event: Event, target: 'comprobanteArchivo' | 'certificadoNuevoArchivo' = 'comprobanteArchivo') {
    const input = event.target as HTMLInputElement;
    const file = input.files?.[0];
    if (!file) return;

    const archivo = this[target];
    const error = validarArchivo(file, { tipos: ['application/pdf', 'image/png', 'image/jpeg'] });
    if (error) {
      archivo.error.set(error);
      archivo.nombre.set('');
      archivo.dataUrl.set('');
      input.value = '';
      return;
    }

    archivo.error.set('');
    const reader = new FileReader();
    reader.onload = () => {
      archivo.nombre.set(file.name);
      archivo.dataUrl.set(reader.result as string);
      archivo.mime.set(file.type);
    };
    reader.readAsDataURL(file);
  }

  /**
   * Busca la persona por cédula (tenga o no cuenta de usuario) para autocompletar sus
   * datos y verificar de una vez su certificado prerrequisito del nivel seleccionado.
   * Si no está registrada, los campos quedan editables para completarlos a mano.
   */
  async buscarPorCedula() {
    const cedula = this.nuevo.cedula.trim();
    if (!cedula || !/^\d{10}$/.test(cedula)) {
      this.busquedaCedulaMsg.set('Ingresa una cédula válida (10 dígitos) para buscar.');
      return;
    }

    this.buscandoCedula.set(true);
    this.busquedaCedulaMsg.set('');
    this.personaEnSistema.set(false);
    this.certificadoValidado.set(false);
    this.personaIdPersona = null;

    const tipoPrerrequisito = this.prerrequisitoInmediato[this.nuevo.nivel];

    try {
      const persona = await firstValueFrom(this.personasService.buscarPorCedula(cedula));
      this.personaEnSistema.set(true);
      this.personaIdPersona = persona.id_persona;
      this.nuevo.nombres = persona.nombres;
      this.nuevo.apellidos = persona.apellidos;

      const tieneCertificado = await firstValueFrom(
        this.certificadosService.tienePrerrequisitoEmitido(persona.id_persona, tipoPrerrequisito)
      );
      this.certificadoValidado.set(tieneCertificado);
      this.buscandoCedula.set(false);
      this.busquedaCedulaMsg.set(
        tieneCertificado
          ? `Persona encontrada: tiene el certificado de ${tipoPrerrequisito} emitido.`
          : `Persona encontrada: sube su certificado de ${tipoPrerrequisito} para poder inscribirla (quedará pendiente hasta que el Sacerdote lo valide).`
      );
    } catch (error: any) {
      this.buscandoCedula.set(false);
      this.personaEnSistema.set(false);
      this.nuevo.nombres = '';
      this.nuevo.apellidos = '';
      this.busquedaCedulaMsg.set(
        error?.status === 404
          ? `No se encontró una persona registrada con esa cédula. Completa los datos manualmente y adjunta su certificado de ${tipoPrerrequisito}.`
          : (error?.error?.mensaje ?? 'No se pudo buscar la cédula. Intenta de nuevo.')
      );
    }
  }

  /**
   * Inscribe a la persona: sube el comprobante y crea el inscrito directamente. Si el
   * certificado prerrequisito ya estaba emitido, nace "Activo"; si el Catequista tuvo que
   * adjuntarlo aquí, nace "Pendiente" hasta que el Sacerdote lo valide (se promueve solo).
   */
  async guardarNuevo() {
    this.errorNuevo.set('');
    if (!this.nuevo.cedula.trim() || !this.nuevo.nombres.trim() || !this.nuevo.apellidos.trim() || !this.nuevo.nivel || !this.nuevo.fecha_inscripcion) {
      this.errorNuevo.set('Cédula, nombres, apellidos, nivel y fecha de inscripción son obligatorios.');
      return;
    }
    if (!/^\d{10}$/.test(this.nuevo.cedula.trim())) {
      this.errorNuevo.set('La cédula debe tener exactamente 10 dígitos.');
      return;
    }
    if (!this.certificadoValidado() && !this.certificadoNuevoArchivo.dataUrl()) {
      this.errorNuevo.set('Adjunta el certificado prerrequisito, o busca la cédula y verifica que la persona ya lo tenga emitido.');
      return;
    }
    if (!this.comprobanteArchivo.dataUrl()) {
      this.errorNuevo.set('La foto o PDF del comprobante de pago es obligatorio.');
      return;
    }

    const u = this.authService.user();
    const idCapilla = u?.id_capilla;
    if (!idCapilla) {
      this.errorNuevo.set('No tienes una capilla asignada.');
      return;
    }

    const nombreCompleto = `${this.nuevo.nombres.trim()} ${this.nuevo.apellidos.trim()}`;
    const cedula = this.nuevo.cedula.trim();

    this.guardando.set(true);
    try {
      // Resuelve (o crea) la persona, igual que en la inscripción de terceros del Laico.
      let idPersona = this.personaIdPersona;
      if (!idPersona) {
        try {
          const personaExistente = await firstValueFrom(this.personasService.buscarPorCedula(cedula));
          idPersona = personaExistente.id_persona;
        } catch {
          const personaCreada = await firstValueFrom(this.personasService.crear({
            cedula, nombres: this.nuevo.nombres.trim(), apellidos: this.nuevo.apellidos.trim()
          }));
          idPersona = personaCreada.id_persona;
        }
      }

      // El Catequista no valida certificados: el que suba aquí queda "Pendiente" hasta
      // que el Sacerdote lo revise (igual que cuando lo sube un Laico).
      if (!this.certificadoValidado() && this.certificadoNuevoArchivo.dataUrl()) {
        await firstValueFrom(this.certificadosService.crear({
          tipo: this.prerrequisitoInmediato[this.nuevo.nivel], id_persona: idPersona,
          archivo_nombre: this.certificadoNuevoArchivo.nombre(),
          archivo_url: this.certificadoNuevoArchivo.dataUrl(), mime_type: this.certificadoNuevoArchivo.mime()
        }));
      }

      const documento = await firstValueFrom(this.documentosService.crear({
        tipo: `Comprobante de catequesis - ${nombreCompleto} (cédula ${cedula})`,
        archivo_nombre: this.comprobanteArchivo.nombre(),
        archivo_url: this.comprobanteArchivo.dataUrl(),
        mime_type: this.comprobanteArchivo.mime()
      }));

      await firstValueFrom(this.inscritosService.crear({
        cedula,
        nombres: nombreCompleto,
        nivel: this.nuevo.nivel as InscritoCatequesis['nivel'],
        id_capilla: idCapilla,
        id_catequista: u?.id_usuario,
        fecha_inscripcion: this.nuevo.fecha_inscripcion,
        monto: this.nuevo.monto,
        comprobante: documento.archivo_nombre,
        estado: this.certificadoValidado() ? 'Activo' : 'Pendiente'
      }));

      this.guardando.set(false);
      this.showNuevo = false;
      this.resetNuevo();
      this.mensajeExito.set(
        this.certificadoValidado()
          ? 'Inscrito registrado correctamente.'
          : 'Inscrito registrado como Pendiente: se activará solo cuando el Sacerdote valide el certificado.'
      );
      this.cargarInscritos();
    } catch (error: any) {
      this.guardando.set(false);
      this.errorNuevo.set(error?.error?.mensaje ?? 'No se pudo registrar el inscrito.');
    }
  }

  abrirEditar(i: InscritoCatequesis) {
    this.editando = i;
    this.formEditar = { estado: i.estado, nota: '' };
    this.errorEditar.set('');
    this.estadoBloqueadoPorCertificado.set(false);
    this.showEditar = true;

    this.verificandoCertificado.set(true);
    this.personasService.buscarPorCedula(i.cedula).subscribe({
      next: (persona) => {
        this.certificadosService.tienePrerrequisitoEmitido(persona.id_persona, i.nivel).subscribe({
          next: (tiene) => {
            this.verificandoCertificado.set(false);
            this.estadoBloqueadoPorCertificado.set(tiene);
          },
          error: () => this.verificandoCertificado.set(false)
        });
      },
      error: () => this.verificandoCertificado.set(false)
    });
  }

  guardarEditar() {
    if (!this.editando) return;
    this.errorEditar.set('');
    if (!this.formEditar.estado) {
      this.errorEditar.set('El estado es obligatorio.');
      return;
    }
    // El <select> de estado queda deshabilitado en la plantilla cuando ya hay certificado
    // emitido, así que aquí forzamos el valor original por si acaso llega alterado.
    if (this.estadoBloqueadoPorCertificado()) {
      this.formEditar.estado = this.editando.estado;
    }

    const u = this.authService.user();
    this.guardando.set(true);
    this.inscritosService.editar(this.editando.id_inscrito, {
      id_catequista: this.editando.id_catequista ?? u?.id_usuario,
      estado: this.formEditar.estado,
      nota: this.formEditar.nota.trim() || undefined
    }).subscribe({
      next: () => {
        this.guardando.set(false);
        this.showEditar = false;
        this.editando = null;
        this.formEditar = { estado: '', nota: '' };
        this.mensajeExito.set('Inscrito actualizado correctamente.');
        this.cargarInscritos();
      },
      error: (error) => {
        this.guardando.set(false);
        this.errorEditar.set(error?.error?.mensaje ?? 'No se pudo actualizar el inscrito.');
      }
    });
  }

  abrirEliminar(i: InscritoCatequesis) {
    this.eliminarTarget = i;
    this.errorEliminar.set('');
    this.showEliminar = true;
  }

  eliminar() {
    if (!this.puedeEliminar || !this.eliminarTarget) return;
    this.errorEliminar.set('');
    this.guardando.set(true);
    this.inscritosService.eliminar(this.eliminarTarget.id_inscrito).subscribe({
      next: () => {
        this.guardando.set(false);
        this.showEliminar = false;
        this.eliminarTarget = null;
        this.mensajeExito.set('Inscrito eliminado correctamente.');
        this.cargarInscritos();
      },
      error: (error) => {
        this.guardando.set(false);
        this.errorEliminar.set(error?.error?.mensaje ?? 'No se pudo eliminar el inscrito.');
      }
    });
  }

  abrirHistorial(i: InscritoCatequesis) {
    this.historialTarget = i;
    this.historial.set([]);
    this.showHistorial = true;
    this.cargandoHistorial.set(true);
    this.historialService.listarPorInscrito(i.id_inscrito).subscribe({
      next: (data) => {
        this.historial.set(data);
        this.cargandoHistorial.set(false);
      },
      error: () => {
        this.cargandoHistorial.set(false);
      }
    });
  }

  closeOnOverlay(e: MouseEvent, modal: 'nuevo' | 'editar' | 'eliminar' | 'historial') {
    if (e.target !== e.currentTarget) return;
    if (modal === 'nuevo') this.cerrarNuevo();
    else if (modal === 'editar') { this.showEditar = false; this.editando = null; }
    else if (modal === 'historial') { this.showHistorial = false; this.historialTarget = null; }
    else { this.showEliminar = false; this.eliminarTarget = null; }
  }
}
