import { Component, OnInit, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { SlicePipe } from '@angular/common';
import { AuthService } from '../../services/auth.service';
import { ComunicadosService } from '../../services/comunicados.service';
import { Comunicado, EstadoComunicado } from '../../models/comunicado.model';
import { mensajesTemporales } from '../../shared/utils/mensajes-temporales';
import { autoRecarga } from '../../shared/utils/auto-recarga';

interface NuevoComunicado {
  titulo?: string;
  mensaje?: string;
  estado?: EstadoComunicado;
}

@Component({
  selector: 'app-coordinador-comunicados',
  standalone: true,
  imports: [FormsModule, SlicePipe],
  templateUrl: './coordinador-comunicados.html',
  styleUrl: './coordinador-comunicados.css'
})
export class CoordinadorComunicadosComponent implements OnInit {
  private authService = inject(AuthService);
  private comunicadosService = inject(ComunicadosService);

  get capilla() { return this.authService.user()?.capilla ?? ''; }

  showModal = false;
  guardando = signal(false);
  mensajeError = mensajesTemporales(signal(''));
  mensajeExito = mensajesTemporales(signal(''));

  comunicados = signal<Comunicado[]>([]);
  editando: Comunicado | null = null;
  nuevo: NuevoComunicado = {};

  constructor() {
    autoRecarga(() => this.refrescar());
  }

  ngOnInit() {
    this.cargar();
  }

  private cargar(mostrarError = true) {
    this.comunicadosService.listar().subscribe({
      next: (data) => this.comunicados.set(data),
      error: () => { if (mostrarError) this.mensajeError.set('No se pudieron cargar los comunicados.'); }
    });
  }

  private refrescar() {
    this.cargar(false);
  }

  openModal() {
    this.nuevo = { estado: 'Enviado' };
    this.editando = null;
    this.mensajeError.set('');
    this.showModal = true;
  }

  editar(c: Comunicado) {
    this.nuevo = { titulo: c.titulo, mensaje: c.mensaje, estado: c.estado };
    this.editando = c;
    this.mensajeError.set('');
    this.showModal = true;
  }

  guardar() {
    this.mensajeError.set('');

    if (!this.nuevo.titulo?.trim() || !this.nuevo.mensaje?.trim()) {
      this.mensajeError.set('El título y el mensaje son obligatorios.');
      return;
    }

    const idCapilla = this.authService.user()?.id_capilla;
    if (!idCapilla) {
      this.mensajeError.set('No tienes una capilla asignada.');
      return;
    }

    const payload = {
      titulo: this.nuevo.titulo.trim(),
      mensaje: this.nuevo.mensaje.trim(),
      id_capilla: idCapilla,
      estado: this.nuevo.estado ?? 'Enviado'
    };

    this.guardando.set(true);
    const obs = this.editando
      ? this.comunicadosService.editar(this.editando.id_comunicado, payload)
      : this.comunicadosService.crear(payload);

    obs.subscribe({
      next: () => {
        this.guardando.set(false);
        this.mensajeExito.set(this.editando ? 'Comunicado actualizado correctamente.' : 'Comunicado creado correctamente.');
        this.editando = null;
        this.nuevo = {};
        this.showModal = false;
        this.cargar();
      },
      error: (error) => {
        this.guardando.set(false);
        this.mensajeError.set(error?.error?.mensaje ?? 'No se pudo guardar el comunicado.');
      }
    });
  }

  closeOnOverlay(e: MouseEvent) {
    if (e.target === e.currentTarget) { this.showModal = false; this.editando = null; }
  }
}
