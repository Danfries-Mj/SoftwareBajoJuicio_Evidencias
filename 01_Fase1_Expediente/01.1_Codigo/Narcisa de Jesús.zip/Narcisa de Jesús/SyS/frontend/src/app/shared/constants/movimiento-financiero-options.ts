export const CATEGORIA_TIPOS: Record<string, string[]> = {
  'Colecta dominical': ['Ingreso'],
  'Donación': ['Ingreso'],
  'Aporte mensual capilla': ['Ingreso'],
  'Actividad parroquial': ['Ingreso', 'Egreso'],
  'Servicios básicos': ['Egreso'],
  'Compra de insumos': ['Egreso']
};

export const JUSTIFICACION_TIPOS: Record<string, string[]> = {
  'Colecta parroquial': ['Ingreso'],
  'Donación recibida': ['Ingreso'],
  'Aporte mensual de capilla': ['Ingreso'],
  'Evento parroquial': ['Ingreso', 'Egreso'],
  'Pago de servicios básicos': ['Egreso'],
  'Compra de insumos médicos': ['Egreso']
};

export function categoriasPorTipo(tipo: string): string[] {
  const claves = Object.keys(CATEGORIA_TIPOS);
  return tipo ? claves.filter(c => CATEGORIA_TIPOS[c].includes(tipo)) : claves;
}

export function justificacionesPorTipo(tipo: string): string[] {
  const claves = Object.keys(JUSTIFICACION_TIPOS);
  return tipo ? claves.filter(j => JUSTIFICACION_TIPOS[j].includes(tipo)) : claves;
}
