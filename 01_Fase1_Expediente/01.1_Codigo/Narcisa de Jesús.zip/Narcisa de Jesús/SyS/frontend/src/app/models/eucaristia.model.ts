export type DiaSemana = 'Domingo' | 'Lunes' | 'Martes' | 'Miercoles' | 'Jueves' | 'Viernes' | 'Sabado';
export type EstadoEucaristia = 'Activa' | 'Programada' | 'Cancelada' | 'Realizada';

export interface Eucaristia {
  id_eucaristia: number;
  id_capilla: number;
  capilla_nombre?: string;
  dia_semana: string;
  fecha: string;
  hora_inicio: string;
  hora_fin?: string;
  id_sacerdote?: number | null;
  estado: EstadoEucaristia;
}
