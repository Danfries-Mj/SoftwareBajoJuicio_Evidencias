import { Component, inject } from '@angular/core';
import { RouterLink, RouterLinkActive } from '@angular/router';
import { SidebarStateService } from '../../services/sidebar-state.service';

@Component({
  selector: 'app-sacerdote-sidebar',
  standalone: true,
  imports: [RouterLink, RouterLinkActive],
  templateUrl: './sacerdote-sidebar.html',
  styleUrl: './sacerdote-sidebar.css'
})
export class SacerdoteSidebarComponent {
  protected sidebarState = inject(SidebarStateService);
}
