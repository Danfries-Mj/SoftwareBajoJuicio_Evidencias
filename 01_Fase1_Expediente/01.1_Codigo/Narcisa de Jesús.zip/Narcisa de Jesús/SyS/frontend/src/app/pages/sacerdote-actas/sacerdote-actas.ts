import { Component, inject, OnInit, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { SlicePipe } from '@angular/common';
import { CapillasService } from '../../services/capillas.service';
import { ActasService } from '../../services/actas.service';
import { Capilla } from '../../models/capilla.model';
import { Acta } from '../../models/acta.model';
import { mensajesTemporales } from '../../shared/utils/mensajes-temporales';
import { autoRecarga } from '../../shared/utils/auto-recarga';
@Component({
  selector: 'app-sacerdote-actas',
  standalone: true,
  imports: [FormsModule, SlicePipe],
  templateUrl: './sacerdote-actas.html',
  styleUrl: './sacerdote-actas.css'
})
export class SacerdoteActasComponent implements OnInit {
  private capillasService = inject(CapillasService);
  private actasService = inject(ActasService);

  showModal = false;
  editando: Acta | null = null;
  actaSeleccionada: Acta | null = null;
  guardando = signal(false);
  mensajeError = mensajesTemporales(signal(''));

  actas = signal<Acta[]>([]);
  capillas = signal<Capilla[]>([]);

  tipos = ['Parroquial', 'Capilla'];
  estados = ['Borrador', 'Firmada'];

  nueva: Partial<Acta> = {};

  constructor() {
    autoRecarga(() => this.refrescar());
  }

  ngOnInit() {
    this.capillasService.listar().subscribe({ next: (c) => this.capillas.set(c) });
    this.cargarActas();
  }

  private cargarActas(mostrarError = true) {
    this.actasService.listar().subscribe({
      next: (actas) => this.actas.set(actas),
      error: () => { if (mostrarError) this.mensajeError.set('No se pudieron cargar las actas.'); }
    });
  }

  private refrescar() {
    this.cargarActas(false);
  }

  capillaNombre(a: Acta): string {
    if (a.tipo === 'Parroquial') return 'Toda la parroquia';
    return a.capilla_nombre ?? this.capillas().find(c => c.id_capilla === a.id_capilla)?.nombre ?? '—';
  }

  openModal() {
    this.editando = null;
    this.nueva = { tipo: 'Parroquial', estado: 'Borrador' };
    this.mensajeError.set('');
    this.showModal = true;
  }

  editar(a: Acta) {
    this.editando = a;
    this.nueva = {
      titulo: a.titulo,
      tipo: a.tipo,
      id_capilla: a.id_capilla,
      lugar: a.lugar,
      descripcion: a.descripcion,
      asistentes: a.asistentes,
      fecha: (a.fecha || '').slice(0, 10),
      proxima_reunion: a.proxima_reunion ? a.proxima_reunion.slice(0, 10) : '',
      estado: a.estado
    };
    this.mensajeError.set('');
    this.showModal = true;
  }

  eliminar(a: Acta) {
    if (!confirm('¿Eliminar esta acta?')) return;
    this.actasService.eliminar(a.id_acta).subscribe({
      next: () => this.cargarActas(),
      error: (error) => this.mensajeError.set(error?.error?.mensaje ?? 'No se pudo eliminar el acta.')
    });
  }

  guardar() {
    this.mensajeError.set('');

    if (!this.nueva.titulo || !this.nueva.tipo || !this.nueva.fecha) {
      this.mensajeError.set('Título, tipo y fecha son obligatorios.');
      return;
    }
    if (this.nueva.tipo === 'Capilla' && !this.nueva.id_capilla) {
      this.mensajeError.set('Selecciona la capilla para un acta de tipo Capilla.');
      return;
    }

    // Solo se exige fecha >= hoy al crear: un acta que se edita puede ser legítimamente
    // de una reunión ya pasada (se corrige descripción, asistentes, etc.), y eso es válido.
    const fechaActa = new Date(this.nueva.fecha + 'T00:00:00');
    if (!this.editando) {
      const hoy = new Date();
      hoy.setHours(0, 0, 0, 0);
      if (fechaActa < hoy) {
        this.mensajeError.set('La fecha del acta no puede ser anterior a la fecha actual.');
        return;
      }
    }

    if (this.nueva.proxima_reunion) {
      const fechaProxima = new Date(this.nueva.proxima_reunion + 'T00:00:00');
      if (fechaProxima < fechaActa) {
        this.mensajeError.set('La próxima reunión no puede ser anterior a la fecha del acta.');
        return;
      }
      // Las reuniones son mensuales, así que la próxima puede alejarse hasta 40 días.
      const diffDias = (fechaProxima.getTime() - fechaActa.getTime()) / (1000 * 60 * 60 * 24);
      if (diffDias > 40) {
        this.mensajeError.set('La próxima reunión no puede alejarse más de 40 días de la fecha del acta.');
        return;
      }
    }

    const datos: Partial<Acta> = {
      titulo: this.nueva.titulo,
      tipo: this.nueva.tipo,
      id_capilla: this.nueva.tipo === 'Capilla' ? Number(this.nueva.id_capilla) : null,
      lugar: this.nueva.lugar,
      descripcion: this.nueva.descripcion,
      asistentes: this.nueva.asistentes,
      fecha: this.nueva.fecha,
      proxima_reunion: this.nueva.proxima_reunion,
      estado: this.nueva.estado ?? 'Borrador'
    };

    this.guardando.set(true);
    const peticion = this.editando
      ? this.actasService.editar(this.editando.id_acta, datos)
      : this.actasService.crear(datos);

    peticion.subscribe({
      next: () => {
        this.guardando.set(false);
        this.showModal = false;
        this.editando = null;
        this.nueva = {};
        this.cargarActas();
      },
      error: (error) => {
        this.guardando.set(false);
        this.mensajeError.set(error?.error?.mensaje ?? 'No se pudo guardar el acta.');
      }
    });
  }

  verActa(a: Acta) {
    this.actaSeleccionada = a;
  }

  closeOnOverlay(e: MouseEvent) {
    if (e.target === e.currentTarget) this.showModal = false;
  }

  closeVerOnOverlay(e: MouseEvent) {
    if (e.target === e.currentTarget) this.actaSeleccionada = null;
  }
}
