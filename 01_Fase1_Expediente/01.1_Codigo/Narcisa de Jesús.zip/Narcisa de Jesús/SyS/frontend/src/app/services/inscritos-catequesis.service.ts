import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable, map } from 'rxjs';
import { API_URL } from '../core/config/api.config';
import { InscritoCatequesis } from '../models/inscrito-catequesis.model';

@Injectable({ providedIn: 'root' })
export class InscritosCatequesisService {
  private apiUrl = `${API_URL}/inscritos-catequesis`;

  constructor(private http: HttpClient) {}

  listar(filtros: { nivel?: string; estado?: string; nombre?: string; id_capilla?: number } = {}): Observable<InscritoCatequesis[]> {
    let params = new HttpParams();
    if (filtros.nivel) params = params.set('nivel', filtros.nivel);
    if (filtros.estado) params = params.set('estado', filtros.estado);
    if (filtros.nombre) params = params.set('nombre', filtros.nombre);
    if (filtros.id_capilla) params = params.set('id_capilla', filtros.id_capilla);

    return this.http.get<{ mensaje: string; total: number; inscritos: InscritoCatequesis[] }>(this.apiUrl, { params })
      .pipe(map(respuesta => respuesta.inscritos));
  }

  obtenerPorId(id: number): Observable<InscritoCatequesis> {
    return this.http.get<{ mensaje: string; inscrito: InscritoCatequesis }>(`${this.apiUrl}/${id}`)
      .pipe(map(respuesta => respuesta.inscrito));
  }

  crear(datos: Partial<InscritoCatequesis>): Observable<InscritoCatequesis> {
    return this.http.post<{ mensaje: string; inscrito: InscritoCatequesis }>(this.apiUrl, datos)
      .pipe(map(respuesta => respuesta.inscrito));
  }

  editar(id: number, datos: { id_catequista?: number; estado: string; nota?: string }): Observable<InscritoCatequesis> {
    return this.http.put<{ mensaje: string; inscrito: InscritoCatequesis }>(`${this.apiUrl}/${id}`, datos)
      .pipe(map(respuesta => respuesta.inscrito));
  }

  eliminar(id: number): Observable<{ mensaje: string; inscrito: InscritoCatequesis }> {
    return this.http.delete<{ mensaje: string; inscrito: InscritoCatequesis }>(`${this.apiUrl}/${id}`);
  }
}
