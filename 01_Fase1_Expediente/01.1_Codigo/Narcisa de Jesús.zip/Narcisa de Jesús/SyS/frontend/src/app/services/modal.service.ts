import { Injectable, signal } from '@angular/core';

@Injectable({ providedIn: 'root' })
export class ModalService {
  showLogin = signal(false);
  showRegister = signal(false);
  showForgotPassword = signal(false);
  showResetPassword = signal(false);

  /** Correo capturado en "Olvidé mi contraseña" para prellenarlo al ingresar el código. */
  correoRecuperacion = signal('');

  private cerrarTodos() {
    this.showLogin.set(false);
    this.showRegister.set(false);
    this.showForgotPassword.set(false);
    this.showResetPassword.set(false);
  }

  openLogin() {
    this.cerrarTodos();
    this.showLogin.set(true);
    document.body.style.overflow = 'hidden';
  }

  openRegister() {
    this.cerrarTodos();
    this.showRegister.set(true);
    document.body.style.overflow = 'hidden';
  }

  openForgotPassword() {
    this.cerrarTodos();
    this.showForgotPassword.set(true);
    document.body.style.overflow = 'hidden';
  }

  openResetPassword(correo: string) {
    this.cerrarTodos();
    this.correoRecuperacion.set(correo);
    this.showResetPassword.set(true);
    document.body.style.overflow = 'hidden';
  }

  closeAll() {
    this.cerrarTodos();
    document.body.style.overflow = '';
  }
}
