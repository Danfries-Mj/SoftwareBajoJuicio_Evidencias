import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable, map } from 'rxjs';
import { API_URL } from '../core/config/api.config';
import { MovimientoFinanciero } from '../models/movimiento-financiero.model';

@Injectable({ providedIn: 'root' })
export class MovimientosFinancierosService {
  private apiUrl = `${API_URL}/movimientos-financieros`;

  constructor(private http: HttpClient) {}

  listar(filtros: { id_fondo?: number; tipo?: string; fecha_desde?: string; fecha_hasta?: string } = {}): Observable<MovimientoFinanciero[]> {
    let params = new HttpParams();
    if (filtros.id_fondo) params = params.set('id_fondo', filtros.id_fondo);
    if (filtros.tipo) params = params.set('tipo', filtros.tipo);
    if (filtros.fecha_desde) params = params.set('fecha_desde', filtros.fecha_desde);
    if (filtros.fecha_hasta) params = params.set('fecha_hasta', filtros.fecha_hasta);

    return this.http.get<{ mensaje: string; total: number; movimientos: MovimientoFinanciero[] }>(this.apiUrl, { params })
      .pipe(map(respuesta => respuesta.movimientos));
  }

  obtenerPorId(id: number): Observable<MovimientoFinanciero> {
    return this.http.get<{ mensaje: string; movimiento: MovimientoFinanciero }>(`${this.apiUrl}/${id}`)
      .pipe(map(respuesta => respuesta.movimiento));
  }

  crear(datos: Partial<MovimientoFinanciero>): Observable<MovimientoFinanciero> {
    return this.http.post<{ mensaje: string; movimiento: MovimientoFinanciero }>(this.apiUrl, datos)
      .pipe(map(respuesta => respuesta.movimiento));
  }

  editar(id: number, datos: Partial<MovimientoFinanciero>): Observable<MovimientoFinanciero> {
    return this.http.put<{ mensaje: string; movimiento: MovimientoFinanciero }>(`${this.apiUrl}/${id}`, datos)
      .pipe(map(respuesta => respuesta.movimiento));
  }

  eliminar(id: number): Observable<{ mensaje: string; movimiento: MovimientoFinanciero }> {
    return this.http.delete<{ mensaje: string; movimiento: MovimientoFinanciero }>(`${this.apiUrl}/${id}`);
  }
}
