import { Component, inject, signal } from '@angular/core';
import { FormBuilder, ReactiveFormsModule, Validators } from '@angular/forms';
import { ModalService } from '../../services/modal.service';
import { AuthService } from '../../services/auth.service';
import { FormAlertComponent } from '../form-alert/form-alert';
import { mensajeDeError } from '../../shared/utils/validaciones';
import { mensajesTemporales } from '../../shared/utils/mensajes-temporales';

@Component({
  selector: 'app-forgot-password-modal',
  standalone: true,
  imports: [ReactiveFormsModule, FormAlertComponent],
  templateUrl: './forgot-password-modal.html',
  styleUrl: './forgot-password-modal.css'
})
export class ForgotPasswordModalComponent {
  protected modalService = inject(ModalService);
  private authService = inject(AuthService);
  private fb = inject(FormBuilder);

  cargando = signal(false);
  mensajeError = mensajesTemporales(signal(''));
  mensajeExito = mensajesTemporales(signal(''));
  mensajeDeError = mensajeDeError;

  form = this.fb.group({
    correo: ['', [Validators.required, Validators.email]]
  });

  enviar() {
    if (this.form.invalid) {
      this.form.markAllAsTouched();
      this.mensajeError.set('Ingresa un correo válido.');
      return;
    }

    const { correo } = this.form.getRawValue();
    this.mensajeError.set('');
    this.cargando.set(true);
    this.authService.solicitarRecuperacion(correo!).subscribe({
      next: (respuesta) => {
        this.cargando.set(false);
        this.mensajeExito.set(respuesta?.mensaje ?? 'Si el correo está registrado, enviamos un código de verificación.');
        setTimeout(() => this.modalService.openResetPassword(correo!), 1200);
      },
      error: (error) => {
        this.cargando.set(false);
        this.mensajeError.set(error?.error?.mensaje ?? 'No se pudo procesar la solicitud. Intenta nuevamente.');
      }
    });
  }

  irAIngresarCodigo() {
    const { correo } = this.form.getRawValue();
    this.modalService.openResetPassword(correo ?? '');
  }

  cerrar() {
    this.form.reset();
    this.mensajeError.set('');
    this.mensajeExito.set('');
    this.modalService.closeAll();
  }

  closeOnOverlay(event: MouseEvent) {
    if (event.target === event.currentTarget) {
      this.cerrar();
    }
  }
}
