import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable, map } from 'rxjs';
import { API_URL } from '../core/config/api.config';
import { Certificado } from '../models/certificado.model';

@Injectable({ providedIn: 'root' })
export class CertificadosService {
  private apiUrl = `${API_URL}/certificados`;

  constructor(private http: HttpClient) {}

  listar(filtros: { tipo?: string; estado?: string; id_persona?: number } = {}): Observable<Certificado[]> {
    let params = new HttpParams();
    if (filtros.tipo) params = params.set('tipo', filtros.tipo);
    if (filtros.estado) params = params.set('estado', filtros.estado);
    if (filtros.id_persona) params = params.set('id_persona', filtros.id_persona);

    return this.http.get<{ mensaje: string; total: number; certificados: Certificado[] }>(this.apiUrl, { params })
      .pipe(map(respuesta => respuesta.certificados));
  }

  /**
   * Comprueba si una persona ya tiene emitido un certificado de ese tipo exacto. Usa el
   * endpoint dedicado (no `listar`) porque un Laico puede necesitar verificar el
   * certificado de un TERCERO que está inscribiendo, no solo el suyo propio: `listar`
   * fuerza el id_persona del propio Laico y además expone el archivo del certificado,
   * que no hace falta para esta verificación.
   */
  tienePrerrequisitoEmitido(id_persona: number, tipo: string): Observable<boolean> {
    const params = new HttpParams().set('id_persona', id_persona).set('tipo', tipo);
    return this.http.get<{ mensaje: string; cumple: boolean }>(`${this.apiUrl}/verificar-prerequisito`, { params })
      .pipe(map(respuesta => respuesta.cumple));
  }

  obtenerPorId(id: number): Observable<Certificado> {
    return this.http.get<{ mensaje: string; certificado: Certificado }>(`${this.apiUrl}/${id}`)
      .pipe(map(respuesta => respuesta.certificado));
  }

  crear(datos: { tipo: string; id_capilla?: number | null; archivo_nombre?: string; archivo_url?: string; mime_type?: string; id_persona?: number }): Observable<Certificado> {
    return this.http.post<{ mensaje: string; certificado: Certificado }>(this.apiUrl, datos)
      .pipe(map(respuesta => respuesta.certificado));
  }

  emitir(id: number, datos: { fecha_emision: string; archivo_url?: string }): Observable<Certificado> {
    return this.http.put<{ mensaje: string; certificado: Certificado }>(`${this.apiUrl}/${id}/emitir`, datos)
      .pipe(map(respuesta => respuesta.certificado));
  }

  rechazar(id: number): Observable<Certificado> {
    return this.http.put<{ mensaje: string; certificado: Certificado }>(`${this.apiUrl}/${id}/rechazar`, {})
      .pipe(map(respuesta => respuesta.certificado));
  }

  eliminar(id: number): Observable<{ mensaje: string; certificado: Certificado }> {
    return this.http.delete<{ mensaje: string; certificado: Certificado }>(`${this.apiUrl}/${id}`);
  }
}
