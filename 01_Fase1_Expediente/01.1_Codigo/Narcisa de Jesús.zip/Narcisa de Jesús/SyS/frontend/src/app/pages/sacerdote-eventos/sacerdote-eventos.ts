import { Component, inject, OnInit, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { CapillasService } from '../../services/capillas.service';
import { EventosService } from '../../services/eventos.service';
import { Capilla } from '../../models/capilla.model';
import { Evento } from '../../models/evento.model';
import { mensajesTemporales } from '../../shared/utils/mensajes-temporales';
import { autoRecarga } from '../../shared/utils/auto-recarga';
import { OPCIONES_HORA } from '../../shared/utils/horarios-disponibles';
import { formatearFecha } from '../../shared/utils/date-format';
import { CATEGORIA_COLOR, claseBadgeCategoria, claseDotCategoria } from '../../shared/constants/categoria-colors';
@Component({
  selector: 'app-sacerdote-eventos',
  standalone: true,
  imports: [FormsModule],
  templateUrl: './sacerdote-eventos.html',
  styleUrl: './sacerdote-eventos.css'
})
export class SacerdoteEventosComponent implements OnInit {
  private capillasService = inject(CapillasService);
  private eventosService = inject(EventosService);
  protected formatearFecha = formatearFecha;
  protected claseBadgeCategoria = claseBadgeCategoria;
  protected claseDotCategoria = claseDotCategoria;
  protected categoriasLeyenda = Object.keys(CATEGORIA_COLOR);

  showModal = false;
  editando: Evento | null = null;
  guardando = signal(false);
  mensajeError = mensajesTemporales(signal(''));

  eventos = signal<Evento[]>([]);
  capillas = signal<Capilla[]>([]);

  tiposAmbito = ['Parroquial', 'Capilla'];
  categorias = ['Eucaristia', 'Evento', 'Reunion', 'Catequesis', 'Retiro', 'Procesion', 'Formacion', 'Otro'];
  estados = ['Proximo', 'Realizado'];
  opcionesHora = OPCIONES_HORA;

  nuevo: Partial<Evento> = {};

  private today = new Date();
  semana = ['Dom', 'Lun', 'Mar', 'Mié', 'Jue', 'Vie', 'Sáb'];
  diasCalendario = signal<(number | null)[]>([]);
  mesActual = signal('');

  constructor() {
    autoRecarga(() => this.refrescar());
  }

  ngOnInit() {
    this.capillasService.listar().subscribe({ next: (c) => this.capillas.set(c) });
    this.construirCalendario();
    this.cargarEventos();
  }

  private cargarEventos(mostrarError = true) {
    this.eventosService.listar().subscribe({
      next: (eventos) => this.eventos.set(eventos),
      error: () => { if (mostrarError) this.mensajeError.set('No se pudieron cargar los eventos.'); }
    });
  }

  private construirCalendario() {
    const year = this.today.getFullYear();
    const month = this.today.getMonth();
    const primerDia = new Date(year, month, 1);
    const offset = primerDia.getDay();
    const diasDelMes = new Date(year, month + 1, 0).getDate();

    this.diasCalendario.set([
      ...new Array(offset).fill(null),
      ...Array.from({ length: diasDelMes }, (_, i) => i + 1)
    ]);

    this.mesActual.set(primerDia.toLocaleDateString('es-ES', { month: 'long', year: 'numeric' }));
  }

  /** Categorías distintas con evento ese día del mes actual, para pintar un punto por cada una. */
  categoriasDelDia(dia: number | null): string[] {
    if (dia === null) return [];
    const year = this.today.getFullYear();
    const month = this.today.getMonth();
    const fechaStr = `${year}-${(month + 1).toString().padStart(2, '0')}-${dia.toString().padStart(2, '0')}`;
    const categorias = this.eventos()
      .filter(e => e.fecha?.slice(0, 10) === fechaStr)
      .map(e => e.categoria);
    return Array.from(new Set(categorias));
  }

  diasConEvento(dia: number | null): boolean {
    return this.categoriasDelDia(dia).length > 0;
  }

  /** Pinta la celda del día con el color de su categoría (la primera, si hay varias ese día). */
  claseCeldaDia(dia: number | null): string {
    const categorias = this.categoriasDelDia(dia);
    return categorias.length > 0 ? this.claseBadgeCategoria(categorias[0]) : '';
  }

  private refrescar() {
    this.cargarEventos(false);
  }

  capillaNombre(e: Evento): string {
    if (e.tipo_ambito === 'Parroquial') return 'Toda la parroquia';
    return e.capilla_nombre ?? this.capillas().find(c => c.id_capilla === e.id_capilla)?.nombre ?? '—';
  }

  get proximosEventos(): Evento[] {
    return this.eventos().filter(e => e.estado === 'Proximo').slice(0, 5);
  }

  openModal() {
    this.editando = null;
    this.nuevo = { tipo_ambito: 'Parroquial', categoria: 'Evento', estado: 'Proximo' };
    this.mensajeError.set('');
    this.showModal = true;
  }

  editar(e: Evento) {
    this.editando = e;
    this.nuevo = {
      ...e,
      fecha: e.fecha?.slice(0, 10),
      hora_inicio: e.hora_inicio?.slice(0, 5),
      hora_fin: e.hora_fin?.slice(0, 5)
    };
    this.mensajeError.set('');
    this.showModal = true;
  }

  eliminar(e: Evento) {
    if (!confirm('¿Eliminar este evento?')) return;
    this.eventosService.eliminar(e.id_evento).subscribe({
      next: () => this.cargarEventos(),
      error: (error) => this.mensajeError.set(error?.error?.mensaje ?? 'No se pudo eliminar el evento.')
    });
  }

  guardar() {
    this.mensajeError.set('');

    if (!this.nuevo.nombre || !this.nuevo.tipo_ambito || !this.nuevo.fecha) {
      this.mensajeError.set('Título, tipo de ámbito y fecha son obligatorios.');
      return;
    }
    if (this.nuevo.tipo_ambito === 'Capilla' && !this.nuevo.id_capilla) {
      this.mensajeError.set('Selecciona la capilla para un evento de ámbito Capilla.');
      return;
    }

    const hoy = new Date();
    hoy.setHours(0, 0, 0, 0);
    const fechaEvento = new Date(this.nuevo.fecha + 'T00:00:00');
    if (this.nuevo.estado !== 'Realizado' && fechaEvento < hoy) {
      this.mensajeError.set('La fecha del evento no puede ser anterior a la fecha actual.');
      return;
    }
    if (this.nuevo.hora_inicio && this.nuevo.hora_fin && this.nuevo.hora_inicio >= this.nuevo.hora_fin) {
      this.mensajeError.set('La hora de inicio debe ser anterior a la hora de fin.');
      return;
    }

    if (this.nuevo.categoria === 'Eucaristia' && this.nuevo.fecha && this.nuevo.hora_inicio) {
      const duplicada = this.eventos().some(e =>
        e.categoria === 'Eucaristia' &&
        e.fecha?.slice(0, 10) === this.nuevo.fecha &&
        e.hora_inicio?.slice(0, 5) === this.nuevo.hora_inicio?.slice(0, 5) &&
        e.id_evento !== this.editando?.id_evento
      );
      if (duplicada) {
        this.mensajeError.set('Ya hay una eucaristía asignada a esta hora.');
        return;
      }
    }

    const datos: Partial<Evento> = {
      nombre: this.nuevo.nombre,
      descripcion: this.nuevo.descripcion,
      tipo_ambito: this.nuevo.tipo_ambito,
      categoria: this.nuevo.categoria ?? 'Evento',
      id_capilla: this.nuevo.tipo_ambito === 'Capilla' ? Number(this.nuevo.id_capilla) : null,
      fecha: this.nuevo.fecha,
      hora_inicio: this.nuevo.hora_inicio,
      hora_fin: this.nuevo.hora_fin,
      lugar: this.nuevo.lugar,
      estado: this.nuevo.estado ?? 'Proximo'
    };

    this.guardando.set(true);
    const peticion = this.editando
      ? this.eventosService.editar(this.editando.id_evento, datos)
      : this.eventosService.crear(datos);

    peticion.subscribe({
      next: () => {
        this.guardando.set(false);
        this.showModal = false;
        this.editando = null;
        this.nuevo = {};
        this.cargarEventos();
      },
      error: (error) => {
        this.guardando.set(false);
        this.mensajeError.set(error?.error?.mensaje ?? 'No se pudo guardar el evento.');
      }
    });
  }

  closeOnOverlay(e: MouseEvent) {
    if (e.target === e.currentTarget) this.showModal = false;
  }
}
