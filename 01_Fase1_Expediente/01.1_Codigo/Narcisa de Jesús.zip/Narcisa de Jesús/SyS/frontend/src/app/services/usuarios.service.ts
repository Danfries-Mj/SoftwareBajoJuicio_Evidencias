import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable, map } from 'rxjs';
import { API_URL } from '../core/config/api.config';
import { Usuario } from '../models/usuario.model';

export interface NuevoUsuario {
  cedula: string;
  nombres: string;
  apellidos: string;
  telefono?: string;
  correo: string;
  contrasena: string;
  rol: string;
  id_capilla: number | null;
}

export interface PerfilUsuario {
  nombres: string;
  apellidos: string;
  telefono?: string;
  correo: string;
  contrasena?: string;
}

@Injectable({ providedIn: 'root' })
export class UsuariosService {
  private apiUrl = `${API_URL}/usuarios`;

  constructor(private http: HttpClient) {}

  listar(filtros: { rol?: string; id_capilla?: number } = {}): Observable<Usuario[]> {
    let params = new HttpParams();
    if (filtros.rol) params = params.set('rol', filtros.rol);
    if (filtros.id_capilla) params = params.set('id_capilla', filtros.id_capilla);

    return this.http.get<{ mensaje: string; total: number; usuarios: Usuario[] }>(this.apiUrl, { params })
      .pipe(map(respuesta => respuesta.usuarios));
  }

  obtenerPorId(id: number): Observable<Usuario> {
    return this.http.get<{ mensaje: string; usuario: Usuario }>(`${this.apiUrl}/${id}`)
      .pipe(map(respuesta => respuesta.usuario));
  }

  /**
   * Requiere el endpoint GET /usuarios/cedula/:cedula en el backend (mismo patrón que
   * PersonasService.buscarPorCedula). Aún no implementado del lado del servidor: se deja
   * la llamada lista para cuando exista; mientras tanto responderá 404/error.
   */
  buscarPorCedula(cedula: string): Observable<Usuario> {
    return this.http.get<{ mensaje: string; usuario: Usuario }>(`${this.apiUrl}/cedula/${cedula}`)
      .pipe(map(respuesta => respuesta.usuario));
  }

  crear(usuario: NuevoUsuario): Observable<Usuario> {
    return this.http.post<{ mensaje: string; usuario: Usuario }>(this.apiUrl, usuario)
      .pipe(map(respuesta => respuesta.usuario));
  }

  editar(id: number, datos: { rol: string; id_capilla: number | null; activo?: boolean }): Observable<Usuario> {
    return this.http.put<{ mensaje: string; usuario: Usuario }>(`${this.apiUrl}/${id}`, datos)
      .pipe(map(respuesta => respuesta.usuario));
  }

  editarPerfil(id: number, datos: PerfilUsuario): Observable<Usuario> {
    return this.http.put<{ mensaje: string; usuario: Usuario }>(`${this.apiUrl}/${id}/perfil`, datos)
      .pipe(map(respuesta => respuesta.usuario));
  }

  desactivar(id: number): Observable<Usuario> {
    return this.http.put<{ mensaje: string; usuario: Usuario }>(`${this.apiUrl}/${id}/desactivar`, {})
      .pipe(map(respuesta => respuesta.usuario));
  }

  activar(id: number): Observable<Usuario> {
    return this.http.put<{ mensaje: string; usuario: Usuario }>(`${this.apiUrl}/${id}/activar`, {})
      .pipe(map(respuesta => respuesta.usuario));
  }
}
