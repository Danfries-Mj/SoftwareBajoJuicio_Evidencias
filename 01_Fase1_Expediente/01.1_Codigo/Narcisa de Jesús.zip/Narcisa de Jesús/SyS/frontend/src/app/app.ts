import { Component, computed, inject } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { NavbarComponent } from './components/navbar/navbar';
import { LoginModalComponent } from './components/login-modal/login-modal';
import { RegisterModalComponent } from './components/register-modal/register-modal';
import { ForgotPasswordModalComponent } from './components/forgot-password-modal/forgot-password-modal';
import { ResetPasswordModalComponent } from './components/reset-password-modal/reset-password-modal';
import { SacerdoteSidebarComponent } from './components/sacerdote-sidebar/sacerdote-sidebar';
import { FooterComponent } from './components/footer/footer';
import { AuthService } from './services/auth.service';
import { SidebarStateService } from './services/sidebar-state.service';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [
    RouterOutlet,
    NavbarComponent,
    LoginModalComponent,
    RegisterModalComponent,
    ForgotPasswordModalComponent,
    ResetPasswordModalComponent,
    SacerdoteSidebarComponent,
    FooterComponent
  ],
  templateUrl: './app.html',
  styleUrl: './app.css'
})
export class App {
  private authService = inject(AuthService);
  protected sidebarState = inject(SidebarStateService);
  protected isSacerdote = computed(() => this.authService.user()?.rol === 'Sacerdote');
}
