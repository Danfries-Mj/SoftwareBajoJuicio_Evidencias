export type TipoActa = 'Parroquial' | 'Capilla';
export type EstadoActa = 'Borrador' | 'Firmada';

export interface Acta {
  id_acta: number;
  numero?: string;
  titulo: string;
  tipo: TipoActa;
  id_capilla?: number | null;
  capilla_nombre?: string;
  lugar?: string;
  descripcion?: string;
  asistentes?: number;
  fecha: string;
  proxima_reunion?: string;
  estado: EstadoActa;
  creado_por?: number;
}
