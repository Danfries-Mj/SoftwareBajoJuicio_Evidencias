import { Component, inject, OnInit, signal, computed } from '@angular/core';
import { SlicePipe } from '@angular/common';
import { AuthService } from '../../services/auth.service';
import { InscritosCatequesisService } from '../../services/inscritos-catequesis.service';
import { InscritoCatequesis } from '../../models/inscrito-catequesis.model';
import { mensajesTemporales } from '../../shared/utils/mensajes-temporales';
import { autoRecarga } from '../../shared/utils/auto-recarga';

@Component({
  selector: 'app-catequista-inicio',
  standalone: true,
  imports: [SlicePipe],
  templateUrl: './catequista-inicio.html',
  styleUrl: './catequista-inicio.css'
})
export class CatequistaInicioComponent implements OnInit {
  private authService = inject(AuthService);
  private inscritosService = inject(InscritosCatequesisService);

  get nombre() { return this.authService.user()?.nombres ?? ''; }
  get capilla() { return this.authService.user()?.capilla ?? ''; }

  inscritos = signal<InscritoCatequesis[]>([]);
  mensajeError = mensajesTemporales(signal(''));

  totalInscritos = computed(() => this.inscritos().length);
  totalActivos = computed(() => this.inscritos().filter(i => i.estado === 'Activo').length);
  totalPendientes = computed(() => this.inscritos().filter(i => i.estado === 'Pendiente').length);

  constructor() {
    autoRecarga(() => this.refrescar());
  }

  ngOnInit() {
    this.cargar();
  }

  private cargar(mostrarError = true) {
    this.inscritosService.listar().subscribe({
      next: (data) => this.inscritos.set(data),
      error: (error) => { if (mostrarError) this.mensajeError.set(error?.error?.mensaje ?? 'No se pudieron cargar tus inscritos.'); }
    });
  }

  private refrescar() {
    this.cargar(false);
  }
}
