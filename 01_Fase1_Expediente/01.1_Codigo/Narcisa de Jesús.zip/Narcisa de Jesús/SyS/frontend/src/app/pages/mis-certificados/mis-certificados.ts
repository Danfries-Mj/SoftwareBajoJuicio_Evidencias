import { Component, inject, OnInit, signal } from '@angular/core';
import { SlicePipe } from '@angular/common';
import { CertificadosService } from '../../services/certificados.service';
import { CapillasService } from '../../services/capillas.service';
import { descargarDocumento } from '../../services/documentos.service';
import { Certificado } from '../../models/certificado.model';
import { mensajesTemporales } from '../../shared/utils/mensajes-temporales';

@Component({
  selector: 'app-mis-certificados',
  standalone: true,
  imports: [SlicePipe],
  templateUrl: './mis-certificados.html',
  styleUrl: './mis-certificados.css'
})
export class MisCertificadosComponent implements OnInit {
  private certificadosService = inject(CertificadosService);
  private capillasService = inject(CapillasService);

  certificados = signal<Certificado[]>([]);
  mensajeError = mensajesTemporales(signal(''));
  private capillasMap = new Map<number, string>();

  ngOnInit() {
    this.capillasService.listar().subscribe({
      next: (capillas) => capillas.forEach(c => this.capillasMap.set(c.id_capilla, c.nombre))
    });

    this.certificadosService.listar().subscribe({
      next: (data) => this.certificados.set(data),
      error: () => this.mensajeError.set('No se pudo cargar tus certificados.')
    });
  }

  capillaNombre(idCapilla: number | null | undefined): string {
    if (!idCapilla) return '—';
    return this.capillasMap.get(idCapilla) ?? '—';
  }

  descargar(c: Certificado) {
    if (!c.archivo_url) return;
    descargarDocumento(c, c.archivo_nombre ?? `Certificado-${c.tipo}`);
  }
}
