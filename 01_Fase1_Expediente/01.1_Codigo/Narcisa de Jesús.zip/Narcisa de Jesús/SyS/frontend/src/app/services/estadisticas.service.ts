import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, map } from 'rxjs';
import { API_URL } from '../core/config/api.config';

export interface EstadisticasPublicas {
  capillas: number;
  catequizandos: number;
  catequistas: number;
}

@Injectable({ providedIn: 'root' })
export class EstadisticasService {
  private apiUrl = `${API_URL}/estadisticas`;

  constructor(private http: HttpClient) {}

  /** Endpoint público: no requiere sesión, se usa en la página "Sobre Nosotros". */
  publicas(): Observable<EstadisticasPublicas> {
    return this.http.get<{ mensaje: string; estadisticas: EstadisticasPublicas }>(`${this.apiUrl}/publicas`)
      .pipe(map(respuesta => respuesta.estadisticas));
  }
}
