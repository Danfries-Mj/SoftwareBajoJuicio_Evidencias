import { Component, OnInit, inject, signal } from '@angular/core';
import { InscritosCatequesisService } from '../../services/inscritos-catequesis.service';
import { InscritoCatequesis } from '../../models/inscrito-catequesis.model';
import { AuthService } from '../../services/auth.service';
import { mensajesTemporales } from '../../shared/utils/mensajes-temporales';
import { autoRecarga } from '../../shared/utils/auto-recarga';

interface GrupoCapilla {
  capilla: string;
  inscritos: number;
  monto: number;
}

@Component({
  selector: 'app-tesorero-catequesis',
  standalone: true,
  imports: [],
  templateUrl: './tesorero-catequesis.html',
  styleUrl: './tesorero-catequesis.css'
})
export class TesoreroCatequesisComponent implements OnInit {
  private inscritosService = inject(InscritosCatequesisService);
  private authService = inject(AuthService);

  // El tesorero general (sin capilla asignada) ve los valores de todas las
  // capillas; el tesorero de una capilla solo ve los de la suya (el backend ya
  // filtra la respuesta), así que aquí solo se decide el rótulo a mostrar.
  get esTesoreroGeneral(): boolean {
    return !this.authService.user()?.id_capilla;
  }

  mensajeError = mensajesTemporales(signal(''));

  primera = signal<GrupoCapilla[]>([]);
  confirmacion = signal<GrupoCapilla[]>([]);

  totalPrimera = signal(0);
  totalConfirmacion = signal(0);
  inscritosPrimera = signal(0);
  inscritosConfirmacion = signal(0);
  capillasCount = signal(0);

  constructor() {
    autoRecarga(() => this.refrescar());
  }

  ngOnInit() {
    this.cargar();
  }

  private cargar(mostrarError = true) {
    this.inscritosService.listar().subscribe({
      next: (inscritos) => this.procesar(inscritos),
      error: () => { if (mostrarError) this.mensajeError.set('No se pudieron cargar los inscritos de catequesis.'); }
    });
  }

  private refrescar() {
    this.cargar(false);
  }

  private procesar(inscritos: InscritoCatequesis[]) {
    const primera = inscritos.filter(i => i.nivel === 'Primera Comunion');
    const confirmacion = inscritos.filter(i => i.nivel === 'Confirmacion');

    this.primera.set(this.agrupar(primera));
    this.confirmacion.set(this.agrupar(confirmacion));

    this.inscritosPrimera.set(primera.length);
    this.inscritosConfirmacion.set(confirmacion.length);
    this.totalPrimera.set(primera.reduce((s, i) => s + Number(i.monto ?? 0), 0));
    this.totalConfirmacion.set(confirmacion.reduce((s, i) => s + Number(i.monto ?? 0), 0));

    const capillas = new Set(inscritos.map(i => i.capilla_nombre ?? i.id_capilla));
    this.capillasCount.set(capillas.size);
  }

  private agrupar(inscritos: InscritoCatequesis[]): GrupoCapilla[] {
    const mapa = new Map<string, GrupoCapilla>();
    for (const i of inscritos) {
      const capilla = i.capilla_nombre ?? `Capilla ${i.id_capilla}`;
      const actual = mapa.get(capilla) ?? { capilla, inscritos: 0, monto: 0 };
      actual.inscritos += 1;
      actual.monto += Number(i.monto ?? 0);
      mapa.set(capilla, actual);
    }
    return Array.from(mapa.values());
  }

  pct(grupo: GrupoCapilla, lista: GrupoCapilla[]): number {
    const max = Math.max(1, ...lista.map(g => g.inscritos));
    return Math.round((grupo.inscritos / max) * 100);
  }

  get totalRecaudado(): number {
    return this.totalPrimera() + this.totalConfirmacion();
  }
}
