import { Component, OnInit, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { SlicePipe } from '@angular/common';
import { AuthService } from '../../services/auth.service';
import { ActasService } from '../../services/actas.service';
import { Acta } from '../../models/acta.model';
import { mensajesTemporales } from '../../shared/utils/mensajes-temporales';
import { autoRecarga } from '../../shared/utils/auto-recarga';

interface NuevaActa {
  titulo?: string;
  fecha?: string;
  lugar?: string;
  descripcion?: string;
  asistentes?: number;
  proxima_reunion?: string;
}

@Component({
  selector: 'app-coordinador-actas',
  standalone: true,
  imports: [FormsModule, SlicePipe],
  templateUrl: './coordinador-actas.html',
  styleUrl: './coordinador-actas.css'
})
export class CoordinadorActasComponent implements OnInit {
  private authService = inject(AuthService);
  private actasService = inject(ActasService);

  showModal = false;
  guardando = signal(false);
  mensajeError = mensajesTemporales(signal(''));
  mensajeExito = mensajesTemporales(signal(''));

  actas = signal<Acta[]>([]);

  nueva: NuevaActa = {};
  editando: Acta | null = null;
  actaSeleccionada: Acta | null = null;

  get capilla() { return this.authService.user()?.capilla ?? ''; }

  /** El coordinador solo puede editar las actas de tipo Capilla que sean de la suya; las parroquiales son de solo lectura. */
  puedeEditar(a: Acta): boolean {
    return a.tipo === 'Capilla' && a.id_capilla === this.authService.user()?.id_capilla;
  }

  capillaNombre(a: Acta): string {
    if (a.tipo === 'Parroquial') return 'Toda la parroquia';
    return a.capilla_nombre ?? this.capilla;
  }

  verActa(a: Acta) {
    this.actaSeleccionada = a;
  }

  closeVerOnOverlay(e: MouseEvent) {
    if (e.target === e.currentTarget) this.actaSeleccionada = null;
  }

  constructor() {
    autoRecarga(() => this.refrescar());
  }

  ngOnInit() {
    this.cargar();
  }

  private cargar(mostrarError = true) {
    const idCapilla = this.authService.user()?.id_capilla ?? undefined;
    this.actasService.listar({ id_capilla: idCapilla }).subscribe({
      next: (data) => this.actas.set(data),
      error: () => { if (mostrarError) this.mensajeError.set('No se pudieron cargar las actas.'); }
    });
  }

  private refrescar() {
    this.cargar(false);
  }

  openModal() {
    this.nueva = { lugar: '', asistentes: 0 };
    this.editando = null;
    this.mensajeError.set('');
    this.showModal = true;
  }

  editarActa(a: Acta) {
    if (!this.puedeEditar(a)) return;
    this.nueva = {
      titulo: a.titulo,
      fecha: (a.fecha || '').slice(0, 10),
      lugar: a.lugar,
      descripcion: a.descripcion,
      asistentes: a.asistentes,
      proxima_reunion: a.proxima_reunion ? a.proxima_reunion.slice(0, 10) : ''
    };
    this.editando = a;
    this.mensajeError.set('');
    this.showModal = true;
  }

  guardar() {
    this.mensajeError.set('');

    if (!this.nueva.titulo?.trim() || !this.nueva.fecha) {
      this.mensajeError.set('El título y la fecha son obligatorios.');
      return;
    }

    // Solo se exige fecha >= hoy al crear: un acta que se edita puede ser legítimamente
    // de una reunión ya pasada (se corrige descripción, asistentes, etc.), y eso es válido.
    const fechaActa = new Date(this.nueva.fecha + 'T00:00:00');
    if (!this.editando) {
      const hoy = new Date();
      hoy.setHours(0, 0, 0, 0);
      if (fechaActa < hoy) {
        this.mensajeError.set('La fecha del acta no puede ser anterior a la fecha actual.');
        return;
      }
    }

    if (this.nueva.proxima_reunion) {
      const fechaProxima = new Date(this.nueva.proxima_reunion + 'T00:00:00');
      if (fechaProxima < fechaActa) {
        this.mensajeError.set('La próxima reunión no puede ser anterior a la fecha del acta.');
        return;
      }
      // Las reuniones de capilla son mensuales, así que la próxima puede alejarse hasta 40 días.
      const diffDias = (fechaProxima.getTime() - fechaActa.getTime()) / (1000 * 60 * 60 * 24);
      if (diffDias > 40) {
        this.mensajeError.set('La próxima reunión no puede alejarse más de 40 días de la fecha del acta.');
        return;
      }
    }

    const idCapilla = this.authService.user()?.id_capilla;
    if (!idCapilla) {
      this.mensajeError.set('No tienes una capilla asignada.');
      return;
    }

    const payload: Partial<Acta> = {
      titulo: this.nueva.titulo.trim(),
      tipo: 'Capilla',
      id_capilla: idCapilla,
      lugar: this.nueva.lugar || undefined,
      descripcion: this.nueva.descripcion || undefined,
      asistentes: this.nueva.asistentes ?? undefined,
      fecha: this.nueva.fecha,
      proxima_reunion: this.nueva.proxima_reunion || undefined
    };

    this.guardando.set(true);
    const obs = this.editando
      ? this.actasService.editar(this.editando.id_acta, payload)
      : this.actasService.crear(payload);

    obs.subscribe({
      next: () => {
        this.guardando.set(false);
        this.mensajeExito.set(this.editando ? 'Acta actualizada correctamente.' : 'Acta registrada correctamente.');
        this.editando = null;
        this.nueva = {};
        this.showModal = false;
        this.cargar();
      },
      error: (error) => {
        this.guardando.set(false);
        this.mensajeError.set(error?.error?.mensaje ?? 'No se pudo guardar el acta.');
      }
    });
  }

  closeOnOverlay(e: MouseEvent) {
    if (e.target === e.currentTarget) this.showModal = false;
  }
}
