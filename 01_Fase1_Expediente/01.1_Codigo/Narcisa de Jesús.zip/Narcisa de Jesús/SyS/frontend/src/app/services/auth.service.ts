import { Injectable, signal, computed, inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, map, of, switchMap, tap, catchError } from 'rxjs';
import { SessionStorageService } from './session-storage.service';
import { CapillasService } from './capillas.service';
import { API_URL } from '../core/config/api.config';

export interface UserInfo {
  id_usuario: number;
  nombres: string;
  apellidos: string;
  cedula: string;
  telefono: string;
  email: string;
  rol: string;
  id_capilla: number | null;
  capilla: string;
}

interface UsuarioApi {
  id_usuario: number;
  id_persona: number;
  cedula: string;
  nombres: string;
  apellidos: string;
  telefono: string;
  correo: string;
  rol: string;
  id_capilla: number | null;
  activo: boolean;
}

export interface RegistroLaico {
  cedula: string;
  nombres: string;
  apellidos: string;
  telefono: string;
  correo: string;
  contrasena: string;
  id_capilla: number | null;
}

const AUTH_KEY = 'auth_user';
const TOKEN_KEY = 'auth_token';

@Injectable({ providedIn: 'root' })
export class AuthService {
  private http = inject(HttpClient);
  private storage = inject(SessionStorageService);
  private capillasService = inject(CapillasService);

  private _user = signal<UserInfo | null>(this.storage.get<UserInfo>(AUTH_KEY));
  private _token = signal<string | null>(this.storage.get<string>(TOKEN_KEY));

  readonly user = this._user.asReadonly();
  readonly token = this._token.asReadonly();
  readonly isLoggedIn = computed(() => this._user() !== null);
  readonly fullName = computed(() => {
    const u = this._user();
    return u ? `${u.nombres} ${u.apellidos}` : '';
  });
  readonly shortName = computed(() => {
    const u = this._user();
    return u ? `${u.nombres.split(' ')[0]} ${u.apellidos.split(' ')[0]}` : '';
  });

  private mapUsuario(u: UsuarioApi, capillaNombre: string): UserInfo {
    return {
      id_usuario: u.id_usuario,
      nombres: u.nombres,
      apellidos: u.apellidos,
      cedula: u.cedula,
      telefono: u.telefono ?? '',
      email: u.correo,
      rol: u.rol,
      id_capilla: u.id_capilla,
      capilla: capillaNombre
    };
  }

  iniciarSesion(correo: string, contrasena: string): Observable<UserInfo> {
    return this.http.post<{ mensaje: string; usuario: UsuarioApi; token: string }>(
      `${API_URL}/auth/login`, { correo, contrasena }
    ).pipe(
      switchMap(respuesta => {
        this._token.set(respuesta.token);
        this.storage.set(TOKEN_KEY, respuesta.token);

        const u = respuesta.usuario;

        if (!u.id_capilla) {
            const etiqueta = u.rol === 'Sacerdote' ? 'Nuestra Señora de Guadalupe' : (u.rol === 'Tesorero' ? 'Parroquia' : '');
            return of(this.mapUsuario(u, etiqueta));
        }

        return this.capillasService.obtenerPorId(u.id_capilla).pipe(
          map(capilla => this.mapUsuario(u, capilla.nombre)),
          catchError(() => of(this.mapUsuario(u, '')))
        );
      }),
      tap(userInfo => this.login(userInfo))
    );
  }

  registrarLaico(datos: RegistroLaico): Observable<{ mensaje: string; usuario: UsuarioApi }> {
    return this.http.post<{ mensaje: string; usuario: UsuarioApi }>(`${API_URL}/auth/registro`, datos);
  }

  /**
   * Endpoint público: no requiere sesión, se usa mientras el usuario llena el formulario
   * de registro. Si la cédula ya tiene una persona registrada sin cuenta (p. ej. de una
   * inscripción de catequesis de un tercero, o el bautizando de una solicitud), viene en
   * `personaExistente` para autocompletar el formulario: el registro sigue disponible,
   * solo que se vinculará a esa persona en vez de crear una nueva.
   */
  cedulaDisponible(cedula: string): Observable<{ disponible: boolean; personaExistente: { nombres: string; apellidos: string; telefono: string | null } | null }> {
    return this.http.get<{ disponible: boolean; personaExistente: { nombres: string; apellidos: string; telefono: string | null } | null }>(`${API_URL}/auth/cedula-disponible/${cedula}`);
  }

  /**
   * Requiere que el backend implemente POST /auth/olvide-contrasena: recibe { correo },
   * genera un código de un solo uso con expiración corta (ej. 15 min) y lo envía por correo.
   * Por seguridad (no revelar qué correos existen) debe responder 200 con un mensaje genérico
   * tanto si el correo existe como si no.
   */
  solicitarRecuperacion(correo: string): Observable<{ mensaje: string }> {
    return this.http.post<{ mensaje: string }>(`${API_URL}/auth/olvide-contrasena`, { correo });
  }

  /**
   * Requiere que el backend implemente POST /auth/restablecer-contrasena: recibe
   * { correo, codigo, contrasena }, valida que el código sea correcto y no haya expirado,
   * actualiza la contraseña y lo invalida. Debe responder 400 con mensaje claro si el código
   * es inválido o expiró.
   */
  restablecerContrasena(datos: { correo: string; codigo: string; contrasena: string }): Observable<{ mensaje: string }> {
    return this.http.post<{ mensaje: string }>(`${API_URL}/auth/restablecer-contrasena`, datos);
  }

  login(user: UserInfo) {
    this._user.set(user);
    this.storage.set(AUTH_KEY, user);
  }

  logout() {
    this._user.set(null);
    this._token.set(null);
    this.storage.remove(AUTH_KEY);
    this.storage.remove(TOKEN_KEY);
  }
}
