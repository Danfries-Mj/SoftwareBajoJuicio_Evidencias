import { AbstractControl, ValidationErrors, ValidatorFn } from '@angular/forms';

/** Algoritmo módulo 10 oficial para validar una cédula ecuatoriana de 10 dígitos. */
export function esCedulaEcuatorianaValida(cedula: string): boolean {
  if (!/^\d{10}$/.test(cedula)) return false;

  const digitos = cedula.split('').map(Number);
  const provincia = digitos[0] * 10 + digitos[1];
  if (provincia < 1 || provincia > 24) return false;
  if (digitos[2] > 6) return false;

  const coeficientes = [2, 1, 2, 1, 2, 1, 2, 1, 2];
  let suma = 0;
  for (let i = 0; i < 9; i++) {
    let valor = digitos[i] * coeficientes[i];
    if (valor > 9) valor -= 9;
    suma += valor;
  }

  const decenaSuperior = Math.ceil(suma / 10) * 10;
  const digitoVerificador = decenaSuperior - suma === 10 ? 0 : decenaSuperior - suma;
  return digitoVerificador === digitos[9];
}

/** Deja solo dígitos y recorta a maxLength; para inputs sin FormControl (template-driven). */
export function soloDigitos(valor: string | null | undefined, maxLength: number): string {
  return (valor ?? '').replace(/\D/g, '').slice(0, maxLength);
}

export function cedulaEcuatorianaValidator(): ValidatorFn {
  return (control: AbstractControl): ValidationErrors | null => {
    const valor = (control.value ?? '').toString().trim();
    if (!valor) return null;
    return esCedulaEcuatorianaValida(valor) ? null : { cedulaInvalida: true };
  };
}

export function telefonoEcuadorValidator(): ValidatorFn {
  return (control: AbstractControl): ValidationErrors | null => {
    const valor = (control.value ?? '').toString().trim();
    if (!valor) return null;
    return /^0\d{9}$/.test(valor) ? null : { telefonoInvalido: true };
  };
}

export function soloTextoValidator(): ValidatorFn {
  return (control: AbstractControl): ValidationErrors | null => {
    const valor = (control.value ?? '').toString().trim();
    if (!valor) return null;
    return /^[A-Za-zÁÉÍÓÚáéíóúÑñÜü\s]+$/.test(valor) ? null : { soloTexto: true };
  };
}

/** Acepta de 1 a 3 palabras (ej. "Juan", "Juan Carlos", "María José"). */
export function nombresValidator(): ValidatorFn {
  return (control: AbstractControl): ValidationErrors | null => {
    const valor = (control.value ?? '').toString().trim();
    if (!valor) return null;
    const palabras = valor.split(/\s+/).filter(Boolean);
    return palabras.length >= 1 && palabras.length <= 3 ? null : { nombresInvalidos: true };
  };
}

/** Acepta de 2 a 5 palabras (ej. "Pérez Gómez", "Gómez de la Cruz"). */
export function apellidosValidator(): ValidatorFn {
  return (control: AbstractControl): ValidationErrors | null => {
    const valor = (control.value ?? '').toString().trim();
    if (!valor) return null;
    const palabras = valor.split(/\s+/).filter(Boolean);
    return palabras.length >= 2 && palabras.length <= 5 ? null : { apellidosInvalidos: true };
  };
}

export function montoPositivoValidator(): ValidatorFn {
  return (control: AbstractControl): ValidationErrors | null => {
    const valor = control.value;
    if (valor === null || valor === undefined || valor === '') return null;
    const num = typeof valor === 'number' ? valor : parseFloat(String(valor).replace(',', '.'));
    if (isNaN(num) || num <= 0) return { montoInvalido: true };
    if (!/^\d+(\.\d{1,2})?$/.test(num.toString())) return { montoInvalido: true };
    return null;
  };
}

export function montoMinimoValidator(minimo: number): ValidatorFn {
  return (control: AbstractControl): ValidationErrors | null => {
    const valor = control.value;
    if (valor === null || valor === undefined || valor === '') return null;
    const num = typeof valor === 'number' ? valor : parseFloat(String(valor).replace(',', '.'));
    if (isNaN(num)) return null;
    return num >= minimo ? null : { montoMinimo: { minimo } };
  };
}

export function fechaNoPasadaValidator(): ValidatorFn {
  return (control: AbstractControl): ValidationErrors | null => {
    const valor = control.value;
    if (!valor) return null;
    const fecha = new Date(valor);
    const hoy = new Date();
    hoy.setHours(0, 0, 0, 0);
    return fecha >= hoy ? null : { fechaPasada: true };
  };
}

export function fechaNoFuturaValidator(): ValidatorFn {
  return (control: AbstractControl): ValidationErrors | null => {
    const valor = control.value;
    if (!valor) return null;
    const fecha = new Date(valor);
    const hoy = new Date();
    hoy.setHours(23, 59, 59, 999);
    return fecha <= hoy ? null : { fechaFutura: true };
  };
}

export function codigoRecuperacionValidator(): ValidatorFn {
  return (control: AbstractControl): ValidationErrors | null => {
    const valor = (control.value ?? '').toString().trim();
    if (!valor) return null;
    return /^\d{6}$/.test(valor) ? null : { codigoInvalido: true };
  };
}

export function passwordSeguraValidator(): ValidatorFn {
  return (control: AbstractControl): ValidationErrors | null => {
    const valor = (control.value ?? '').toString();
    if (!valor) return null;
    const errores: string[] = [];
    if (valor.length < 8) errores.push('mínimo 8 caracteres');
    if (!/[A-Z]/.test(valor)) errores.push('una mayúscula');
    if (!/[a-z]/.test(valor)) errores.push('una minúscula');
    if (!/\d/.test(valor)) errores.push('un número');
    if (!/[^A-Za-z0-9]/.test(valor)) errores.push('un carácter especial');
    return errores.length === 0 ? null : { passwordDebil: { mensaje: `Requiere: ${errores.join(', ')}` } };
  };
}

/** Validator de grupo: compara dos campos de contraseña dentro del mismo FormGroup. */
export function passwordsIgualesValidator(campoPassword: string, campoConfirm: string): ValidatorFn {
  return (group: AbstractControl): ValidationErrors | null => {
    const password = group.get(campoPassword)?.value;
    const confirm = group.get(campoConfirm)?.value;
    if (!password || !confirm) return null;
    return password === confirm ? null : { passwordsNoCoinciden: true };
  };
}

/** Validator de grupo: asegura que dos cédulas sean diferentes (matrimonio). */
export function cedulasDistintasValidator(campo1: string, campo2: string): ValidatorFn {
  return (group: AbstractControl): ValidationErrors | null => {
    const c1 = group.get(campo1)?.value;
    const c2 = group.get(campo2)?.value;
    if (!c1 || !c2) return null;
    return c1 !== c2 ? null : { cedulasIguales: true };
  };
}

/** Compara fecha/hora de inicio y fin dentro del mismo FormGroup (hInicio < hFin). */
export function rangoHorasValidoValidator(campoInicio: string, campoFin: string): ValidatorFn {
  return (group: AbstractControl): ValidationErrors | null => {
    const inicio = group.get(campoInicio)?.value;
    const fin = group.get(campoFin)?.value;
    if (!inicio || !fin) return null;
    return inicio < fin ? null : { rangoHorasInvalido: true };
  };
}

export const TIPOS_ARCHIVO_PERMITIDOS = ['application/pdf', 'image/png', 'image/jpeg'];
export const TAMANO_MAXIMO_ARCHIVO_MB = 5;

/**
 * Los inputs de archivo no se ligan de forma nativa a un FormControl (los navegadores no
 * permiten asignarles un valor programático), así que se validan de forma imperativa al
 * seleccionarlos. Devuelve un mensaje de error o null si el archivo es válido.
 */
export function validarArchivo(
  file: File | null | undefined,
  opciones: { tipos?: string[]; tamanoMaxMb?: number } = {}
): string | null {
  if (!file) return null;
  const tipos = opciones.tipos ?? TIPOS_ARCHIVO_PERMITIDOS;
  const tamanoMaxMb = opciones.tamanoMaxMb ?? TAMANO_MAXIMO_ARCHIVO_MB;
  if (file.size === 0) {
    return 'El archivo está vacío. Selecciona un archivo válido.';
  }
  if (!tipos.includes(file.type)) {
    return 'Formato no permitido. Usa PDF, JPG o PNG.';
  }
  if (file.size > tamanoMaxMb * 1024 * 1024) {
    return `El archivo supera el tamaño máximo de ${tamanoMaxMb}MB.`;
  }
  return null;
}

const MENSAJES_ERROR: Record<string, string> = {
  required: 'Este campo es obligatorio.',
  email: 'Ingresa un correo electrónico válido.',
  minlength: 'El valor es demasiado corto.',
  maxlength: 'El valor es demasiado largo.',
  cedulaInvalida: 'La cédula ingresada no es válida.',
  cedulaDuplicada: 'Ya existe una cuenta registrada con esta cédula.',
  telefonoInvalido: 'Ingresa un teléfono válido (10 dígitos, ej. 0991234567).',
  soloTexto: 'Solo se permiten letras y espacios.',
  nombresInvalidos: 'Ingresa 1 a 3 nombres.',
  apellidosInvalidos: 'Ingresa los apellidos completos (ej. Gómez de la Cruz).',
  montoInvalido: 'Ingresa un monto numérico mayor a 0 (máximo 2 decimales).',
  montoMinimo: 'El monto mínimo permitido es $5.00.',
  fechaPasada: 'La fecha no puede ser anterior a hoy.',
  fechaFutura: 'La fecha no puede ser posterior a hoy.',
  passwordDebil: 'La contraseña debe tener al menos 8 caracteres, mayúscula, minúscula, número y carácter especial.',
  passwordsNoCoinciden: 'Las contraseñas no coinciden.',
  cedulasIguales: 'Las cédulas de ambas personas deben ser diferentes.',
  codigoInvalido: 'Ingresa el código de 6 dígitos que enviamos a tu correo.',
  rangoHorasInvalido: 'La hora de inicio debe ser anterior a la hora de fin.',
};

/** Traduce el primer error de un control a un mensaje legible para mostrar bajo el campo. */
export function mensajeDeError(errors: ValidationErrors | null | undefined): string {
  if (!errors) return '';
  const clave = Object.keys(errors)[0];
  return MENSAJES_ERROR[clave] ?? 'Valor inválido.';
}
