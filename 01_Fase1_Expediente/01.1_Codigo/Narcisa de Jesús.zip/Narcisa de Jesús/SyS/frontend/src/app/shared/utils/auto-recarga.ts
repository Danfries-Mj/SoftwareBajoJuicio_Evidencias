import { effect } from '@angular/core';

const DEFAULT_INTERVALO_MS = 10000;

/**
 * Recarga el callback cada `ms` milisegundos mientras el componente esté vivo.
 * Debe llamarse dentro de un contexto de inyección (inicializador de campo o
 * constructor de un componente/directiva); el efecto se limpia solo al
 * destruirse el componente, así que no hace falta gestionar el timer a mano.
 */
export function autoRecarga(callback: () => void, ms = DEFAULT_INTERVALO_MS) {
  effect((onCleanup) => {
    const timer = setInterval(() => callback(), ms);
    onCleanup(() => clearInterval(timer));
  });
}
