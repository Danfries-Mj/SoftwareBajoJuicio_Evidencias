import { Component, inject, OnInit, signal } from '@angular/core';
import { SlicePipe } from '@angular/common';
import { Router } from '@angular/router';
import { DocumentosService, abrirDocumentoEnNuevaPestana, descargarDocumento } from '../../services/documentos.service';
import { Documento } from '../../models/documento.model';
import { mensajesTemporales } from '../../shared/utils/mensajes-temporales';
@Component({
  selector: 'app-mis-documentos',
  standalone: true,
  imports: [SlicePipe],
  templateUrl: './mis-documentos.html',
  styleUrl: './mis-documentos.css'
})
export class MisDocumentosComponent implements OnInit {
  private docsService = inject(DocumentosService);
  private router = inject(Router);

  documentos = signal<Documento[]>([]);
  docSeleccionado: Documento | null = null;
  mensajeError = mensajesTemporales(signal(''));

  ngOnInit() {
    this.docsService.listar().subscribe({
      next: (documentos) => this.documentos.set(documentos),
      error: () => this.mensajeError.set('No se pudo cargar la lista de documentos.')
    });
  }

  tipoColor(tipo: string | undefined): string {
    if (!tipo) return 'brown';
    if (tipo.includes('Comunión') || tipo.includes('Comunion')) return 'blue';
    if (tipo.includes('Confirmación') || tipo.includes('Confirmacion')) return 'purple';
    if (tipo.includes('Certificado')) return 'gold';
    return 'brown';
  }

  verDocumento(doc: Documento) {
    this.docSeleccionado = doc;
  }

  verArchivo(doc: Documento) {
    abrirDocumentoEnNuevaPestana(doc);
  }

  descargar(doc: Documento) {
    descargarDocumento(doc, doc.archivo_nombre ?? 'documento');
  }

  closeOnOverlay(e: MouseEvent) {
    if (e.target === e.currentTarget) this.docSeleccionado = null;
  }

  goBack() {
    this.router.navigate(['/']);
  }
}
