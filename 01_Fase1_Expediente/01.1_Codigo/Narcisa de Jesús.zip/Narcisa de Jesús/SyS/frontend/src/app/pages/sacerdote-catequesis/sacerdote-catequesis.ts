import { Component, inject, OnInit, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { firstValueFrom, timeout } from 'rxjs';
import { CapillasService } from '../../services/capillas.service';
import { InscritosCatequesisService } from '../../services/inscritos-catequesis.service';
import { InscripcionesCatequesisService } from '../../services/inscripciones-catequesis.service';
import { UsuariosService } from '../../services/usuarios.service';
import { PersonasService } from '../../services/personas.service';
import { CertificadosService } from '../../services/certificados.service';
import { DocumentosService, abrirDocumentoEnNuevaPestana, descargarDocumento } from '../../services/documentos.service';
import { Capilla } from '../../models/capilla.model';
import { InscritoCatequesis } from '../../models/inscrito-catequesis.model';
import { Usuario } from '../../models/usuario.model';
import { Certificado } from '../../models/certificado.model';
import { mensajesTemporales } from '../../shared/utils/mensajes-temporales';
import { autoRecarga } from '../../shared/utils/auto-recarga';
import { soloDigitos, validarArchivo } from '../../shared/utils/validaciones';

interface FinalizadoConCertificado {
  inscrito: InscritoCatequesis;
  certificado: Certificado;
}

type SeccionCatequesis = 'inscripciones' | 'sinCertificado' | 'porValidar' | 'emitidos';

function nuevoArchivo() {
  return { nombre: signal(''), dataUrl: signal(''), mime: signal(''), error: signal('') };
}

/** Evita que una petición colgada deje el botón "Guardando..." bloqueado indefinidamente. */
const TIMEOUT_GUARDADO_MS = 20000;

@Component({
  selector: 'app-sacerdote-catequesis',
  standalone: true,
  imports: [FormsModule],
  templateUrl: './sacerdote-catequesis.html',
  styleUrl: './sacerdote-catequesis.css'
})
export class SacerdoteCatequesisComponent implements OnInit {
  private capillasService = inject(CapillasService);
  private inscritosService = inject(InscritosCatequesisService);
  private inscripcionesService = inject(InscripcionesCatequesisService);
  private usuariosService = inject(UsuariosService);
  private personasService = inject(PersonasService);
  private certificadosService = inject(CertificadosService);
  private documentosService = inject(DocumentosService);
  protected soloDigitos = soloDigitos;

  seccionActiva = signal<SeccionCatequesis>('inscripciones');

  showModal = false;
  editando: InscritoCatequesis | null = null;
  guardando = signal(false);
  mensajeError = mensajesTemporales(signal(''));
  mensajeExito = mensajesTemporales(signal(''));
  generandoCertificados = signal(false);
  clasificandoCertificados = signal(false);
  finalizadosSinCertificado = signal<InscritoCatequesis[]>([]);
  finalizadosConCertificado = signal<FinalizadoConCertificado[]>([]);

  certificadosPendientes = signal<Certificado[]>([]);
  procesandoCertificado = signal<number | null>(null);

  busqueda = '';
  filtroCapilla: number | '' = '';

  busquedaEmitidos = '';
  filtroCapillaEmitidos: number | '' = '';

  inscripciones = signal<InscritoCatequesis[]>([]);
  capillas = signal<Capilla[]>([]);
  catequistas = signal<Usuario[]>([]);

  niveles = ['Primera Comunion', 'Confirmacion'];
  estados = ['Pendiente', 'Activo', 'Finalizado'];

  /**
   * Certificado prerrequisito inmediato de cada nivel (el que hay que verificar/subir aquí).
   * No hace falta revisar toda la cadena: para tener el de Primera Comunión emitido, ya se
   * exigió el de Bautismo al emitirlo, así que basta con el inmediato anterior.
   */
  private readonly prerrequisitoInmediato: Record<string, string> = {
    'Primera Comunion': 'Bautismo',
    'Confirmacion': 'Primera Comunion'
  };

  nueva: Partial<InscritoCatequesis> = {};
  nuevaApellidos = '';
  edicion: { id_catequista: number | ''; estado: string; nota: string } = { id_catequista: '', estado: 'Pendiente', nota: '' };

  buscandoCedula = signal(false);
  busquedaCedulaMsg = signal('');
  personaEnSistema = signal(false);
  // Si el certificado prerrequisito ya está emitido (tenga o no cuenta la persona), no
  // hace falta subir nada; si no, el Sacerdote puede adjuntarlo aquí mismo (queda validado
  // de inmediato, porque es él mismo quien lo está subiendo).
  certificadoValidado = signal(false);
  private personaIdPersona: number | null = null;
  comprobanteArchivo = nuevoArchivo();
  certificadoNuevoArchivo = nuevoArchivo();

  constructor() {
    autoRecarga(() => this.refrescar());
  }

  ngOnInit() {
    this.capillasService.listar().subscribe({ next: (c) => this.capillas.set(c) });
    this.usuariosService.listar({ rol: 'Catequista' }).subscribe({ next: (u) => this.catequistas.set(u) });
    this.cargarInscripciones();
    this.cargarCertificadosPendientes();
  }

  private cargarCertificadosPendientes() {
    this.certificadosService.listar({ estado: 'Pendiente' }).subscribe({
      next: (c) => this.certificadosPendientes.set(c)
    });
  }

  solicitanteNombre(c: Certificado): string {
    return `${c.solicitante_nombres ?? ''} ${c.solicitante_apellidos ?? ''}`.trim() || '—';
  }

  verArchivoCertificado(c: Certificado) {
    abrirDocumentoEnNuevaPestana(c);
  }

  aprobarCertificadoPendiente(c: Certificado) {
    if (this.procesandoCertificado() !== null) return;
    this.procesandoCertificado.set(c.id_certificado);
    this.mensajeError.set('');
    this.certificadosService.emitir(c.id_certificado, { fecha_emision: new Date().toISOString().slice(0, 10) }).subscribe({
      next: () => {
        this.procesandoCertificado.set(null);
        this.mensajeExito.set('Certificado aprobado correctamente.');
        this.cargarCertificadosPendientes();
      },
      error: (error) => {
        this.procesandoCertificado.set(null);
        this.mensajeError.set(error?.error?.mensaje ?? 'No se pudo aprobar el certificado.');
      }
    });
  }

  rechazarCertificadoPendiente(c: Certificado) {
    if (this.procesandoCertificado() !== null) return;
    if (!confirm(`¿Rechazar el certificado de ${c.tipo} subido por ${this.solicitanteNombre(c)}?`)) return;

    this.procesandoCertificado.set(c.id_certificado);
    this.mensajeError.set('');
    this.certificadosService.rechazar(c.id_certificado).subscribe({
      next: () => {
        this.procesandoCertificado.set(null);
        this.mensajeExito.set('Certificado rechazado.');
        this.cargarCertificadosPendientes();
      },
      error: (error) => {
        this.procesandoCertificado.set(null);
        this.mensajeError.set(error?.error?.mensaje ?? 'No se pudo rechazar el certificado.');
      }
    });
  }

  private cargarInscripciones(mostrarError = true) {
    this.inscritosService.listar().subscribe({
      next: (data) => {
        this.inscripciones.set(data);
        this.clasificarFinalizados();
      },
      error: () => { if (mostrarError) this.mensajeError.set('No se pudieron cargar las inscripciones de catequesis.'); }
    });
  }

  /** Separa los inscritos "Finalizado" en dos tablas: con certificado emitido y sin él. */
  private async clasificarFinalizados() {
    const finalizados = this.inscripciones().filter(i => i.estado === 'Finalizado');
    if (finalizados.length === 0) {
      this.finalizadosSinCertificado.set([]);
      this.finalizadosConCertificado.set([]);
      return;
    }

    this.clasificandoCertificados.set(true);
    const sinCertificado: InscritoCatequesis[] = [];
    const conCertificado: FinalizadoConCertificado[] = [];

    for (const inscrito of finalizados) {
      // Se busca por persona (no por cuenta de usuario): un tercero inscrito en catequesis
      // puede no tener cuenta propia, pero como persona siempre existe (ver
      // obtenerOCrearPersonaTercero en inscripciones.ts) y es a ella a quien se le emite el
      // certificado.
      const persona = await firstValueFrom(this.personasService.buscarPorCedula(inscrito.cedula)).catch(() => null);
      if (!persona) {
        sinCertificado.push(inscrito);
        continue;
      }

      const certificados = await firstValueFrom(
        this.certificadosService.listar({ id_persona: persona.id_persona, tipo: inscrito.nivel, estado: 'Emitido' })
      ).catch(() => []);

      if (certificados.length > 0) {
        conCertificado.push({ inscrito, certificado: certificados[0] });
      } else {
        sinCertificado.push(inscrito);
      }
    }

    this.finalizadosSinCertificado.set(sinCertificado);
    this.finalizadosConCertificado.set(conCertificado);
    this.clasificandoCertificados.set(false);
  }

  private refrescar() {
    this.cargarInscripciones(false);
    this.cargarCertificadosPendientes();
  }

  verCertificado(c: Certificado) {
    abrirDocumentoEnNuevaPestana(c);
  }

  descargarCertificado(c: Certificado, nombreInscrito: string) {
    descargarDocumento(c, c.archivo_nombre || `certificado-${nombreInscrito}.pdf`);
  }

  get inscripcionesFiltradas(): InscritoCatequesis[] {
    return this.inscripciones().filter(i => {
      const texto = this.busqueda.toLowerCase();
      const coincideTexto = !texto || `${i.nombres} ${i.cedula}`.toLowerCase().includes(texto);
      const coincideCapilla = !this.filtroCapilla || i.id_capilla === this.filtroCapilla;
      return coincideTexto && coincideCapilla;
    });
  }

  get emitidosFiltrados(): FinalizadoConCertificado[] {
    const texto = this.busquedaEmitidos.toLowerCase();
    return this.finalizadosConCertificado().filter(f => {
      const coincideTexto = !texto || `${f.inscrito.nombres} ${f.inscrito.cedula}`.toLowerCase().includes(texto);
      const coincideCapilla = !this.filtroCapillaEmitidos || f.inscrito.id_capilla === this.filtroCapillaEmitidos;
      return coincideTexto && coincideCapilla;
    });
  }

  capillaNombre(i: InscritoCatequesis): string {
    return i.capilla_nombre ?? this.capillas().find(c => c.id_capilla === i.id_capilla)?.nombre ?? '—';
  }

  catequistaNombre(i: InscritoCatequesis): string {
    if (!i.id_catequista) return 'Sin asignar';
    const cat = this.catequistas().find(c => c.id_usuario === i.id_catequista);
    return cat ? `${cat.nombres} ${cat.apellidos}` : 'Sin asignar';
  }

  openModal() {
    this.editando = null;
    this.nueva = { nivel: 'Primera Comunion', estado: 'Pendiente', fecha_inscripcion: new Date().toISOString().slice(0, 10) };
    this.nuevaApellidos = '';
    this.mensajeError.set('');
    this.busquedaCedulaMsg.set('');
    this.personaEnSistema.set(false);
    this.certificadoValidado.set(false);
    this.personaIdPersona = null;
    this.comprobanteArchivo = nuevoArchivo();
    this.certificadoNuevoArchivo = nuevoArchivo();
    this.showModal = true;
  }

  onCedulaChange(valor: string) {
    this.nueva.cedula = soloDigitos(valor, 10);
    this.personaEnSistema.set(false);
    this.certificadoValidado.set(false);
    this.personaIdPersona = null;
    this.busquedaCedulaMsg.set('');
  }

  /** Cambiar el nivel invalida la búsqueda anterior: el certificado prerrequisito es distinto. */
  onNivelChange(valor: string) {
    this.nueva.nivel = valor as InscritoCatequesis['nivel'];
    this.personaEnSistema.set(false);
    this.certificadoValidado.set(false);
    this.personaIdPersona = null;
    this.busquedaCedulaMsg.set('');
  }

  onFileSelect(event: Event, target: 'comprobanteArchivo' | 'certificadoNuevoArchivo' = 'comprobanteArchivo') {
    const input = event.target as HTMLInputElement;
    const file = input.files?.[0];
    if (!file) return;

    const archivo = this[target];
    const error = validarArchivo(file, { tipos: ['application/pdf', 'image/png', 'image/jpeg'] });
    if (error) {
      archivo.error.set(error);
      archivo.nombre.set('');
      archivo.dataUrl.set('');
      input.value = '';
      return;
    }

    archivo.error.set('');
    const reader = new FileReader();
    reader.onload = () => {
      archivo.nombre.set(file.name);
      archivo.dataUrl.set(reader.result as string);
      archivo.mime.set(file.type);
    };
    reader.readAsDataURL(file);
  }

  /**
   * Busca la persona por cédula (tenga o no cuenta de usuario) para autocompletar sus
   * datos y verificar de una vez su certificado prerrequisito del nivel seleccionado.
   * Si no está registrada, los campos quedan editables para completarlos a mano.
   */
  async buscarPorCedula() {
    const cedula = (this.nueva.cedula ?? '').trim();
    if (!cedula || !/^\d{10}$/.test(cedula)) {
      this.busquedaCedulaMsg.set('Ingresa una cédula válida (10 dígitos) para buscar.');
      return;
    }
    if (!this.nueva.nivel) {
      this.busquedaCedulaMsg.set('Selecciona el nivel antes de buscar.');
      return;
    }

    this.buscandoCedula.set(true);
    this.busquedaCedulaMsg.set('');
    this.personaEnSistema.set(false);
    this.certificadoValidado.set(false);
    this.personaIdPersona = null;

    const tipoPrerrequisito = this.prerrequisitoInmediato[this.nueva.nivel];

    try {
      const persona = await firstValueFrom(this.personasService.buscarPorCedula(cedula));
      this.personaEnSistema.set(true);
      this.personaIdPersona = persona.id_persona;
      this.nueva.nombres = persona.nombres;
      this.nuevaApellidos = persona.apellidos;

      // Si además tiene cuenta de usuario, se aprovecha para autocompletar su capilla.
      try {
        const usuario = await firstValueFrom(this.usuariosService.buscarPorCedula(cedula));
        if (usuario.id_capilla) this.nueva.id_capilla = Number(usuario.id_capilla);
      } catch { /* no tiene cuenta propia: la capilla se elige manualmente */ }

      const tieneCertificado = await firstValueFrom(
        this.certificadosService.tienePrerrequisitoEmitido(persona.id_persona, tipoPrerrequisito)
      );
      this.certificadoValidado.set(tieneCertificado);
      this.buscandoCedula.set(false);
      this.busquedaCedulaMsg.set(
        tieneCertificado
          ? `Persona encontrada: tiene el certificado de ${tipoPrerrequisito} emitido.`
          : `Persona encontrada: sube su certificado de ${tipoPrerrequisito} para poder inscribirla.`
      );
    } catch {
      this.buscandoCedula.set(false);
      this.personaEnSistema.set(false);
      this.nueva.nombres = '';
      this.nuevaApellidos = '';
      this.busquedaCedulaMsg.set(`No se encontró una persona registrada con esa cédula. Completa los datos manualmente y adjunta su certificado de ${tipoPrerrequisito}.`);
    }
  }

  /** Un Finalizado con certificado ya emitido es un registro cerrado: ya no se edita ni se elimina. */
  estaBloqueadoPorCertificado(i: InscritoCatequesis): boolean {
    return this.finalizadosConCertificado().some(f => f.inscrito.id_inscrito === i.id_inscrito);
  }

  editar(i: InscritoCatequesis) {
    if (this.estaBloqueadoPorCertificado(i)) return;
    this.editando = i;
    this.edicion = { id_catequista: i.id_catequista ?? '', estado: i.estado, nota: '' };
    this.mensajeError.set('');
    this.showModal = true;
  }

  eliminar(i: InscritoCatequesis) {
    if (this.estaBloqueadoPorCertificado(i)) return;
    if (!confirm('¿Eliminar esta inscripción de catequesis?')) return;
    this.inscritosService.eliminar(i.id_inscrito).subscribe({
      next: () => this.cargarInscripciones(),
      error: (error) => this.mensajeError.set(error?.error?.mensaje ?? 'No se pudo eliminar la inscripción.')
    });
  }

  async guardar() {
    // Evita doble envío: si ya hay un guardado en curso (p. ej. por doble clic), se ignora.
    if (this.guardando()) return;
    this.mensajeError.set('');

    if (this.editando) {
      if (!this.edicion.estado) {
        this.mensajeError.set('El estado es obligatorio.');
        return;
      }
      this.guardando.set(true);
      this.inscritosService.editar(this.editando.id_inscrito, {
        id_catequista: this.edicion.id_catequista ? Number(this.edicion.id_catequista) : undefined,
        estado: this.edicion.estado,
        nota: this.edicion.nota || undefined
      }).pipe(timeout(TIMEOUT_GUARDADO_MS)).subscribe({
        next: () => {
          this.guardando.set(false);
          this.showModal = false;
          this.editando = null;
          this.cargarInscripciones();
        },
        error: (error) => {
          this.guardando.set(false);
          this.mensajeError.set(error?.error?.mensaje ?? 'No se pudo actualizar la inscripción.');
        }
      });
      return;
    }

    if (!this.nueva.nombres || !this.nuevaApellidos || !this.nueva.cedula || !this.nueva.nivel || !this.nueva.id_capilla || !this.nueva.fecha_inscripcion) {
      this.mensajeError.set('Nombres, apellidos, cédula, nivel, capilla y fecha de inscripción son obligatorios.');
      return;
    }
    if (!/^\d{10}$/.test(this.nueva.cedula)) {
      this.mensajeError.set('La cédula debe tener exactamente 10 dígitos.');
      return;
    }
    if (!this.certificadoValidado() && !this.certificadoNuevoArchivo.dataUrl()) {
      this.mensajeError.set('Adjunta el certificado prerrequisito, o busca la cédula y verifica que la persona ya lo tenga emitido.');
      return;
    }
    if (!this.comprobanteArchivo.dataUrl()) {
      this.mensajeError.set('La foto o PDF del comprobante de pago es obligatorio.');
      return;
    }

    const idCapilla = Number(this.nueva.id_capilla);
    const nombreCompleto = `${this.nueva.nombres.trim()} ${this.nuevaApellidos.trim()}`;

    this.guardando.set(true);
    try {
      // Verifica contra el servidor (no solo en memoria) que esta persona no tenga ya un
      // inscrito activo/pendiente en este nivel, para evitar registros duplicados sin
      // depender únicamente del bloqueo de doble clic en el propio formulario.
      const existentes = await firstValueFrom(
        this.inscritosService.listar({ nivel: this.nueva.nivel }).pipe(timeout(TIMEOUT_GUARDADO_MS))
      );
      const yaInscrito = existentes.some(i => i.cedula === this.nueva.cedula && (i.estado === 'Pendiente' || i.estado === 'Activo'));
      if (yaInscrito) {
        this.guardando.set(false);
        this.mensajeError.set('Esta persona ya tiene una inscripción activa o pendiente en este nivel. Revisa la tabla antes de registrar otra.');
        return;
      }

      // Resuelve (o crea) la persona, igual que en la inscripción de terceros del Laico:
      // así queda un registro real aunque la persona no tenga cuenta.
      let idPersona = this.personaIdPersona;
      if (!idPersona) {
        try {
          const personaExistente = await firstValueFrom(this.personasService.buscarPorCedula(this.nueva.cedula));
          idPersona = personaExistente.id_persona;
        } catch {
          const personaCreada = await firstValueFrom(this.personasService.crear({
            cedula: this.nueva.cedula, nombres: this.nueva.nombres.trim(), apellidos: this.nuevaApellidos.trim()
          }));
          idPersona = personaCreada.id_persona;
        }
      }

      // El certificado que sube el propio Sacerdote queda validado (Emitido) de inmediato:
      // es él mismo quien lo está aprobando en el acto.
      if (!this.certificadoValidado() && this.certificadoNuevoArchivo.dataUrl()) {
        await firstValueFrom(this.certificadosService.crear({
          tipo: this.prerrequisitoInmediato[this.nueva.nivel], id_persona: idPersona,
          archivo_nombre: this.certificadoNuevoArchivo.nombre(),
          archivo_url: this.certificadoNuevoArchivo.dataUrl(), mime_type: this.certificadoNuevoArchivo.mime()
        }).pipe(timeout(TIMEOUT_GUARDADO_MS)));
      }

      const documento = await firstValueFrom(this.documentosService.crear({
        tipo: `Comprobante de catequesis - ${nombreCompleto} (cédula ${this.nueva.cedula.trim()})`,
        archivo_nombre: this.comprobanteArchivo.nombre(),
        archivo_url: this.comprobanteArchivo.dataUrl(),
        mime_type: this.comprobanteArchivo.mime()
      }).pipe(timeout(TIMEOUT_GUARDADO_MS)));

      // El Sacerdote ya validó (o acaba de validar) el certificado y el comprobante: el
      // inscrito se crea directo, sin pasos intermedios, y nace "Activo" de una vez.
      await firstValueFrom(this.inscritosService.crear({
        cedula: this.nueva.cedula,
        nombres: nombreCompleto,
        nivel: this.nueva.nivel,
        id_capilla: idCapilla,
        fecha_inscripcion: this.nueva.fecha_inscripcion,
        monto: this.nueva.monto,
        comprobante: documento.archivo_nombre,
        estado: 'Activo'
      }).pipe(timeout(TIMEOUT_GUARDADO_MS)));

      this.guardando.set(false);
      this.showModal = false;
      this.nueva = {};
      this.mensajeExito.set('Inscripción registrada correctamente.');
      this.cargarInscripciones();
    } catch (error: any) {
      this.guardando.set(false);
      this.mensajeError.set(
        error?.name === 'TimeoutError'
          ? 'El servidor tardó demasiado en responder. Verifica si la inscripción se registró antes de volver a intentarlo.'
          : (error?.error?.mensaje ?? 'No se pudo registrar la inscripción.')
      );
    }
  }

  closeOnOverlay(e: MouseEvent) {
    if (e.target === e.currentTarget) this.showModal = false;
  }

  /**
   * Genera (y emite de una vez, con PDF automático) el certificado de catequesis para
   * cada inscrito de la tabla "Sin certificado". Al terminar, esos inscritos pasan a
   * la tabla "Certificados emitidos".
   */
  async generarCertificados() {
    this.mensajeError.set('');
    this.mensajeExito.set('');

    const pendientes = this.finalizadosSinCertificado();
    if (pendientes.length === 0) {
      this.mensajeError.set('No hay inscritos Finalizado pendientes de certificado.');
      return;
    }

    this.generandoCertificados.set(true);
    let generados = 0, sinPersona = 0, errores = 0;
    const hoy = new Date().toISOString().slice(0, 10);

    for (const i of pendientes) {
      try {
        // Se genera el certificado a nombre de la persona (no de la cuenta de usuario):
        // un tercero inscrito puede no tener cuenta propia, pero sí tiene un id_persona
        // real al que asociar el certificado.
        const persona = await firstValueFrom(this.personasService.buscarPorCedula(i.cedula)).catch(() => null);
        if (!persona) { sinPersona++; continue; }

        const certificado = await firstValueFrom(this.certificadosService.crear({
          tipo: i.nivel, id_capilla: i.id_capilla, id_persona: persona.id_persona
        }));
        await firstValueFrom(this.certificadosService.emitir(certificado.id_certificado, { fecha_emision: hoy }));
        generados++;
      } catch {
        errores++;
      }
    }

    this.generandoCertificados.set(false);
    await this.clasificarFinalizados();

    const partes: string[] = [];
    if (generados) partes.push(`${generados} certificado(s) generado(s)`);
    if (sinPersona) partes.push(`${sinPersona} sin persona registrada`);
    if (errores) partes.push(`${errores} con error (revisa prerrequisitos del sacramento anterior)`);

    if (generados > 0) this.mensajeExito.set(partes.join(' · '));
    else this.mensajeError.set(partes.join(' · ') || 'No se generó ningún certificado.');
  }
}
