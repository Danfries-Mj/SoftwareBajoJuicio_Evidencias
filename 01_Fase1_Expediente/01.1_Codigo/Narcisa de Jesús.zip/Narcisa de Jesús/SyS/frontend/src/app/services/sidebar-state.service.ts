import { Injectable, signal } from '@angular/core';

@Injectable({ providedIn: 'root' })
export class SidebarStateService {
  expanded = signal(true);
  toggle() { this.expanded.update(v => !v); }
}
