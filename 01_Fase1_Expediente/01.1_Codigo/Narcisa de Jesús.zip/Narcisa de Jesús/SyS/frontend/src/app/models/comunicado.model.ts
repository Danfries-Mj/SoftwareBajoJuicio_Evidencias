export type EstadoComunicado = 'Borrador' | 'Enviado';

export interface Comunicado {
  id_comunicado: number;
  titulo: string;
  mensaje: string;
  id_capilla?: number | null;
  capilla_nombre?: string;
  estado: EstadoComunicado;
  creado_por?: number;
  fecha_creacion?: string;
  fecha_publicacion?: string;
}
