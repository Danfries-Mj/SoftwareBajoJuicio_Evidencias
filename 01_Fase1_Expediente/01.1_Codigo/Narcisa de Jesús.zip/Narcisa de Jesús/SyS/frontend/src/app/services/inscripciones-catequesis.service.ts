import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable, map } from 'rxjs';
import { API_URL } from '../core/config/api.config';
import { InscripcionCatequesis } from '../models/inscripcion-catequesis.model';

@Injectable({ providedIn: 'root' })
export class InscripcionesCatequesisService {
  private apiUrl = `${API_URL}/inscripciones-catequesis`;

  constructor(private http: HttpClient) {}

  listar(filtros: { id_capilla?: number; nivel?: string; estado?: string } = {}): Observable<InscripcionCatequesis[]> {
    let params = new HttpParams();
    if (filtros.id_capilla) params = params.set('id_capilla', filtros.id_capilla);
    if (filtros.nivel) params = params.set('nivel', filtros.nivel);
    if (filtros.estado) params = params.set('estado', filtros.estado);

    return this.http.get<{ mensaje: string; total: number; inscripciones: InscripcionCatequesis[] }>(this.apiUrl, { params })
      .pipe(map(respuesta => respuesta.inscripciones));
  }

  obtenerPorId(id: number): Observable<InscripcionCatequesis> {
    return this.http.get<{ mensaje: string; inscripcion: InscripcionCatequesis }>(`${this.apiUrl}/${id}`)
      .pipe(map(respuesta => respuesta.inscripcion));
  }

  crear(datos: { nivel: string; id_capilla: number; monto?: number; id_documento?: number | null; id_laico?: number }): Observable<InscripcionCatequesis> {
    return this.http.post<{ mensaje: string; inscripcion: InscripcionCatequesis }>(this.apiUrl, datos)
      .pipe(map(respuesta => respuesta.inscripcion));
  }

  aprobar(id: number): Observable<InscripcionCatequesis> {
    return this.http.put<{ mensaje: string; inscripcion: InscripcionCatequesis }>(`${this.apiUrl}/${id}/aprobar`, {})
      .pipe(map(respuesta => respuesta.inscripcion));
  }

  rechazar(id: number): Observable<InscripcionCatequesis> {
    return this.http.put<{ mensaje: string; inscripcion: InscripcionCatequesis }>(`${this.apiUrl}/${id}/rechazar`, {})
      .pipe(map(respuesta => respuesta.inscripcion));
  }

  eliminar(id: number): Observable<{ mensaje: string; inscripcion: InscripcionCatequesis }> {
    return this.http.delete<{ mensaje: string; inscripcion: InscripcionCatequesis }>(`${this.apiUrl}/${id}`);
  }
}
