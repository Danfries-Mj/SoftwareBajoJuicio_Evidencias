import { Component, Input } from '@angular/core';

@Component({
  selector: 'app-form-alert',
  standalone: true,
  templateUrl: './form-alert.html',
  styleUrl: './form-alert.css'
})
export class FormAlertComponent {
  @Input() tipo: 'error' | 'exito' = 'error';
  @Input() mensaje = '';
}
