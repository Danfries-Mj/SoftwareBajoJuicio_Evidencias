export interface HistorialInscrito {
  id_historial: number;
  id_inscrito: number;
  comprobante?: string;
  estado_anterior?: string;
  estado_nuevo: string;
  nota?: string;
  fecha_cambio?: string;
}
