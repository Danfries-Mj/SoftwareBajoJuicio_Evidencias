import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable, map } from 'rxjs';
import { API_URL } from '../core/config/api.config';

export interface Notificacion {
  id_notificacion: number;
  id_usuario: number;
  titulo: string;
  mensaje: string;
  leida: boolean;
  fecha_creacion: string;
}

@Injectable({ providedIn: 'root' })
export class NotificacionesService {
  private apiUrl = `${API_URL}/notificaciones`;

  constructor(private http: HttpClient) {}

  listar(soloPendientes = false): Observable<{ notificaciones: Notificacion[]; pendientes: number }> {
    let params = new HttpParams();
    if (soloPendientes) params = params.set('solo_pendientes', 'true');

    return this.http.get<{ mensaje: string; notificaciones: Notificacion[]; pendientes: number }>(this.apiUrl, { params })
      .pipe(map(respuesta => ({ notificaciones: respuesta.notificaciones, pendientes: respuesta.pendientes })));
  }

  marcarLeida(id: number): Observable<any> {
    return this.http.put(`${this.apiUrl}/${id}/leer`, {});
  }

  marcarTodasLeidas(): Observable<any> {
    return this.http.put(`${this.apiUrl}/leer-todas`, {});
  }

  enviarAMiembros(datos: { id_usuario?: number | null; titulo: string; mensaje: string }): Observable<{ mensaje: string; enviadas: number }> {
    return this.http.post<{ mensaje: string; enviadas: number }>(`${this.apiUrl}/enviar-miembros`, datos);
  }
}
