import { NivelCatequesis } from './inscripcion-catequesis.model';

export type EstadoInscrito = 'Pendiente' | 'Activo' | 'Finalizado';

export interface InscritoCatequesis {
  id_inscrito: number;
  id_inscripcion?: number | null;
  cedula: string;
  nombres: string;
  nivel: NivelCatequesis;
  id_capilla: number;
  capilla_nombre?: string;
  id_catequista?: number | null;
  fecha_inscripcion: string;
  monto?: number;
  comprobante?: string;
  estado: EstadoInscrito;
}
