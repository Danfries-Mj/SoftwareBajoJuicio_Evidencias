export type NivelCatequesis = 'Primera Comunion' | 'Confirmacion';
export type EstadoInscripcion = 'Pendiente' | 'Aprobada' | 'Rechazada';

export interface InscripcionCatequesis {
  id_inscripcion: number;
  id_laico: number;
  nivel: NivelCatequesis;
  id_capilla: number;
  capilla_nombre?: string;
  monto?: number;
  pago_confirmado?: boolean;
  fecha_solicitud?: string;
  estado: EstadoInscripcion;
  id_revisor?: number | null;
  id_documento?: number | null;
}
