import { Component, inject, HostListener, OnInit, OnDestroy, signal } from '@angular/core';
import { Router, RouterLink, RouterLinkActive } from '@angular/router';
import { ModalService } from '../../services/modal.service';
import { AuthService } from '../../services/auth.service';
import { NotificacionesService } from '../../services/notificaciones.service';

const INTERVALO_REFRESCO_NOTIFICACIONES_MS = 20000;

@Component({
  selector: 'app-navbar',
  standalone: true,
  imports: [RouterLink, RouterLinkActive],
  templateUrl: './navbar.html',
  styleUrl: './navbar.css'
})
export class NavbarComponent implements OnInit, OnDestroy {
  protected modalService = inject(ModalService);
  protected authService = inject(AuthService);
  private notificacionesService = inject(NotificacionesService);
  private router = inject(Router);
  showDropdown = false;
  showNotificaciones = false;

  notificaciones = signal<any[]>([]);
  notificacionesPendientes = signal(0);
  private intervaloNotificaciones?: ReturnType<typeof setInterval>;

  ngOnInit() {
    if (this.authService.isLoggedIn()) {
      this.cargarNotificaciones();
      this.intervaloNotificaciones = setInterval(
        () => this.cargarNotificaciones(),
        INTERVALO_REFRESCO_NOTIFICACIONES_MS
      );
    }
  }

  ngOnDestroy() {
    if (this.intervaloNotificaciones) clearInterval(this.intervaloNotificaciones);
  }

  private cargarNotificaciones() {
    const soloPendientes = !this.showNotificaciones;
    this.notificacionesService.listar(soloPendientes).subscribe({
      next: (resultado) => {
        this.notificaciones.set(resultado.notificaciones);
        if (this.showNotificaciones) {
          this.notificacionesPendientes.set(0);
        } else {
          this.notificacionesPendientes.set(resultado.pendientes);
        }
      },
      error: () => {
        this.notificaciones.set([]);
        this.notificacionesPendientes.set(0);
      }
    });
  }

  toggleDropdown() {
    this.showDropdown = !this.showDropdown;
    this.showNotificaciones = false;
  }

  toggleNotificaciones() {
    this.showNotificaciones = !this.showNotificaciones;
    this.showDropdown = false;
    if (this.showNotificaciones) {
      this.notificacionesService.marcarTodasLeidas().subscribe({
        complete: () => {
          this.notificacionesPendientes.set(0);
          this.cargarNotificaciones();
        }
      });
    }
  }

  logout() {
    this.authService.logout();
    this.showDropdown = false;
    this.router.navigate(['/']);
  }

  @HostListener('document:click', ['$event'])
  onDocumentClick(event: MouseEvent) {
    const target = event.target as HTMLElement;
    if (!target.closest('.dropdown')) {
      this.showDropdown = false;
      this.showNotificaciones = false;
    }
  }
}
