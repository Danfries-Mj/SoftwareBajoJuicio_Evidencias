import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, map } from 'rxjs';
import { API_URL } from '../core/config/api.config';
import { BeneficiarioSolicitud } from '../models/beneficiario-solicitud.model';

@Injectable({ providedIn: 'root' })
export class BeneficiariosSolicitudService {
  private apiUrl = `${API_URL}/beneficiarios-solicitud`;

  constructor(private http: HttpClient) {}

  listarPorSolicitud(idSolicitud: number): Observable<BeneficiarioSolicitud[]> {
    return this.http.get<{ mensaje: string; total: number; beneficiarios: BeneficiarioSolicitud[] }>(`${this.apiUrl}/solicitud/${idSolicitud}`)
      .pipe(map(respuesta => respuesta.beneficiarios));
  }

  crear(datos: { id_solicitud: number; rol_beneficiario: string; nombres?: string; apellidos?: string; cedula?: string; telefono?: string; id_persona?: number | null }): Observable<BeneficiarioSolicitud> {
    return this.http.post<{ mensaje: string; beneficiario: BeneficiarioSolicitud }>(this.apiUrl, datos)
      .pipe(map(respuesta => respuesta.beneficiario));
  }

  eliminar(id: number): Observable<{ mensaje: string; beneficiario: BeneficiarioSolicitud }> {
    return this.http.delete<{ mensaje: string; beneficiario: BeneficiarioSolicitud }>(`${this.apiUrl}/${id}`);
  }
}
