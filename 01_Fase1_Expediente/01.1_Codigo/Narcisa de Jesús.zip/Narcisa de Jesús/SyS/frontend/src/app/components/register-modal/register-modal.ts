import { Component, OnInit, inject, signal, effect, WritableSignal } from '@angular/core';
import { AbstractControl, AsyncValidatorFn, FormBuilder, ReactiveFormsModule, Validators } from '@angular/forms';
import { of, timer } from 'rxjs';
import { switchMap, map, catchError } from 'rxjs/operators';
import { ModalService } from '../../services/modal.service';
import { AuthService } from '../../services/auth.service';
import { CapillasService } from '../../services/capillas.service';
import { Capilla } from '../../models/capilla.model';
import { FormAlertComponent } from '../form-alert/form-alert';
import { SuccessModalComponent } from '../success-modal/success-modal';
import { mensajesTemporales } from '../../shared/utils/mensajes-temporales';
import {
  cedulaEcuatorianaValidator,
  telefonoEcuadorValidator,
  soloTextoValidator,
  nombresValidator,
  apellidosValidator,
  passwordSeguraValidator,
  passwordsIgualesValidator,
  mensajeDeError
} from '../../shared/utils/validaciones';

interface PersonaPrevia {
  nombres: string;
  apellidos: string;
  telefono: string | null;
}

/**
 * Consulta al backend (con un pequeño debounce) si ya existe una cuenta con esa cédula.
 * Si la cédula está disponible pero ya tiene datos de una persona sin cuenta (inscripción
 * de tercero, bautizando de una solicitud, etc.), los deja en `personaEncontrada` para que
 * el formulario los autocomplete.
 */
function cedulaDuplicadaValidator(authService: AuthService, personaEncontrada: WritableSignal<PersonaPrevia | null>): AsyncValidatorFn {
  return (control: AbstractControl) => {
    const valor = (control.value ?? '').toString().trim();
    if (!/^\d{10}$/.test(valor)) {
      personaEncontrada.set(null);
      return of(null);
    }
    return timer(400).pipe(
      switchMap(() => authService.cedulaDisponible(valor)),
      map(({ disponible, personaExistente }) => {
        personaEncontrada.set(disponible ? personaExistente : null);
        return disponible ? null : { cedulaDuplicada: true };
      }),
      catchError(() => {
        personaEncontrada.set(null);
        return of(null);
      })
    );
  };
}

@Component({
  selector: 'app-register-modal',
  standalone: true,
  imports: [ReactiveFormsModule, FormAlertComponent, SuccessModalComponent],
  templateUrl: './register-modal.html',
  styleUrl: './register-modal.css'
})
export class RegisterModalComponent implements OnInit {
  protected modalService = inject(ModalService);
  private authService = inject(AuthService);
  private capillasService = inject(CapillasService);
  private fb = inject(FormBuilder);

  showPassword = false;
  showConfirmPassword = false;

  capillas = signal<Capilla[]>([]);
  cargando = signal(false);
  mensajeError = mensajesTemporales(signal(''));
  mensajeDeError = mensajeDeError;
  mostrarExito = signal(false);

  /** Persona ya registrada (sin cuenta) encontrada por la cédula, para autocompletar. */
  personaEncontrada = signal<PersonaPrevia | null>(null);

  form = this.fb.group(
    {
      nombres: ['', [Validators.required, soloTextoValidator(), nombresValidator()]],
      apellidos: ['', [Validators.required, soloTextoValidator(), apellidosValidator()]],
      cedula: ['', [Validators.required, cedulaEcuatorianaValidator()], [cedulaDuplicadaValidator(this.authService, this.personaEncontrada)]],
      email: ['', [Validators.required, Validators.email]],
      telefono: ['', [Validators.required, telefonoEcuadorValidator()]],
      password: ['', [Validators.required, passwordSeguraValidator()]],
      confirmPassword: ['', [Validators.required]],
      idCapilla: [null as number | null, [Validators.required]]
    },
    { validators: passwordsIgualesValidator('password', 'confirmPassword') }
  );

  constructor() {
    // Autocompleta nombres/apellidos/teléfono cuando se encuentra una persona previa por
    // cédula, sin pisar lo que la persona ya haya escrito a mano; queda editable por si
    // el dato guardado (p. ej. de una inscripción hecha por un catequista) está mal.
    effect(() => {
      const persona = this.personaEncontrada();
      if (!persona) return;
      if (!this.form.controls.nombres.value) this.form.controls.nombres.setValue(persona.nombres);
      if (!this.form.controls.apellidos.value) this.form.controls.apellidos.setValue(persona.apellidos);
      if (persona.telefono && !this.form.controls.telefono.value) this.form.controls.telefono.setValue(persona.telefono);
    });
  }

  ngOnInit() {
    this.capillasService.listar().subscribe({
      next: (capillas) => {
        this.capillas.set(capillas);
        if (capillas.length) this.form.controls.idCapilla.setValue(capillas[0].id_capilla);
      }
    });
  }

  registrar() {
    if (this.form.invalid) {
      this.form.markAllAsTouched();
      this.mensajeError.set(
        this.form.errors?.['passwordsNoCoinciden']
          ? 'Las contraseñas no coinciden.'
          : 'Revisa los campos marcados en rojo.'
      );
      return;
    }

    const { nombres, apellidos, cedula, email, telefono, password, idCapilla } = this.form.getRawValue();

    this.cargando.set(true);
    this.mensajeError.set('');
    this.authService.registrarLaico({
      cedula: cedula!,
      nombres: nombres!,
      apellidos: apellidos!,
      telefono: telefono!,
      correo: email!,
      contrasena: password!,
      id_capilla: idCapilla
    }).subscribe({
      next: () => {
        this.cargando.set(false);
        this.mostrarExito.set(true);
      },
      error: (error) => {
        this.cargando.set(false);
        this.mensajeError.set(error?.error?.mensaje ?? 'No se pudo completar el registro.');
      }
    });
  }

  cerrarExito() {
    this.mostrarExito.set(false);
    this.resetForm();
    this.modalService.closeAll();
    this.modalService.openLogin();
  }

  cerrar() {
    this.resetForm();
    this.modalService.closeAll();
  }

  closeOnOverlay(event: MouseEvent) {
    if (event.target === event.currentTarget) {
      this.cerrar();
    }
  }

  private resetForm() {
    this.form.reset();
    this.form.controls.idCapilla.setValue(this.capillas().length ? this.capillas()[0].id_capilla : null);
    this.showPassword = false;
    this.showConfirmPassword = false;
    this.mensajeError.set('');
    this.personaEncontrada.set(null);
  }
}
