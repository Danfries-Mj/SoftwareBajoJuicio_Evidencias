export interface Documento {
  id_documento: number;
  id_usuario: number;
  tipo?: string;
  archivo_nombre?: string;
  archivo_url?: string;
  mime_type?: string;
  fecha_subida?: string;
}
