import { Component, inject, OnInit, signal } from '@angular/core';
import { SlicePipe } from '@angular/common';
import { AuthService } from '../../services/auth.service';
import { EventosService } from '../../services/eventos.service';
import { Evento } from '../../models/evento.model';
import { mensajesTemporales } from '../../shared/utils/mensajes-temporales';
import { autoRecarga } from '../../shared/utils/auto-recarga';

@Component({
  selector: 'app-catequista-eventos',
  standalone: true,
  imports: [SlicePipe],
  templateUrl: './catequista-eventos.html',
  styleUrl: './catequista-eventos.css'
})
export class CatequistaEventosComponent implements OnInit {
  private authService = inject(AuthService);
  private eventosService = inject(EventosService);

  eventos = signal<Evento[]>([]);
  mensajeError = mensajesTemporales(signal(''));

  constructor() {
    autoRecarga(() => this.refrescar());
  }

  ngOnInit() {
    this.cargar();
  }

  private cargar(mostrarError = true) {
    const idCapilla = this.authService.user()?.id_capilla;
    this.eventosService.listar().subscribe({
      next: (data) => {
        const relevantes = data.filter(e => e.tipo_ambito === 'Parroquial' || e.id_capilla === idCapilla);
        this.eventos.set(relevantes);
      },
      error: (error) => { if (mostrarError) this.mensajeError.set(error?.error?.mensaje ?? 'No se pudieron cargar los eventos.'); }
    });
  }

  private refrescar() {
    this.cargar(false);
  }
}
