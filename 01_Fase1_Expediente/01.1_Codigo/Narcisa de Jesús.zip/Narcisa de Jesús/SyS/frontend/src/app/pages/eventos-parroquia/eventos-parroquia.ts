import { Component, inject, OnInit, signal, computed } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { DatePipe } from '@angular/common';
import { EventosService } from '../../services/eventos.service';
import { CapillasService } from '../../services/capillas.service';
import { Evento } from '../../models/evento.model';
import { mensajesTemporales } from '../../shared/utils/mensajes-temporales';

@Component({
  selector: 'app-eventos-parroquia',
  standalone: true,
  imports: [FormsModule, DatePipe],
  templateUrl: './eventos-parroquia.html',
  styleUrl: './eventos-parroquia.css'
})
export class EventosParroquiaComponent implements OnInit {
  private eventosService = inject(EventosService);
  private capillasService = inject(CapillasService);

  filtro = signal('');
  todos = signal<Evento[]>([]);
  mensajeError = mensajesTemporales(signal(''));
  private capillasMap = new Map<number, string>();

  eventos = computed(() => {
    const filtro = this.filtro();
    if (!filtro) return this.todos();
    return this.todos().filter(e => e.tipo_ambito?.toLowerCase() === filtro.toLowerCase());
  });

  ngOnInit() {
    this.capillasService.listar().subscribe({
      next: (capillas) => capillas.forEach(c => this.capillasMap.set(c.id_capilla, c.nombre))
    });

    this.eventosService.listar().subscribe({
      next: (eventos) => this.todos.set(eventos),
      error: () => this.mensajeError.set('No se pudieron cargar los eventos.')
    });
  }

  capillaNombre(evento: Evento): string {
    if (evento.tipo_ambito === 'Parroquial' && !evento.id_capilla) return 'Toda la parroquia';
    if (!evento.id_capilla) return '—';
    return this.capillasMap.get(evento.id_capilla) ?? '—';
  }
}
