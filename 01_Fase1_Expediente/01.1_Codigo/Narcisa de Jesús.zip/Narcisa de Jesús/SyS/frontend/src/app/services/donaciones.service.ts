import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable, map } from 'rxjs';
import { API_URL } from '../core/config/api.config';
import { Donacion } from '../models/donacion.model';

@Injectable({ providedIn: 'root' })
export class DonacionesService {
  private apiUrl = `${API_URL}/donaciones`;

  constructor(private http: HttpClient) {}

  listar(filtros: { estado?: string } = {}): Observable<Donacion[]> {
    let params = new HttpParams();
    if (filtros.estado) params = params.set('estado', filtros.estado);

    return this.http.get<{ mensaje: string; total: number; donaciones: Donacion[] }>(this.apiUrl, { params })
      .pipe(map(respuesta => respuesta.donaciones));
  }

  obtenerPorId(id: number): Observable<Donacion> {
    return this.http.get<{ mensaje: string; donacion: Donacion }>(`${this.apiUrl}/${id}`)
      .pipe(map(respuesta => respuesta.donacion));
  }

  crear(datos: { id_capilla?: number | null; fecha: string; monto: number; id_documento?: number | null; id_fondo?: number | null }): Observable<Donacion> {
    return this.http.post<{ mensaje: string; donacion: Donacion }>(this.apiUrl, datos)
      .pipe(map(respuesta => respuesta.donacion));
  }

  aprobar(id: number): Observable<Donacion> {
    return this.http.put<{ mensaje: string; donacion: Donacion }>(`${this.apiUrl}/${id}/aprobar`, {})
      .pipe(map(respuesta => respuesta.donacion));
  }

  rechazar(id: number): Observable<Donacion> {
    return this.http.put<{ mensaje: string; donacion: Donacion }>(`${this.apiUrl}/${id}/rechazar`, {})
      .pipe(map(respuesta => respuesta.donacion));
  }

  eliminar(id: number): Observable<{ mensaje: string; donacion: Donacion }> {
    return this.http.delete<{ mensaje: string; donacion: Donacion }>(`${this.apiUrl}/${id}`);
  }
}
