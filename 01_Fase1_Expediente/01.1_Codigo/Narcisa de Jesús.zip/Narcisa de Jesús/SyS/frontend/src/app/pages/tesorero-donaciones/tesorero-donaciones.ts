import { Component, OnInit, inject, signal } from '@angular/core';
import { AuthService } from '../../services/auth.service';
import { DonacionesService } from '../../services/donaciones.service';
import { DocumentosService, abrirDocumentoEnNuevaPestana, abrirPestanaEnBlanco } from '../../services/documentos.service';
import { Donacion } from '../../models/donacion.model';
import { mensajesTemporales } from '../../shared/utils/mensajes-temporales';
import { autoRecarga } from '../../shared/utils/auto-recarga';

@Component({
  selector: 'app-tesorero-donaciones',
  standalone: true,
  imports: [],
  templateUrl: './tesorero-donaciones.html',
  styleUrl: './tesorero-donaciones.css'
})
export class TesoreroDonacionesComponent implements OnInit {
  protected Number = Number;

  private authService = inject(AuthService);
  private donacionesService = inject(DonacionesService);
  private documentosService = inject(DocumentosService);

  get tesorero() { return (this.authService.user()?.nombres ?? '') + ' ' + (this.authService.user()?.apellidos ?? ''); }
  get capilla() { return this.authService.user()?.capilla ?? ''; }

  donaciones = signal<Donacion[]>([]);
  mensajeError = mensajesTemporales(signal(''));
  procesando = signal<number | null>(null);

  constructor() {
    autoRecarga(() => this.refrescar());
  }

  ngOnInit() {
    this.cargar();
  }

  private cargar(mostrarError = true) {
    this.donacionesService.listar().subscribe({
      next: (donaciones) => this.donaciones.set(donaciones),
      error: () => { if (mostrarError) this.mensajeError.set('No se pudieron cargar las donaciones.'); }
    });
  }

  formatFecha(fecha: string): string {
    if (!fecha) return '—';
    const [y, m, d] = fecha.slice(0, 10).split('-');
    return `${d}/${m}/${y}`;
  }

  private refrescar() {
    this.cargar(false);
  }

  aprobar(d: Donacion) {
    this.mensajeError.set('');
    this.procesando.set(d.id_donacion);
    this.donacionesService.aprobar(d.id_donacion).subscribe({
      next: () => {
        this.procesando.set(null);
        this.cargar();
      },
      error: (error) => {
        this.procesando.set(null);
        console.error('Error al aprobar donación:', error?.error);
        this.mensajeError.set(error?.error?.error ?? error?.error?.mensaje ?? 'No se pudo aprobar la donación.');
      }
    });
  }

  verComprobante(d: Donacion) {
    if (!d.id_documento) return;
    const ventana = abrirPestanaEnBlanco();
    this.documentosService.obtenerPorId(d.id_documento).subscribe({
      next: (doc) => abrirDocumentoEnNuevaPestana(doc, ventana),
      error: () => {
        ventana?.close();
        this.mensajeError.set('No se pudo cargar el comprobante.');
      }
    });
  }

  rechazar(d: Donacion) {
    this.mensajeError.set('');
    this.procesando.set(d.id_donacion);
    this.donacionesService.rechazar(d.id_donacion).subscribe({
      next: () => {
        this.procesando.set(null);
        this.cargar();
      },
      error: (error) => {
        this.procesando.set(null);
        console.error('Error al rechazar donación:', error?.error);
        this.mensajeError.set(error?.error?.error ?? error?.error?.mensaje ?? 'No se pudo rechazar la donación.');
      }
    });
  }
}
