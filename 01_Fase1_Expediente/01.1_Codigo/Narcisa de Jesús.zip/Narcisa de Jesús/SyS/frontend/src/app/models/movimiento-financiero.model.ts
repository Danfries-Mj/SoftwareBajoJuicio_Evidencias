export type TipoMovimiento = 'Ingreso' | 'Egreso';

export interface MovimientoFinanciero {
  id_movimiento: number;
  tipo: TipoMovimiento;
  categoria?: string;
  descripcion?: string;
  id_fondo: number;
  fondo_nombre?: string;
  id_capilla?: number | null;
  monto: number;
  fecha: string;
  justificacion?: string;
  registrado_por?: number;
}
