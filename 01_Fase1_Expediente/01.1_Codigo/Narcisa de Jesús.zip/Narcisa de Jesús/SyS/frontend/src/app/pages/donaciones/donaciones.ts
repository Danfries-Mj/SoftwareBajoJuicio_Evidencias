import { Component, inject, OnInit, signal } from '@angular/core';
import { FormBuilder, ReactiveFormsModule, Validators } from '@angular/forms';
import { firstValueFrom } from 'rxjs';
import { SuccessModalComponent } from '../../components/success-modal/success-modal';
import { FormAlertComponent } from '../../components/form-alert/form-alert';
import { AuthService } from '../../services/auth.service';
import { CapillasService } from '../../services/capillas.service';
import { DonacionesService } from '../../services/donaciones.service';
import { DocumentosService } from '../../services/documentos.service';
import { Capilla } from '../../models/capilla.model';
import { montoPositivoValidator, montoMinimoValidator, mensajeDeError, validarArchivo } from '../../shared/utils/validaciones';
import { mensajesTemporales } from '../../shared/utils/mensajes-temporales';

export const DONACION_MONTO_MINIMO = 5;

interface DonacionTipo {
  id: string;
  titulo: string;
  descripcion: string;
  conCapilla: boolean;
  idFondo: number | null;
}

function nuevoArchivo() {
  return { nombre: signal(''), dataUrl: signal(''), mime: signal(''), error: signal('') };
}

@Component({
  selector: 'app-donaciones',
  standalone: true,
  imports: [ReactiveFormsModule, SuccessModalComponent, FormAlertComponent],
  templateUrl: './donaciones.html',
  styleUrl: './donaciones.css'
})
export class DonacionesComponent implements OnInit {
  private authService = inject(AuthService);
  private capillasService = inject(CapillasService);
  private donacionesService = inject(DonacionesService);
  private documentosService = inject(DocumentosService);
  private fb = inject(FormBuilder);

  comprobanteArchivo = nuevoArchivo();

  tipos: DonacionTipo[] = [
    { id: 'salud', titulo: 'Fondo de Salud', descripcion: 'Insumos y equipo médico para la comunidad', conCapilla: false, idFondo: 5 },
    { id: 'general', titulo: 'Fondo General', descripcion: 'Mantenimiento y actividades parroquiales', conCapilla: false, idFondo: 4 },
    { id: 'capilla', titulo: 'Mi capilla', descripcion: 'Dona directamente a tu capilla más cercana', conCapilla: true, idFondo: null }
  ];

  capillas = signal<Capilla[]>([]);

  activeModal: DonacionTipo | null = null;
  showSuccess = false;

  guardando = signal(false);
  mensajeError = mensajesTemporales(signal(''));
  mensajeDeError = mensajeDeError;

  form = this.fb.group({
    idCapilla: [null as number | null],
    monto: ['', [Validators.required, montoPositivoValidator(), montoMinimoValidator(DONACION_MONTO_MINIMO)]]
  });

  ngOnInit() {
    this.capillasService.listar().subscribe({
      next: (capillas) => {
        this.capillas.set(capillas);
        if (capillas.length) this.form.controls.idCapilla.setValue(capillas[0].id_capilla);
      }
    });
  }

  openModal(tipo: DonacionTipo) {
    if (!this.authService.isLoggedIn()) {
      this.mensajeError.set('Debes iniciar sesión para registrar una donación.');
      return;
    }
    if (this.authService.user()?.rol === 'Sacerdote') {
      this.mensajeError.set('El módulo de donaciones no está habilitado para el rol Sacerdote.');
      return;
    }
    this.activeModal = tipo;
    this.resetFormulario();
    this.mensajeError.set('');
  }

  onFileSelect(event: Event) {
    const input = event.target as HTMLInputElement;
    const file = input.files?.[0];
    if (!file) return;

    const error = validarArchivo(file, { tipos: ['application/pdf', 'image/png', 'image/jpeg'] });
    if (error) {
      this.comprobanteArchivo.error.set(error);
      this.comprobanteArchivo.nombre.set('');
      this.comprobanteArchivo.dataUrl.set('');
      input.value = '';
      return;
    }

    this.comprobanteArchivo.error.set('');
    const reader = new FileReader();
    reader.onload = () => {
      this.comprobanteArchivo.nombre.set(file.name);
      this.comprobanteArchivo.dataUrl.set(reader.result as string);
      this.comprobanteArchivo.mime.set(file.type);
    };
    reader.readAsDataURL(file);
  }

  async submit() {
    if (!this.activeModal) return;
    this.mensajeError.set('');

    if (this.form.invalid) {
      this.form.markAllAsTouched();
      this.mensajeError.set('Revisa los campos marcados en rojo.');
      return;
    }

    if (!this.comprobanteArchivo.dataUrl()) {
      this.mensajeError.set('La foto del comprobante es obligatoria.');
      return;
    }

    const { idCapilla, monto } = this.form.getRawValue();
    const montoNumerico = Number(monto);

    const idCapillaDonacion = this.activeModal.conCapilla
      ? idCapilla
      : (this.authService.user()?.id_capilla ?? null);

    this.guardando.set(true);

    try {
      const documento = await firstValueFrom(this.documentosService.crear({
        tipo: 'Comprobante de donación',
        archivo_nombre: this.comprobanteArchivo.nombre(),
        archivo_url: this.comprobanteArchivo.dataUrl(),
        mime_type: this.comprobanteArchivo.mime()
      }));

      await firstValueFrom(this.donacionesService.crear({
        id_capilla: idCapillaDonacion,
        fecha: new Date().toISOString().slice(0, 10),
        monto: montoNumerico,
        id_documento: documento.id_documento,
        id_fondo: this.activeModal.idFondo
      }));

      this.guardando.set(false);
      this.activeModal = null;
      this.showSuccess = true;
      this.resetFormulario();
    } catch (error: any) {
      this.guardando.set(false);
      this.mensajeError.set(error?.error?.mensaje ?? 'No se pudo registrar la donación.');
    }
  }

  closeModal() {
    this.activeModal = null;
    this.resetFormulario();
  }

  private resetFormulario() {
    this.form.reset({ idCapilla: this.capillas()[0]?.id_capilla ?? null, monto: '' });
    this.comprobanteArchivo = nuevoArchivo();
  }

  closeOnOverlay(event: MouseEvent) {
    if (event.target === event.currentTarget) {
      this.closeModal();
    }
  }
}
