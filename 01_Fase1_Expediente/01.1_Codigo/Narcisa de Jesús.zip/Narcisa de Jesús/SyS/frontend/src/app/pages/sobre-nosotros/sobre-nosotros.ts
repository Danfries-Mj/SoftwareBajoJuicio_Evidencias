import { Component, OnInit, inject, signal } from '@angular/core';
import { EstadisticasService } from '../../services/estadisticas.service';

interface Estadistica {
  value: string;
  label: string;
}

@Component({
  selector: 'app-sobre-nosotros',
  standalone: true,
  imports: [],
  templateUrl: './sobre-nosotros.html',
  styleUrl: './sobre-nosotros.css'
})
export class SobreNosotrosComponent implements OnInit {
  private estadisticasService = inject(EstadisticasService);

  // "+40 años de servicio" es un dato histórico de la parroquia, no viene de la BD.
  stats = signal<Estadistica[]>([
    { value: '+40', label: 'Años de\nservicio' },
    { value: '—', label: 'Capillas' },
    { value: '—', label: 'Catequizandos' },
    { value: '—', label: 'Catequistas' }
  ]);

  ngOnInit() {
    this.estadisticasService.publicas().subscribe({
      next: (estadisticas) => {
        this.stats.set([
          { value: '+40', label: 'Años de\nservicio' },
          { value: String(estadisticas.capillas), label: 'Capillas' },
          { value: String(estadisticas.catequizandos), label: 'Catequizandos' },
          { value: String(estadisticas.catequistas), label: 'Catequistas' }
        ]);
      }
    });
  }
}
