import { Component, inject, OnInit, signal } from '@angular/core';
import { DatePipe } from '@angular/common';
import { AuthService } from '../../services/auth.service';
import { ComunicadosService } from '../../services/comunicados.service';
import { Comunicado } from '../../models/comunicado.model';
import { mensajesTemporales } from '../../shared/utils/mensajes-temporales';

@Component({
  selector: 'app-comunicados',
  standalone: true,
  imports: [DatePipe],
  templateUrl: './comunicados.html',
  styleUrl: './comunicados.css'
})
export class ComunicadosComponent implements OnInit {
  private authService = inject(AuthService);
  private comunicadosService = inject(ComunicadosService);

  comunicados = signal<Comunicado[]>([]);
  mensajeError = mensajesTemporales(signal(''));

  ngOnInit() {
    const idCapilla = this.authService.user()?.id_capilla ?? undefined;
    this.comunicadosService.listarPublicos(idCapilla).subscribe({
      next: (comunicados) => this.comunicados.set(comunicados),
      error: () => this.mensajeError.set('No se pudieron cargar los comunicados.')
    });
  }
}
