export type RolUsuario = 'Laico' | 'Catequista' | 'Coordinador' | 'Tesorero' | 'Sacerdote';

export interface Usuario {
  id_usuario: number;
  id_persona: number;
  cedula: string;
  nombres: string;
  apellidos: string;
  telefono?: string;
  correo: string;
  rol: RolUsuario;
  id_capilla: number | null;
  capilla_nombre?: string;
  activo: boolean;
  fecha_registro?: string;
}
