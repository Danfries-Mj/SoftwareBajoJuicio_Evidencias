export type TipoCertificado = 'Bautismo' | 'Primera Comunion' | 'Confirmacion' | 'Matrimonio';
export type EstadoCertificado = 'Pendiente' | 'Emitido' | 'Rechazado';

export interface Certificado {
  id_certificado: number;
  id_persona: number;
  tipo: TipoCertificado;
  id_capilla?: number | null;
  capilla_nombre?: string;
  estado: EstadoCertificado;
  fecha_solicitud?: string;
  fecha_emision?: string;
  archivo_url?: string;
  archivo_nombre?: string;
  mime_type?: string;
  solicitante_nombres?: string;
  solicitante_apellidos?: string;
}
