import { Component, inject, OnInit, signal } from '@angular/core';
import { FormBuilder, ReactiveFormsModule, Validators } from '@angular/forms';
import { SuccessModalComponent } from '../../components/success-modal/success-modal';
import { FormAlertComponent } from '../../components/form-alert/form-alert';
import { AuthService } from '../../services/auth.service';
import { IntencionesMisaService } from '../../services/intenciones-misa.service';
import { cedulaEcuatorianaValidator, soloTextoValidator, fechaNoPasadaValidator, mensajeDeError } from '../../shared/utils/validaciones';
import { mensajesTemporales } from '../../shared/utils/mensajes-temporales';

@Component({
  selector: 'app-intenciones-misa',
  standalone: true,
  imports: [ReactiveFormsModule, SuccessModalComponent, FormAlertComponent],
  templateUrl: './intenciones-misa.html',
  styleUrl: './intenciones-misa.css'
})
export class IntencionMisaComponent implements OnInit {
  private authService = inject(AuthService);
  private intencionesService = inject(IntencionesMisaService);
  private fb = inject(FormBuilder);

  showSuccess = false;
  guardando = signal(false);
  mensajeError = mensajesTemporales(signal(''));
  mensajeDeError = mensajeDeError;

  readonly tiposIntencion = ['Por Difunto', 'Por matrimonio', 'Por nacimiento'];

  form = this.fb.group({
    cedula: ['', [Validators.required, cedulaEcuatorianaValidator()]],
    nombreCompleto: ['', [Validators.required, soloTextoValidator()]],
    nombreMencionar: ['', [Validators.required, soloTextoValidator()]],
    tipoIntencion: ['Por Difunto', [Validators.required]],
    fechaDisponible: ['', [Validators.required, fechaNoPasadaValidator()]]
  });

  ngOnInit() {
    const u = this.authService.user();
    this.form.patchValue({
      cedula: u?.cedula ?? '',
      nombreCompleto: u ? `${u.nombres} ${u.apellidos}` : ''
    });
  }

  submit() {
    this.mensajeError.set('');

    if (!this.authService.isLoggedIn()) {
      this.mensajeError.set('Debes iniciar sesión para solicitar una intención de misa.');
      return;
    }

    if (this.form.invalid) {
      this.form.markAllAsTouched();
      this.mensajeError.set('Revisa los campos marcados en rojo.');
      return;
    }

    const { nombreMencionar, tipoIntencion, fechaDisponible } = this.form.getRawValue();

    this.guardando.set(true);
    this.intencionesService.crear({
      nombre_mencionar: nombreMencionar!,
      tipo: tipoIntencion!,
      fecha_deseada: fechaDisponible!
    }).subscribe({
      next: () => {
        this.guardando.set(false);
        this.form.patchValue({ nombreMencionar: '', tipoIntencion: 'Por Difunto', fechaDisponible: '' });
        this.form.markAsUntouched();
        this.showSuccess = true;
      },
      error: (error) => {
        this.guardando.set(false);
        this.mensajeError.set(error?.error?.mensaje ?? 'No se pudo enviar la intención de misa.');
      }
    });
  }

  reset() {
    this.showSuccess = false;
  }
}
