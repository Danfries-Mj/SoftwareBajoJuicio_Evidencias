import { inject } from '@angular/core';
import { CanActivateFn, Router } from '@angular/router';
import { AuthService } from '../../services/auth.service';
import { ModalService } from '../../services/modal.service';

export const requireAuth: CanActivateFn = () => {
  const authService = inject(AuthService);
  const router = inject(Router);
  const modalService = inject(ModalService);

  if (authService.isLoggedIn()) {
    return true;
  }

  modalService.openLogin();
  return router.createUrlTree(['/']);
};
