import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, map } from 'rxjs';
import { API_URL } from '../core/config/api.config';
import { HistorialInscrito } from '../models/historial-inscrito.model';

@Injectable({ providedIn: 'root' })
export class HistorialInscritoService {
  private apiUrl = `${API_URL}/historial-inscrito`;

  constructor(private http: HttpClient) {}

  listarPorInscrito(idInscrito: number): Observable<HistorialInscrito[]> {
    return this.http.get<{ mensaje: string; total: number; historial: HistorialInscrito[] }>(`${this.apiUrl}/inscrito/${idInscrito}`)
      .pipe(map(respuesta => respuesta.historial));
  }

  buscarPorId(id: number): Observable<HistorialInscrito> {
    return this.http.get<{ mensaje: string; registro: HistorialInscrito }>(`${this.apiUrl}/${id}`)
      .pipe(map(respuesta => respuesta.registro));
  }

  crear(datos: { id_inscrito: number; comprobante?: string; estado_anterior?: string; estado_nuevo: string; nota?: string }): Observable<HistorialInscrito> {
    return this.http.post<{ mensaje: string; registro: HistorialInscrito }>(this.apiUrl, datos)
      .pipe(map(respuesta => respuesta.registro));
  }
}
