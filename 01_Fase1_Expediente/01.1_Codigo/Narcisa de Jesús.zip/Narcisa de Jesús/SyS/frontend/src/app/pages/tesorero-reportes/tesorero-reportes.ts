import { Component, OnInit, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { FondosService } from '../../services/fondos.service';
import { MovimientosFinancierosService } from '../../services/movimientos-financieros.service';
import { Fondo } from '../../models/fondo.model';
import { MovimientoFinanciero } from '../../models/movimiento-financiero.model';
import { mensajesTemporales } from '../../shared/utils/mensajes-temporales';
import { autoRecarga } from '../../shared/utils/auto-recarga';

@Component({
  selector: 'app-tesorero-reportes',
  standalone: true,
  imports: [FormsModule],
  templateUrl: './tesorero-reportes.html',
  styleUrl: './tesorero-reportes.css'
})
export class TesoreroReportesComponent implements OnInit {
  protected Math = Math;

  private fondosService = inject(FondosService);
  private movimientosService = inject(MovimientosFinancierosService);

  filtro = { fechaInicio: '', fechaFin: '', fondo: 'Todos los fondos', tipo: 'Ingresos y egresos' };
  tipos = ['Ingresos y egresos', 'Solo ingresos', 'Solo egresos'];
  fondosOpciones = signal<Fondo[]>([]);
  reporteGenerado = signal(false);
  cargando = signal(false);
  mensajeError = mensajesTemporales(signal(''));

  todosMovimientos = signal<MovimientoFinanciero[]>([]);

  constructor() {
    autoRecarga(() => this.refrescar());
  }

  ngOnInit() {
    this.cargarFondos();
  }

  private cargarFondos() {
    this.fondosService.listar().subscribe({
      next: (fondos) => this.fondosOpciones.set(fondos)
    });
  }

  private refrescar() {
    this.cargarFondos();
    if (this.reporteGenerado() && this.filtro.fechaInicio && this.filtro.fechaFin) {
      this.movimientosService.listar({
        fecha_desde: this.filtro.fechaInicio,
        fecha_hasta: this.filtro.fechaFin
      }).subscribe({
        next: (movimientos) => this.todosMovimientos.set(movimientos)
      });
    }
  }

  get detalle(): MovimientoFinanciero[] {
    if (!this.reporteGenerado()) return [];
    return this.todosMovimientos().filter(m => {
      if (this.filtro.fondo !== 'Todos los fondos' && m.fondo_nombre !== this.filtro.fondo) return false;
      if (this.filtro.tipo === 'Solo ingresos') return m.tipo === 'Ingreso';
      if (this.filtro.tipo === 'Solo egresos') return m.tipo === 'Egreso';
      return true;
    });
  }

  get totalIngresos() { return this.detalle.filter(m => m.tipo === 'Ingreso').reduce((s, m) => s + Number(m.monto), 0); }
  get totalEgresos() { return this.detalle.filter(m => m.tipo === 'Egreso').reduce((s, m) => s + Number(m.monto), 0); }
  get balance() { return this.totalIngresos - this.totalEgresos; }

  formatFecha(fecha: string): string {
    if (!fecha) return '—';
    const [y, m, d] = fecha.slice(0, 10).split('-');
    return `${d}/${m}/${y}`;
  }

  montoSigno(m: MovimientoFinanciero): number {
    return m.tipo === 'Ingreso' ? Number(m.monto) : -Number(m.monto);
  }

  exportarPDF() {
    window.print();
  }

  generarReporte() {
    this.mensajeError.set('');

    if (!this.filtro.fechaInicio || !this.filtro.fechaFin) {
      this.mensajeError.set('Selecciona una fecha de inicio y una fecha de fin.');
      return;
    }

    this.cargando.set(true);
    this.movimientosService.listar({
      fecha_desde: this.filtro.fechaInicio,
      fecha_hasta: this.filtro.fechaFin
    }).subscribe({
      next: (movimientos) => {
        this.cargando.set(false);
        this.todosMovimientos.set(movimientos);
        this.reporteGenerado.set(true);
      },
      error: (error) => {
        this.cargando.set(false);
        this.mensajeError.set(error?.error?.mensaje ?? 'No se pudo generar el reporte.');
      }
    });
  }
}
