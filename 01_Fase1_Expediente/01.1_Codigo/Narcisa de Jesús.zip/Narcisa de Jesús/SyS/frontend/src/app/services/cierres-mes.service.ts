import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, map } from 'rxjs';
import { API_URL } from '../core/config/api.config';
import { CierreMes } from '../models/cierre-mes.model';

@Injectable({ providedIn: 'root' })
export class CierresMesService {
  private apiUrl = `${API_URL}/cierres-mes`;

  constructor(private http: HttpClient) {}

  listar(): Observable<CierreMes[]> {
    return this.http.get<{ mensaje: string; total: number; cierres: CierreMes[] }>(this.apiUrl)
      .pipe(map(respuesta => respuesta.cierres));
  }

  obtenerPorId(id: number): Observable<CierreMes> {
    return this.http.get<{ mensaje: string; cierre: CierreMes }>(`${this.apiUrl}/${id}`)
      .pipe(map(respuesta => respuesta.cierre));
  }

  crear(datos: { mes: number; anio: number }): Observable<CierreMes> {
    return this.http.post<{ mensaje: string; cierre: CierreMes }>(this.apiUrl, datos)
      .pipe(map(respuesta => respuesta.cierre));
  }

  eliminar(id: number): Observable<{ mensaje: string; cierre: CierreMes }> {
    return this.http.delete<{ mensaje: string; cierre: CierreMes }>(`${this.apiUrl}/${id}`);
  }
}
