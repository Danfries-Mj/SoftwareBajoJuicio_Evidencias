import { Component, OnInit, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { FondosService } from '../../services/fondos.service';
import { MovimientosFinancierosService } from '../../services/movimientos-financieros.service';
import { AuthService } from '../../services/auth.service';
import { Fondo } from '../../models/fondo.model';
import { MovimientoFinanciero } from '../../models/movimiento-financiero.model';
import { mensajesTemporales } from '../../shared/utils/mensajes-temporales';
import { autoRecarga } from '../../shared/utils/auto-recarga';
import { categoriasPorTipo, justificacionesPorTipo } from '../../shared/constants/movimiento-financiero-options';

@Component({
  selector: 'app-tesorero-fondos',
  standalone: true,
  imports: [FormsModule],
  templateUrl: './tesorero-fondos.html',
  styleUrl: './tesorero-fondos.css'
})
export class TesoreroFondosComponent implements OnInit {
  protected Math = Math;
  protected Number = Number;

  private fondosService = inject(FondosService);
  private movimientosService = inject(MovimientosFinancierosService);
  private authService = inject(AuthService);

  fondos = signal<Fondo[]>([]);
  movimientos = signal<MovimientoFinanciero[]>([]);
  mensajeError = mensajesTemporales(signal(''));
  mensajeExito = mensajesTemporales(signal(''));

  showModal = false;
  editando: Fondo | null = null;
  guardando = signal(false);
  nombreEditado = '';
  descripcionEditada = '';

  showMovModal = false;
  editandoMov: MovimientoFinanciero | null = null;
  guardandoMov = signal(false);
  tiposMov = ['Ingreso', 'Egreso'];
  nuevoMov: { tipo: string; id_fondo: number | null; categoria: string; descripcion: string; monto: number | null; fecha: string; justificacion: string } = {
    tipo: '', id_fondo: null, categoria: '', descripcion: '', monto: null, fecha: '', justificacion: ''
  };

  get categoriasMov(): string[] {
    return categoriasPorTipo(this.nuevoMov.tipo);
  }

  get justificacionesMov(): string[] {
    return justificacionesPorTipo(this.nuevoMov.tipo);
  }

  onTipoMovChange() {
    if (this.nuevoMov.categoria && !this.categoriasMov.includes(this.nuevoMov.categoria)) {
      this.nuevoMov.categoria = '';
    }
    if (this.nuevoMov.justificacion && !this.justificacionesMov.includes(this.nuevoMov.justificacion)) {
      this.nuevoMov.justificacion = '';
    }
  }

  constructor() {
    autoRecarga(() => this.refrescar());
  }

  ngOnInit() {
    this.cargarFondos();
    this.cargarMovimientos();
  }

  private cargarFondos(mostrarError = true) {
    this.fondosService.listar().subscribe({
      next: (fondos) => this.fondos.set(fondos),
      error: () => { if (mostrarError) this.mensajeError.set('No se pudieron cargar los fondos.'); }
    });
  }

  private cargarMovimientos(mostrarError = true) {
    this.movimientosService.listar().subscribe({
      next: (movimientos) => this.movimientos.set(movimientos.slice(0, 10)),
      error: () => { if (mostrarError) this.mensajeError.set('No se pudieron cargar los movimientos.'); }
    });
  }

  private refrescar() {
    this.cargarFondos(false);
    this.cargarMovimientos(false);
  }

  editar(f: Fondo) {
    this.editando = f;
    this.nombreEditado = f.nombre;
    this.descripcionEditada = f.descripcion ?? '';
    this.mensajeError.set('');
    this.showModal = true;
  }

  cerrarModal() {
    this.showModal = false;
    this.editando = null;
  }

  private idCapillaUsuario(): number | null {
    return this.authService.user()?.id_capilla ?? null;
  }

  /** Editar los datos del fondo (nombre/descripción) es de alcance parroquial: solo el tesorero sin capilla asignada. */
  puedeEditarFondo(_f: Fondo): boolean {
    return this.idCapillaUsuario() === null;
  }

  /** El tesorero de parroquia (sin capilla) edita cualquier movimiento; el de capilla, solo los de la suya. */
  puedeEditarMovimiento(m: MovimientoFinanciero): boolean {
    if (this.idCapillaUsuario() === null) return true;
    return (m.id_capilla ?? null) === this.idCapillaUsuario();
  }

  /** Fondos disponibles como destino al editar un movimiento (mismo alcance que puedeEditarMovimiento). */
  get fondosEditables(): Fondo[] {
    if (this.idCapillaUsuario() === null) return this.fondos();
    return this.fondos().filter(f => (f.id_capilla ?? null) === this.idCapillaUsuario());
  }

  editarMovimiento(m: MovimientoFinanciero) {
    this.editandoMov = m;
    this.nuevoMov = {
      tipo: m.tipo,
      id_fondo: m.id_fondo,
      categoria: m.categoria ?? '',
      descripcion: m.descripcion ?? '',
      monto: m.monto,
      fecha: m.fecha?.slice(0, 10) ?? '',
      justificacion: m.justificacion ?? ''
    };
    this.mensajeError.set('');
    this.showMovModal = true;
  }

  cerrarMovModal() {
    this.showMovModal = false;
    this.editandoMov = null;
  }

  guardarMov() {
    if (!this.editandoMov) return;
    this.mensajeError.set('');

    if (!this.nuevoMov.descripcion.trim() || !this.nuevoMov.id_fondo || !this.nuevoMov.tipo || !this.nuevoMov.monto || !this.nuevoMov.fecha) {
      this.mensajeError.set('Fondo, tipo, descripción, monto y fecha son obligatorios.');
      return;
    }
    if (this.nuevoMov.monto <= 0) {
      this.mensajeError.set('Ingresa un monto válido mayor a cero.');
      return;
    }

    this.guardandoMov.set(true);
    this.movimientosService.editar(this.editandoMov.id_movimiento, {
      tipo: this.nuevoMov.tipo as 'Ingreso' | 'Egreso',
      categoria: this.nuevoMov.categoria || undefined,
      descripcion: this.nuevoMov.descripcion,
      id_fondo: this.nuevoMov.id_fondo,
      monto: this.nuevoMov.monto,
      fecha: this.nuevoMov.fecha,
      justificacion: this.nuevoMov.justificacion || undefined
    }).subscribe({
      next: () => {
        this.guardandoMov.set(false);
        this.mensajeExito.set('Movimiento actualizado correctamente.');
        this.cerrarMovModal();
        this.cargarMovimientos();
        this.cargarFondos();
      },
      error: (error) => {
        this.guardandoMov.set(false);
        this.mensajeError.set(error?.error?.mensaje ?? 'No se pudo actualizar el movimiento.');
      }
    });
  }

  closeMovOnOverlay(e: MouseEvent) {
    if (e.target === e.currentTarget) this.cerrarMovModal();
  }

  closeOnOverlay(e: MouseEvent) {
    if (e.target === e.currentTarget) this.cerrarModal();
  }

  guardar() {
    if (!this.editando) return;
    this.mensajeError.set('');

    if (!this.nombreEditado.trim()) {
      this.mensajeError.set('El nombre del fondo es obligatorio.');
      return;
    }

    this.guardando.set(true);
    this.fondosService.editar(this.editando.id_fondo, {
      nombre: this.nombreEditado.trim(),
      descripcion: this.descripcionEditada.trim() || undefined,
      id_capilla: this.editando.id_capilla ?? null
    }).subscribe({
      next: () => {
        this.guardando.set(false);
        this.mensajeExito.set('Fondo actualizado correctamente.');
        this.cerrarModal();
        this.cargarFondos();
      },
      error: (error) => {
        this.guardando.set(false);
        this.mensajeError.set(error?.error?.mensaje ?? 'No se pudo actualizar el fondo.');
      }
    });
  }

  descripcion(f: Fondo): string {
    if (f.descripcion) return f.descripcion;
    return f.id_capilla ? (f.capilla_nombre ?? 'Capilla') : 'Fondo parroquial general';
  }

  montoSigno(m: MovimientoFinanciero): number {
    return m.tipo === 'Ingreso' ? Number(m.monto) : -Number(m.monto);
  }

  formatFecha(fecha: string): string {
    if (!fecha) return '—';
    const [y, m, d] = fecha.slice(0, 10).split('-');
    return `${d}/${m}/${y}`;
  }
}
