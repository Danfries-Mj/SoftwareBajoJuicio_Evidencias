export type Sacramento = 'Bautizo' | 'Primera Comunion' | 'Confirmacion' | 'Matrimonio';
export type ModalidadSacramento = 'Propia' | 'Terceros';
export type EstadoSolicitudSacramento = 'Pendiente' | 'Atendida' | 'Rechazada';

export interface SolicitudSacramento {
  id_solicitud: number;
  id_usuario: number;
  sacramento: Sacramento;
  modalidad?: ModalidadSacramento;
  id_capilla?: number | null;
  capilla_nombre?: string;
  id_documento?: number | null;
  fecha_solicitud?: string;
  fecha_asignada?: string;
  hora_inicio?: string;
  hora_fin?: string;
  estado: EstadoSolicitudSacramento;
}
