import { Component, inject, signal } from '@angular/core';
import { FormBuilder, ReactiveFormsModule, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { ModalService } from '../../services/modal.service';
import { AuthService } from '../../services/auth.service';
import { FormAlertComponent } from '../form-alert/form-alert';
import { mensajeDeError } from '../../shared/utils/validaciones';
import { mensajesTemporales } from '../../shared/utils/mensajes-temporales';
import { RUTA_POR_ROL } from '../../shared/utils/inicio-roles';

@Component({
  selector: 'app-login-modal',
  standalone: true,
  imports: [ReactiveFormsModule, FormAlertComponent],
  templateUrl: './login-modal.html',
  styleUrl: './login-modal.css'
})
export class LoginModalComponent {
  protected modalService = inject(ModalService);
  private authService = inject(AuthService);
  private router = inject(Router);
  private fb = inject(FormBuilder);

  cargando = signal(false);
  mensajeError = mensajesTemporales(signal(''));
  mensajeDeError = mensajeDeError;

  form = this.fb.group({
    username: ['', [Validators.required, Validators.email]],
    password: ['', [Validators.required]]
  });

  login() {
    if (this.form.invalid) {
      this.form.markAllAsTouched();
      this.mensajeError.set('Revisa los campos marcados en rojo.');
      return;
    }

    const { username, password } = this.form.getRawValue();

    this.cargando.set(true);
    this.mensajeError.set('');
    this.authService.iniciarSesion(username!, password!).subscribe({
      next: (usuario) => {
        this.cargando.set(false);
        this.form.reset();
        this.modalService.closeAll();
        const ruta = RUTA_POR_ROL[usuario.rol];
        if (ruta) this.router.navigate([ruta]);
      },
      error: (error) => {
        this.cargando.set(false);
        this.mensajeError.set(error?.error?.mensaje ?? 'No se pudo iniciar sesión.');
      }
    });
  }

  cerrar() {
    this.form.reset();
    this.mensajeError.set('');
    this.modalService.closeAll();
  }

  closeOnOverlay(event: MouseEvent) {
    if (event.target === event.currentTarget) {
      this.cerrar();
    }
  }
}
