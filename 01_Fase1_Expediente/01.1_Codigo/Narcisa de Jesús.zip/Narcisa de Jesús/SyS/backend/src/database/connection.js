import pg from 'pg';
import { dbConfig } from '../config/db.config.js';

const { Pool } = pg;

export const pool = new Pool(dbConfig);

export const verificarConexion = async() => {
    try {
        await pool.query('SELECT NOW()');
        console.log('Conectado a PostgreSQL');
    } catch (error) {
        console.error('Error al conectar con PostgreSQL:', error.message);
    }
};