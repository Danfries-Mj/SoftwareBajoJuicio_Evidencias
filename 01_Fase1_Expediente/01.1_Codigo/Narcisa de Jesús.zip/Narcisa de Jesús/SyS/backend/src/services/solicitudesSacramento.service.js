import {
    obtenerSolicitudesRepository,
    obtenerSolicitudPorIdRepository,
    obtenerSolicitudPendientePorBeneficiarioRepository,
    crearSolicitudConBeneficiariosRepository,
    asignarSolicitudRepository,
    aprobarSolicitudRepository,
    rechazarSolicitudRepository,
    eliminarSolicitudRepository,
    existeSolicitudAtendidaPorCedulaRepository
} from '../repositories/solicitudesSacramento.repository.js';
import { obtenerBeneficiariosPorSolicitudRepository } from '../repositories/beneficiariosSolicitud.repository.js';
import { actualizarNombreDocumentoRepository } from '../repositories/documentos.repository.js';
import { obtenerCertificadoPrerequisitoRepository } from '../repositories/certificados.repository.js';
import { obtenerUsuarioPorIdRepository } from '../repositories/usuarios.repository.js';

const SACRAMENTOS_VALIDOS = ['Bautizo', 'Primera Comunion', 'Confirmacion', 'Matrimonio'];

export const PRERREQUISITO_SOLICITUD = {
    'Bautizo': null,
    'Primera Comunion': 'Bautismo',
    'Confirmacion': 'Primera Comunion',
    'Matrimonio': 'Confirmacion'
};

// El sacramento de la solicitud no siempre se llama igual que el tipo de certificado
// (Bautizo -> Bautismo); Matrimonio no tiene certificado propio en este sistema, así que
// no hay nada que verificar para ese caso.
export const TIPO_CERTIFICADO_POR_SACRAMENTO = {
    'Bautizo': 'Bautismo',
    'Primera Comunion': 'Primera Comunion',
    'Confirmacion': 'Confirmacion',
    'Matrimonio': null
};

export const obtenerSolicitudesService = async(filtros) => {
    return await obtenerSolicitudesRepository(filtros);
};

export const obtenerSolicitudPorIdService = async(id) => {
    const solicitud = await obtenerSolicitudPorIdRepository(id);

    if (!solicitud) {
        return null;
    }

    const beneficiarios = await obtenerBeneficiariosPorSolicitudRepository(id);

    return { ...solicitud, beneficiarios };
};

export const crearSolicitudService = async(datos) => {
    if (!SACRAMENTOS_VALIDOS.includes(datos.sacramento)) {
        throw new Error(`Sacramento inválido. Sacramentos permitidos: ${SACRAMENTOS_VALIDOS.join(', ')}`);
    }

    const prerequisito = PRERREQUISITO_SOLICITUD[datos.sacramento];

    // Esta validación solo tiene sentido cuando el solicitante pide el sacramento para
    // sí mismo (modalidad 'Propia'): ahí el solicitante es la misma persona que debe
    // cumplir el prerrequisito. Cuando es para un tercero (Bautizo, Primera Comunión y
    // Confirmación en modalidad 'Terceros', o Matrimonio, que no manda modalidad), el
    // beneficiario todavía no existe en este punto —se crea después de la solicitud—,
    // así que no hay forma correcta de revisar su certificado aquí. Esa validación ya
    // la hace el frontend contra la cédula real del tercero (con la opción de adjuntar
    // el certificado como respaldo si no tiene cuenta registrada); revisar en su lugar
    // el certificado del solicitante bloqueaba solicitudes válidas por error.
    if (datos.modalidad === 'Propia') {
        // certificados.id_persona referencia a persona, no a usuarios: hay que resolver
        // el id_persona del solicitante antes de poder consultar sus certificados.
        const solicitante = await obtenerUsuarioPorIdRepository(datos.id_usuario);
        const idPersonaSolicitante = solicitante?.id_persona;

        if (prerequisito) {
            const emitido = idPersonaSolicitante
                ? await obtenerCertificadoPrerequisitoRepository(idPersonaSolicitante, prerequisito)
                : null;
            if (!emitido) {
                throw new Error(`No cumple con el prerrequisito. Necesita el certificado de ${prerequisito} emitido.`);
            }
        }

        // No tiene sentido pedir de nuevo un sacramento que la persona ya recibió: si ya
        // tiene el certificado de este sacramento emitido, se bloquea la solicitud.
        const tipoCertificado = TIPO_CERTIFICADO_POR_SACRAMENTO[datos.sacramento];
        if (tipoCertificado && idPersonaSolicitante) {
            const yaEmitido = await obtenerCertificadoPrerequisitoRepository(idPersonaSolicitante, tipoCertificado);
            if (yaEmitido) {
                throw new Error(`Ya tienes el certificado de ${tipoCertificado} emitido. No puedes volver a solicitar este sacramento.`);
            }
        }
    }

    return await crearSolicitudConBeneficiariosRepository({
        id_usuario: datos.id_usuario,
        sacramento: datos.sacramento,
        modalidad: datos.modalidad,
        id_capilla: datos.id_capilla,
        id_documento: datos.id_documento
    }, datos.beneficiarios || []);
};

export const asignarSolicitudService = async(id, datos) => {
    const solicitud = await asignarSolicitudRepository(id, {
        fecha_asignada: datos.fecha_asignada,
        hora_inicio: datos.hora_inicio,
        hora_fin: datos.hora_fin,
        id_capilla: datos.id_capilla
    });

    if (solicitud?.id_documento) {
        const [beneficiarios, solicitudCompleta] = await Promise.all([
            obtenerBeneficiariosPorSolicitudRepository(id),
            obtenerSolicitudPorIdRepository(id)
        ]);
        const persona = beneficiarios[0]
            ? `${beneficiarios[0].nombres} ${beneficiarios[0].apellidos}`
            : `${solicitudCompleta?.solicitante_nombres ?? ''} ${solicitudCompleta?.solicitante_apellidos ?? ''}`.trim();
        const nombreArchivo = `${solicitud.sacramento}-${(persona.trim() || 'Sin_nombre').replace(/\s+/g, '_')}`;

        await actualizarNombreDocumentoRepository(solicitud.id_documento, nombreArchivo);
    }

    return solicitud;
};

export const aprobarSolicitudService = async(id) => {
    const solicitud = await obtenerSolicitudPorIdRepository(id);
    if (!solicitud) {
        return null;
    }

    // El Catequista solo puede validar el comprobante de pago; el certificado prerrequisito
    // (Bautismo/Primera Comunión) lo valida el Sacerdote por separado. No se aprueba (y por
    // lo tanto no se genera el inscrito) si ese certificado todavía no está Emitido: de lo
    // contrario un certificado pendiente o rechazado podría colarse sin que nadie lo note.
    const prerequisito = PRERREQUISITO_SOLICITUD[solicitud.sacramento];
    if (prerequisito) {
        const beneficiarios = await obtenerBeneficiariosPorSolicitudRepository(id);
        const idPersona = beneficiarios[0]?.id_persona;
        const emitido = idPersona ? await obtenerCertificadoPrerequisitoRepository(idPersona, prerequisito) : null;
        if (!emitido) {
            throw new Error(`No se puede aprobar: el certificado de ${prerequisito} todavía no ha sido validado por el Sacerdote.`);
        }
    }

    return await aprobarSolicitudRepository(id);
};

export const obtenerSolicitudPendientePorBeneficiarioService = async(idPersona, sacramento) => {
    return await obtenerSolicitudPendientePorBeneficiarioRepository(idPersona, sacramento);
};

export const rechazarSolicitudService = async(id) => {
    return await rechazarSolicitudRepository(id);
};

export const eliminarSolicitudService = async(id) => {
    return await eliminarSolicitudRepository(id);
};

export const existeSolicitudAtendidaPorCedulaService = async(cedula, sacramento) => {
    if (!SACRAMENTOS_VALIDOS.includes(sacramento)) {
        throw new Error(`Sacramento inválido. Sacramentos permitidos: ${SACRAMENTOS_VALIDOS.join(', ')}`);
    }

    return await existeSolicitudAtendidaPorCedulaRepository(cedula, sacramento);
};
