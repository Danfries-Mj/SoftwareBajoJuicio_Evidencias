import {
    obtenerEucaristiasRepository,
    obtenerEucaristiaPorIdRepository,
    obtenerEucaristiaDuplicadaRepository,
    crearEucaristiaRepository,
    actualizarEucaristiaRepository,
    marcarPasadasComoRealizadasRepository,
    eliminarEucaristiaRepository
} from '../repositories/eucaristias.repository.js';

export const obtenerEucaristiasService = async(filtros) => {
    return await obtenerEucaristiasRepository(filtros);
};

export const obtenerEucaristiaPorIdService = async(id) => {
    return await obtenerEucaristiaPorIdRepository(id);
};

export const crearEucaristiaService = async(datos) => {
    const duplicada = await obtenerEucaristiaDuplicadaRepository(
        datos.id_capilla, datos.dia_semana, datos.hora_inicio
    );

    if (duplicada) {
        throw new Error('Ya existe un horario de misa activo para esa capilla, día y hora');
    }

    return await crearEucaristiaRepository({
        id_capilla: datos.id_capilla,
        dia_semana: datos.dia_semana,
        fecha: datos.fecha,
        hora_inicio: datos.hora_inicio,
        hora_fin: datos.hora_fin,
        id_sacerdote: datos.id_sacerdote,
        estado: datos.estado || 'Programada'
    });
};

export const actualizarEucaristiaService = async(id, datos) => {
    const duplicada = await obtenerEucaristiaDuplicadaRepository(
        datos.id_capilla, datos.dia_semana, datos.hora_inicio, id
    );

    if (duplicada) {
        throw new Error('Ya existe un horario de misa activo para esa capilla, día y hora');
    }

    return await actualizarEucaristiaRepository(id, {
        id_capilla: datos.id_capilla,
        dia_semana: datos.dia_semana,
        fecha: datos.fecha,
        hora_inicio: datos.hora_inicio,
        hora_fin: datos.hora_fin,
        id_sacerdote: datos.id_sacerdote,
        estado: datos.estado || 'Programada'
    });
};

export const marcarEucaristiasPasadasComoRealizadasService = async() => {
    return await marcarPasadasComoRealizadasRepository();
};

export const eliminarEucaristiaService = async(id) => {
    return await eliminarEucaristiaRepository(id);
};
