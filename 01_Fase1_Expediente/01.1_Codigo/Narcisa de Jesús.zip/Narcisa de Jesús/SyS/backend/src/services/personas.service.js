import {
    obtenerPersonasRepository,
    obtenerPersonaPorIdRepository,
    obtenerPersonaPorCedulaRepository,
    crearPersonaRepository,
    actualizarPersonaRepository,
    eliminarPersonaRepository
} from '../repositories/personas.repository.js';

export const obtenerPersonasService = async() => {
    return await obtenerPersonasRepository();
};

export const obtenerPersonaPorIdService = async(id) => {
    return await obtenerPersonaPorIdRepository(id);
};

export const obtenerPersonaPorCedulaService = async(cedula) => {
    return await obtenerPersonaPorCedulaRepository(cedula);
};

export const crearPersonaService = async(datos) => {
    if (!datos.cedula || !/^\d{10}$/.test(datos.cedula)) {
        throw new Error('La cédula debe tener exactamente 10 dígitos.');
    }
    if (!datos.nombres || !datos.apellidos) {
        throw new Error('Los campos nombres y apellidos son obligatorios.');
    }

    const existente = await obtenerPersonaPorCedulaRepository(datos.cedula);
    if (existente) {
        return existente;
    }

    return await crearPersonaRepository({
        cedula: datos.cedula,
        nombres: datos.nombres,
        apellidos: datos.apellidos,
        telefono: datos.telefono || null
    });
};

export const actualizarPersonaService = async(id, datos) => {
    return await actualizarPersonaRepository(id, {
        nombres: datos.nombres,
        apellidos: datos.apellidos,
        telefono: datos.telefono
    });
};

export const eliminarPersonaService = async(id) => {
    return await eliminarPersonaRepository(id);
};
