import {
    obtenerActasRepository,
    obtenerActaPorIdRepository,
    crearActaRepository,
    actualizarActaRepository,
    eliminarActaRepository
} from '../repositories/actas.repository.js';

const validarAlcanceCoordinador = (usuario, tipo, id_capilla) => {
    if (usuario.rol === 'Coordinador') {
        if (tipo !== 'Capilla' || Number(id_capilla) !== Number(usuario.id_capilla)) {
            throw new Error('El coordinador solo puede gestionar actas de su propia capilla');
        }
    }
};

export const obtenerActasService = async(filtros, usuario) => {
    const filtrosAplicados = { ...filtros };

    // El Coordinador solo puede leer actas parroquiales y las de su propia capilla,
    // nunca las de otra capilla (aunque las pida explícitamente por query param).
    if (usuario?.rol === 'Coordinador') {
        delete filtrosAplicados.id_capilla;
        filtrosAplicados.id_capilla_alcance = usuario.id_capilla;
    }

    return await obtenerActasRepository(filtrosAplicados);
};

export const obtenerActaPorIdService = async(id) => {
    return await obtenerActaPorIdRepository(id);
};

export const crearActaService = async(datos, usuario) => {
    validarAlcanceCoordinador(usuario, datos.tipo, datos.id_capilla);

    return await crearActaRepository({
        titulo: datos.titulo,
        tipo: datos.tipo,
        id_capilla: datos.tipo === 'Parroquial' ? null : datos.id_capilla,
        lugar: datos.lugar,
        descripcion: datos.descripcion,
        asistentes: datos.asistentes,
        fecha: datos.fecha,
        proxima_reunion: datos.proxima_reunion,
        creado_por: usuario.id_usuario
    });
};

export const actualizarActaService = async(id, datos, usuario) => {
    validarAlcanceCoordinador(usuario, datos.tipo, datos.id_capilla);

    return await actualizarActaRepository(id, {
        titulo: datos.titulo,
        tipo: datos.tipo,
        id_capilla: datos.tipo === 'Parroquial' ? null : datos.id_capilla,
        lugar: datos.lugar,
        descripcion: datos.descripcion,
        asistentes: datos.asistentes,
        fecha: datos.fecha,
        proxima_reunion: datos.proxima_reunion,
        estado: datos.estado || 'Borrador'
    });
};

export const eliminarActaService = async(id) => {
    return await eliminarActaRepository(id);
};
