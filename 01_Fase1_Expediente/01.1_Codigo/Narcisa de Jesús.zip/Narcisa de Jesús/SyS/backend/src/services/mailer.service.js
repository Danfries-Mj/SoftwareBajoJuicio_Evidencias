import nodemailer from 'nodemailer';
import { mailerConfig } from '../config/mailer.config.js';

/**
 * rejectUnauthorized: false — en máquinas con antivirus/proxy que inspecciona TLS
 * (Kaspersky, ESET, etc.) el certificado real de Gmail llega reemplazado por uno
 * propio del antivirus, y Node lo rechaza con "self-signed certificate in certificate
 * chain". Como igual pasa por ese intermediario aunque validemos, desactivar la
 * verificación aquí no añade un riesgo nuevo, solo deja de bloquear la conexión SMTP.
 */
const transportador = mailerConfig.host
    ? nodemailer.createTransport({
        host: mailerConfig.host,
        port: mailerConfig.port,
        secure: mailerConfig.secure,
        auth: {
            user: mailerConfig.user,
            pass: mailerConfig.pass
        },
        tls: {
            rejectUnauthorized: false
        }
    })
    : null;

export const enviarCorreoRecuperacion = async(correo, codigo) => {
    if (!transportador) {
        throw new Error('El envío de correos no está configurado. Revisa las variables SMTP en el archivo .env');
    }

    await transportador.sendMail({
        from: mailerConfig.from,
        to: correo,
        subject: 'Código de recuperación de contraseña',
        text: `Tu código para restablecer tu contraseña es: ${codigo}\n\nEste código expira en 15 minutos. Si no solicitaste este cambio, ignora este mensaje.`,
        html: `<p>Tu código para restablecer tu contraseña es:</p><h2>${codigo}</h2><p>Este código expira en 15 minutos. Si no solicitaste este cambio, ignora este mensaje.</p>`
    });
};
