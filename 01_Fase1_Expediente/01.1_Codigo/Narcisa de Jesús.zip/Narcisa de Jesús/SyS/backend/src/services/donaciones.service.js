import {
    obtenerDonacionesRepository,
    obtenerDonacionPorIdRepository,
    crearDonacionRepository,
    cambiarEstadoDonacionRepository,
    eliminarDonacionRepository,
    FONDOS_PARROQUIALES
} from '../repositories/donaciones.repository.js';

export const obtenerDonacionesService = async(filtros, usuario) => {
    const filtrosAplicados = { ...filtros };

    if (usuario?.rol === 'Tesorero') {
        if ((usuario.id_capilla ?? null) === null) {
            filtrosAplicados.solo_parroquiales = true;
        } else {
            filtrosAplicados.id_capilla_tesorero = usuario.id_capilla;
        }
    }

    return await obtenerDonacionesRepository(filtrosAplicados);
};

/**
 * Un Tesorero solo puede ver/aprobar/rechazar donaciones dentro de su propio
 * alcance: el de capilla, solo las de su capilla; el general (sin capilla), solo
 * las dirigidas a fondos parroquiales. El Sacerdote no tiene restricción.
 */
export const puedeGestionarDonacion = (usuario, donacion) => {
    if (!donacion) {
        return false;
    }

    if (usuario.rol === 'Sacerdote') {
        return true;
    }

    if (usuario.rol !== 'Tesorero') {
        return false;
    }

    if ((usuario.id_capilla ?? null) === null) {
        return donacion.id_fondo != null && FONDOS_PARROQUIALES.includes(donacion.fondo_nombre);
    }

    if (donacion.id_fondo == null) {
        return donacion.id_capilla === usuario.id_capilla;
    }

    return donacion.fondo_id_capilla === usuario.id_capilla;
};

export const obtenerDonacionPorIdService = async(id) => {
    return await obtenerDonacionPorIdRepository(id);
};

export const crearDonacionService = async(datos) => {
    return await crearDonacionRepository({
        id_usuario: datos.id_usuario,
        id_capilla: datos.id_capilla,
        fecha: datos.fecha,
        monto: datos.monto,
        id_documento: datos.id_documento,
        id_fondo: datos.id_fondo
    });
};

export const aprobarDonacionService = async(id, idUsuarioRevisor) => {
    return await cambiarEstadoDonacionRepository(id, 'Aprobado', idUsuarioRevisor);
};

export const rechazarDonacionService = async(id, idUsuarioRevisor) => {
    return await cambiarEstadoDonacionRepository(id, 'Rechazado', idUsuarioRevisor);
};

export const eliminarDonacionService = async(id) => {
    return await eliminarDonacionRepository(id);
};
