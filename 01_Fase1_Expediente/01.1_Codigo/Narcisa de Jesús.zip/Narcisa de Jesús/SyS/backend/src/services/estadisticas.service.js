import { obtenerEstadisticasPublicasRepository } from '../repositories/estadisticas.repository.js';

export const obtenerEstadisticasPublicasService = async() => {
    return await obtenerEstadisticasPublicasRepository();
};
