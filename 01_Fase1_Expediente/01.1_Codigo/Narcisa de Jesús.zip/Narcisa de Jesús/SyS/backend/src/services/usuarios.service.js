import {
    obtenerUsuariosRepository,
    obtenerUsuarioPorIdRepository,
    obtenerUsuarioPorCedulaRepository,
    obtenerUsuarioPorCorreoRepository,
    obtenerUsuarioPorPersonaRepository,
    crearUsuarioConPersonaRepository,
    actualizarUsuarioRepository,
    actualizarPerfilUsuarioRepository,
    cambiarEstadoUsuarioRepository
} from '../repositories/usuarios.repository.js';
import { obtenerPersonaPorCedulaRepository } from '../repositories/personas.repository.js';
import { hashearContrasena, compararContrasena, validarFortalezaContrasena } from './auth.service.js';

const ROLES_VALIDOS = ['Laico', 'Catequista', 'Coordinador', 'Tesorero', 'Sacerdote'];

export const obtenerUsuariosService = async(filtros) => {
    return await obtenerUsuariosRepository(filtros);
};

export const obtenerUsuarioPorIdService = async(id) => {
    return await obtenerUsuarioPorIdRepository(id);
};

export const obtenerUsuarioPorCedulaService = async(cedula) => {
    return await obtenerUsuarioPorCedulaRepository(cedula);
};

export const obtenerUsuarioPorPersonaService = async(idPersona) => {
    return await obtenerUsuarioPorPersonaRepository(idPersona);
};

const validarUnicoSacerdote = async(rol, idExcluido) => {
    if (rol !== 'Sacerdote') return;

    const sacerdotes = await obtenerUsuariosRepository({ rol: 'Sacerdote', activo: true });
    const otroSacerdote = sacerdotes.some((s) => s.id_usuario !== idExcluido);

    if (otroSacerdote) {
        throw new Error('Ya existe un usuario con rol Sacerdote. Solo puede haber uno activo a la vez.');
    }
};

export const crearUsuarioService = async(datos, idUsuarioCreador) => {
    if (!ROLES_VALIDOS.includes(datos.rol)) {
        throw new Error(`Rol inválido. Roles permitidos: ${ROLES_VALIDOS.join(', ')}`);
    }

    await validarUnicoSacerdote(datos.rol, null);

    const correoExistente = await obtenerUsuarioPorCorreoRepository(datos.correo);

    if (correoExistente) {
        throw new Error('Ya existe un usuario registrado con ese correo');
    }

    validarFortalezaContrasena(datos.contrasena);
    const contrasenaHash = await hashearContrasena(datos.contrasena);

    // Igual que en el auto-registro: la cédula puede ya tener una persona sin cuenta
    // (inscripción de tercero, bautizando de una solicitud, etc.); se vincula en vez de
    // intentar duplicarla (persona.cedula es UNIQUE).
    const personaExistente = await obtenerPersonaPorCedulaRepository(datos.cedula);

    return await crearUsuarioConPersonaRepository({
        cedula: datos.cedula,
        nombres: datos.nombres,
        apellidos: datos.apellidos,
        telefono: datos.telefono,
        correo: datos.correo,
        idPersonaExistente: personaExistente?.id_persona ?? null,
        contrasenaHash,
        rol: datos.rol,
        id_capilla: datos.id_capilla || null
    }, idUsuarioCreador);
};

export const actualizarUsuarioService = async(id, datos, idUsuarioEditor) => {
    if (!ROLES_VALIDOS.includes(datos.rol)) {
        throw new Error(`Rol inválido. Roles permitidos: ${ROLES_VALIDOS.join(', ')}`);
    }

    await validarUnicoSacerdote(datos.rol, id);

    return await actualizarUsuarioRepository(id, {
        rol: datos.rol,
        id_capilla: datos.id_capilla || null,
        activo: datos.activo !== undefined ? datos.activo : true
    }, idUsuarioEditor);
};

export const actualizarPerfilUsuarioService = async(id, datos) => {
    if (datos.contrasena) {
        const usuario = await obtenerUsuarioPorIdRepository(id);

        if (!usuario) {
            throw new Error('Usuario no encontrado');
        }

        const contrasenaValida = await compararContrasena(datos.contrasenaActual, usuario.contrasena_hash);

        if (!contrasenaValida) {
            throw new Error('La contraseña actual es incorrecta');
        }
    }

    const payload = {
        nombres: datos.nombres,
        apellidos: datos.apellidos,
        telefono: datos.telefono,
        correo: datos.correo
    };

    if (datos.contrasena) {
        validarFortalezaContrasena(datos.contrasena);
        payload.contrasenaHash = await hashearContrasena(datos.contrasena);
    }

    return await actualizarPerfilUsuarioRepository(id, payload);
};

export const desactivarUsuarioService = async(id, idUsuarioEditor) => {
    return await cambiarEstadoUsuarioRepository(id, false, idUsuarioEditor);
};

export const activarUsuarioService = async(id, idUsuarioEditor) => {
    const usuario = await obtenerUsuarioPorIdRepository(id);

    if (usuario) {
        await validarUnicoSacerdote(usuario.rol, id);
    }

    return await cambiarEstadoUsuarioRepository(id, true, idUsuarioEditor);
};
