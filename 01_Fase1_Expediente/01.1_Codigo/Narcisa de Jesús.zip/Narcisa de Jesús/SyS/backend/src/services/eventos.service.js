import {
    obtenerEventosRepository,
    obtenerEventoPorIdRepository,
    obtenerEucaristiaDuplicadaRepository,
    crearEventoRepository,
    actualizarEventoRepository,
    eliminarEventoRepository
} from '../repositories/eventos.repository.js';
import {
    crearEucaristiaRepository,
    actualizarEucaristiaRepository,
    eliminarEucaristiaRepository,
    obtenerEucaristiaPorIdEventoRepository
} from '../repositories/eucaristias.repository.js';

const diaSemanaDeFecha = (fecha) => {
    const date = typeof fecha === 'string' ? new Date(fecha + 'T00:00:00') : new Date(fecha);
    return ['Domingo', 'Lunes', 'Martes', 'Miercoles', 'Jueves', 'Viernes', 'Sabado'][date.getDay()];
};

const sincronizarEucaristiaDeEvento = async(evento, idUsuario) => {
    if (evento.categoria !== 'Eucaristia') {
        const vinculada = await obtenerEucaristiaPorIdEventoRepository(evento.id_evento);
        if (vinculada) {
            await eliminarEucaristiaRepository(vinculada.id_eucaristia);
        }
        return;
    }

    const datosEucaristia = {
        id_capilla: evento.id_capilla,
        dia_semana: diaSemanaDeFecha(evento.fecha),
        fecha: evento.fecha,
        hora_inicio: evento.hora_inicio,
        hora_fin: evento.hora_fin,
        id_sacerdote: idUsuario,
        estado: 'Programada'
    };

    const vinculada = await obtenerEucaristiaPorIdEventoRepository(evento.id_evento);
    if (vinculada) {
        await actualizarEucaristiaRepository(vinculada.id_eucaristia, {
            ...datosEucaristia,
            id_evento: evento.id_evento
        });
    } else {
        await crearEucaristiaRepository({
            ...datosEucaristia,
            id_evento: evento.id_evento
        });
    }
};

const validarAlcanceCoordinador = (usuario, tipo_ambito, id_capilla) => {
    if (usuario.rol === 'Coordinador') {
        if (tipo_ambito !== 'Capilla' || Number(id_capilla) !== Number(usuario.id_capilla)) {
            throw new Error('El coordinador solo puede gestionar eventos de su propia capilla');
        }
    }
};

const validarEucaristiaDuplicada = async(categoria, fecha, horaInicio, idExcluir = null) => {
    if (categoria !== 'Eucaristia' || !fecha || !horaInicio) {
        return;
    }

    const duplicada = await obtenerEucaristiaDuplicadaRepository(fecha, horaInicio, idExcluir);
    if (duplicada) {
        throw new Error('Ya hay una eucaristía asignada a esta hora');
    }
};

export const obtenerEventosService = async(filtros) => {
    return await obtenerEventosRepository(filtros);
};

export const obtenerEventoPorIdService = async(id) => {
    return await obtenerEventoPorIdRepository(id);
};

export const crearEventoService = async(datos, usuario) => {
    validarAlcanceCoordinador(usuario, datos.tipo_ambito, datos.id_capilla);
    await validarEucaristiaDuplicada(datos.categoria, datos.fecha, datos.hora_inicio);

    const evento = await crearEventoRepository({
        nombre: datos.nombre,
        descripcion: datos.descripcion,
        tipo_ambito: datos.tipo_ambito,
        categoria: datos.categoria || 'Evento',
        id_capilla: datos.tipo_ambito === 'Parroquial' ? null : datos.id_capilla,
        fecha: datos.fecha,
        hora_inicio: datos.hora_inicio,
        hora_fin: datos.hora_fin,
        lugar: datos.lugar,
        capacidad: datos.capacidad,
        estado: datos.estado || 'Proximo',
        creado_por: usuario.id_usuario
    });

    await sincronizarEucaristiaDeEvento(evento, usuario.id_usuario);

    return evento;
};

export const actualizarEventoService = async(id, datos, usuario) => {
    const eventoExistente = await obtenerEventoPorIdRepository(id);

    if (!eventoExistente) {
        return null;
    }

    validarAlcanceCoordinador(usuario, datos.tipo_ambito, datos.id_capilla);

    if (usuario.rol === 'Coordinador' && Number(eventoExistente.id_capilla) !== Number(usuario.id_capilla)) {
        throw new Error('El coordinador solo puede gestionar eventos de su propia capilla');
    }

    await validarEucaristiaDuplicada(datos.categoria, datos.fecha, datos.hora_inicio, id);

    const evento = await actualizarEventoRepository(id, {
        nombre: datos.nombre,
        descripcion: datos.descripcion,
        tipo_ambito: datos.tipo_ambito,
        categoria: datos.categoria || 'Evento',
        id_capilla: datos.tipo_ambito === 'Parroquial' ? null : datos.id_capilla,
        fecha: datos.fecha,
        hora_inicio: datos.hora_inicio,
        hora_fin: datos.hora_fin,
        lugar: datos.lugar,
        capacidad: datos.capacidad,
        estado: datos.estado || 'Proximo'
    });

    await sincronizarEucaristiaDeEvento(evento, usuario.id_usuario);

    return evento;
};

export const eliminarEventoService = async(id, usuario) => {
    const eventoExistente = await obtenerEventoPorIdRepository(id);

    if (!eventoExistente) {
        return null;
    }

    if (usuario.rol === 'Coordinador' && Number(eventoExistente.id_capilla) !== Number(usuario.id_capilla)) {
        throw new Error('El coordinador solo puede gestionar eventos de su propia capilla');
    }

    return await eliminarEventoRepository(id);
};
