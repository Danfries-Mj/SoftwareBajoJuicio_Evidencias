import {
    obtenerFondosRepository,
    obtenerFondosPorAlcanceRepository,
    obtenerFondoPorIdRepository,
    crearFondoRepository,
    actualizarFondoRepository,
    eliminarFondoRepository
} from '../repositories/fondos.repository.js';

export const obtenerFondosService = async(usuario) => {
    if (usuario.rol === 'Tesorero' || usuario.rol === 'Coordinador') {
        return await obtenerFondosPorAlcanceRepository(usuario.id_capilla);
    }

    return await obtenerFondosRepository();
};

export const puedeEditarFondo = (usuario, fondo) => {
    if (!fondo) {
        return false;
    }

    if (usuario.rol === 'Tesorero') {
        return (fondo.id_capilla ?? null) === (usuario.id_capilla ?? null);
    }

    return true;
};

/**
 * Editar los datos del fondo (nombre/descripción) es una acción a nivel parroquial:
 * solo el tesorero de parroquia (sin capilla asignada) o el sacerdote pueden hacerlo.
 * El tesorero de una capilla siempre ve estos cuadros de solo lectura, incluida
 * la de su propia capilla.
 */
export const puedeEditarDatosFondo = (usuario) => {
    if (usuario.rol === 'Sacerdote') {
        return true;
    }

    return usuario.rol === 'Tesorero' && (usuario.id_capilla ?? null) === null;
};

/**
 * Editar un movimiento financiero ya registrado: el tesorero de parroquia (sin
 * capilla) puede editar cualquier movimiento; el tesorero de una capilla solo
 * los movimientos ligados al fondo de su propia capilla.
 */
export const puedeEditarMovimientoDeFondo = (usuario, fondo) => {
    if (!fondo) {
        return false;
    }

    if (usuario.rol === 'Tesorero' && (usuario.id_capilla ?? null) === null) {
        return true;
    }

    return puedeEditarFondo(usuario, fondo);
};

export const obtenerFondoPorIdService = async(id) => {
    return await obtenerFondoPorIdRepository(id);
};

export const crearFondoService = async(datos) => {
    return await crearFondoRepository({
        nombre: datos.nombre,
        descripcion: datos.descripcion,
        saldo_actual: datos.saldo_actual || 0,
        id_capilla: datos.id_capilla || null
    });
};

export const actualizarFondoService = async(id, datos) => {
    return await actualizarFondoRepository(id, {
        nombre: datos.nombre,
        descripcion: datos.descripcion,
        id_capilla: datos.id_capilla || null
    });
};

export const eliminarFondoService = async(id) => {
    return await eliminarFondoRepository(id);
};
