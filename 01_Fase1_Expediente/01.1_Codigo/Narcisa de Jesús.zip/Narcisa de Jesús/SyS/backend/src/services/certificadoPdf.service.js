import PDFDocument from 'pdfkit';
import path from 'path';
import { fileURLToPath } from 'url';

const __dirname = path.dirname(fileURLToPath(
    import.meta.url));
const FONTS_DIR = path.join(__dirname, '..', 'assets', 'fonts');

const COLORS = {
    cream: '#FFFDF8',
    primary: '#6B3315',
    primaryDark: '#4A2210',
    accent: '#C58A15',
    textDark: '#2C1204',
    border: '#E8D5B7'
};

const PARROQUIA = {
    nombre: 'PARROQUIA NUESTRA SEÑORA DE GUADALUPE',
    tagline: 'Tu hogar espiritual',
    direccion: 'Av. Las Palmeras y Circunvalación Norte, Machala',
    telefono: '072-937-152',
    ciudad: 'Machala, Ecuador'
};

const SUBTITULO_POR_TIPO = {
    'Bautismo': 'BAUTIZO',
    'Primera Comunion': 'PRIMERA COMUNIÓN',
    'Confirmacion': 'CONFIRMACIÓN',
    'Matrimonio': 'MATRIMONIO'
};


const SIN_LIGADURAS = { features: { liga: false, clig: false, rlig: false, calt: false } };

function letterSpaced(text) {
    return text.split('').join(' ');
}

function centeredText(doc, text, y, { font, size, color, width = 720, x = 36 }) {
    doc.font(font).fontSize(size).fillColor(color);
    doc.text(text, x, y, { width, align: 'center', ...SIN_LIGADURAS });
}

/**
 * Párrafo centrado con tramos en negrita, ajustado línea por línea a mano
 */
function centeredRichParagraph(doc, segments, startY, { width, x, lineHeight }) {
    const words = [];
    segments.forEach((seg) => {
        seg.text.split(' ').filter(Boolean).forEach((w) => {
            words.push({ text: w, font: seg.bold ? 'Times-Bold' : 'Times-Roman' });
        });
    });

    const size = 12.5;
    doc.fontSize(size).fillColor(COLORS.textDark);
    const spaceWidth = (font) => {
        doc.font(font);
        return doc.widthOfString(' ');
    };

    const lines = [];
    let current = [];
    let currentWidth = 0;
    words.forEach((w) => {
        doc.font(w.font);
        const wWidth = doc.widthOfString(w.text);
        const add = current.length ? spaceWidth(w.font) + wWidth : wWidth;
        if (currentWidth + add > width && current.length) {
            lines.push(current);
            current = [w];
            currentWidth = wWidth;
        } else {
            current.push(w);
            currentWidth += add;
        }
    });
    if (current.length) lines.push(current);

    let y = startY;
    lines.forEach((line) => {
        let total = 0;
        line.forEach((w, i) => {
            doc.font(w.font);
            total += doc.widthOfString(w.text);
            if (i < line.length - 1) total += doc.widthOfString(' ');
        });
        let cx = x + (width - total) / 2;
        line.forEach((w, i) => {
            doc.font(w.font).fontSize(size).fillColor(COLORS.textDark);
            doc.text(w.text, cx, y, { lineBreak: false });
            cx += doc.widthOfString(w.text);
            if (i < line.length - 1) cx += doc.widthOfString(' ');
        });
        y += lineHeight;
    });
    return y;
}

/** Texto curvo a lo largo de un arco, espaciado según el ancho real de cada carácter. */
function curvedText(doc, text, cx, cy, radius, { font, size, color, startAngleDeg }) {
    doc.font(font).fontSize(size).fillColor(color);
    const chars = text.split('');
    const widths = chars.map((c) => doc.widthOfString(c, undefined, SIN_LIGADURAS));
    const totalArcLen = widths.reduce((a, w) => a + w, 0);
    const totalAngle = totalArcLen / radius;
    let angle = startAngleDeg * (Math.PI / 180) - totalAngle / 2;

    chars.forEach((ch, i) => {
        const charAngle = widths[i] / radius;
        const midAngle = angle + charAngle / 2;
        const x = cx + radius * Math.sin(midAngle);
        const y = cy - radius * Math.cos(midAngle);
        doc.save();
        doc.translate(x, y);
        doc.rotate(midAngle * 180 / Math.PI);
        doc.text(ch, -widths[i] / 2, -size / 2, { lineBreak: false, ...SIN_LIGADURAS });
        doc.restore();
        angle += charAngle;
    });
}

function dibujarSello(doc, cx, cy, radius) {
    doc.save();
    doc.lineWidth(1.5).strokeColor(COLORS.accent);
    doc.circle(cx, cy, radius).stroke();
    doc.circle(cx, cy, radius - 7).stroke();

    doc.lineWidth(2).strokeColor(COLORS.primary);
    doc.moveTo(cx, cy - 13).lineTo(cx, cy + 13).stroke();
    doc.moveTo(cx - 8, cy - 4).lineTo(cx + 8, cy - 4).stroke();
    doc.restore();

    curvedText(doc, letterSpaced(PARROQUIA.nombre), cx, cy, radius - 15, {
        font: 'Playfair-Bold',
        size: 4.6,
        color: COLORS.primaryDark,
        startAngleDeg: 0
    });
}

function formatearFecha(fecha) {
    const d = fecha ? new Date(fecha) : new Date();
    return new Intl.DateTimeFormat('es-EC', { day: 'numeric', month: 'long', year: 'numeric', timeZone: 'UTC' }).format(d);
}

/**
 * Genera el PDF del certificado (Bautismo/Primera Comunión/Confirmación/Matrimonio)
 * con el diseño de diploma estándar de la parroquia. Devuelve un Buffer con el PDF.
 */
export function generarCertificadoPdfBuffer({ tipo, nombreCompleto, capillaNombre, fechaEmision, parrocoNombre }) {
    return new Promise((resolve, reject) => {
        const doc = new PDFDocument({ size: 'LETTER', layout: 'landscape', margins: { top: 0, bottom: 0, left: 0, right: 0 } });

        doc.registerFont('Playfair', path.join(FONTS_DIR, 'PlayfairDisplay-Variable.ttf'));
        doc.registerFont('Playfair-Bold', path.join(FONTS_DIR, 'PlayfairDisplay-Variable.ttf'));
        doc.registerFont('Playfair-Italic', path.join(FONTS_DIR, 'PlayfairDisplay-Italic-Variable.ttf'));
        doc.registerFont('Signature', path.join(FONTS_DIR, 'GreatVibes-Regular.ttf'));

        const chunks = [];
        doc.on('data', (chunk) => chunks.push(chunk));
        doc.on('end', () => resolve(Buffer.concat(chunks)));
        doc.on('error', reject);

        const W = 792,
            H = 612;
        const cx = W / 2;

        doc.rect(0, 0, W, H).fill(COLORS.cream);
        doc.lineWidth(3).strokeColor(COLORS.accent).rect(26, 26, W - 52, H - 52).stroke();
        doc.lineWidth(1).strokeColor(COLORS.accent).rect(36, 36, W - 72, H - 72).stroke();

        centeredText(doc, PARROQUIA.nombre, 64, { font: 'Playfair-Bold', size: 19, color: COLORS.primaryDark });
        centeredText(doc, PARROQUIA.tagline, 91, { font: 'Playfair-Italic', size: 11, color: COLORS.accent });
        doc.moveTo(cx - 150, 112).lineTo(cx + 150, 112).lineWidth(0.75).strokeColor(COLORS.border).stroke();

        centeredText(doc, 'CERTIFICADO DE CATEQUESIS', 132, { font: 'Playfair-Bold', size: 31, color: COLORS.primaryDark });

        const subtitulo = SUBTITULO_POR_TIPO[tipo] || tipo.toUpperCase();
        centeredText(doc, `—  ${letterSpaced(subtitulo)}  —`, 178, { font: 'Playfair-Bold', size: 12.5, color: COLORS.accent });

        centeredText(doc, 'Se certifica que', 213, { font: 'Playfair-Italic', size: 13.5, color: COLORS.textDark });
        centeredText(doc, nombreCompleto, 236, { font: 'Playfair-Bold', size: 26, color: COLORS.primaryDark });

        doc.moveTo(cx - 120, 276).lineTo(cx + 120, 276).lineWidth(0.75).strokeColor(COLORS.border).stroke();

        const pWidth = 460;
        const afterParagraphY = centeredRichParagraph(doc, [
            { text: 'ha completado satisfactoriamente el proceso de catequesis correspondiente al nivel de', bold: false },
            { text: `${subtitulo},`, bold: true },
            { text: 'impartido en la capilla', bold: false },
            { text: `"${capillaNombre}".`, bold: true }
        ], 294, { width: pWidth, x: cx - pWidth / 2, lineHeight: 18 });

        centeredText(doc, `${PARROQUIA.direccion} · Tel. ${PARROQUIA.telefono}`, afterParagraphY + 8, { font: 'Playfair-Italic', size: 9.5, color: COLORS.textDark });
        centeredText(doc, `${PARROQUIA.ciudad} — ${formatearFecha(fechaEmision)}`, afterParagraphY + 30, { font: 'Playfair', size: 12, color: COLORS.textDark });

        const footerY = 440;
        doc.moveTo(70, footerY).lineTo(W - 70, footerY).lineWidth(0.75).strokeColor(COLORS.border).stroke();

        const nombreConTitulo = /^padre\s/i.test(parrocoNombre) ? parrocoNombre : `Padre ${parrocoNombre}`;
        const firmaX = 110;
        doc.font('Signature').fontSize(30).fillColor(COLORS.textDark).text(parrocoNombre, firmaX, footerY + 16, { lineBreak: false, ...SIN_LIGADURAS });
        doc.moveTo(firmaX, footerY + 60).lineTo(firmaX + 200, footerY + 60).lineWidth(0.75).strokeColor(COLORS.border).stroke();
        doc.font('Playfair-Bold').fontSize(11).fillColor(COLORS.textDark).text(nombreConTitulo, firmaX, footerY + 66, { width: 220, ...SIN_LIGADURAS });
        doc.font('Playfair-Italic').fontSize(9.5).fillColor('#666').text('Párroco', firmaX, footerY + 82, { width: 220, ...SIN_LIGADURAS });

        const seloCx = W - 160,
            seloCy = footerY + 50;
        dibujarSello(doc, seloCx, seloCy, 42);
        centeredText(doc, 'Sello Parroquial', footerY + 98, { font: 'Playfair-Bold', size: 9.5, color: COLORS.textDark, x: seloCx - 110, width: 220 });
        centeredText(doc, PARROQUIA.nombre, footerY + 112, { font: 'Playfair', size: 7.5, color: '#666', x: seloCx - 110, width: 220 });

        doc.end();
    });
}

/** Genera el certificado y lo devuelve como data URI base64, listo para guardar en archivo_url. */
export async function generarCertificadoPdfDataUri(datos) {
    const buffer = await generarCertificadoPdfBuffer(datos);
    return `data:application/pdf;base64,${buffer.toString('base64')}`;
}