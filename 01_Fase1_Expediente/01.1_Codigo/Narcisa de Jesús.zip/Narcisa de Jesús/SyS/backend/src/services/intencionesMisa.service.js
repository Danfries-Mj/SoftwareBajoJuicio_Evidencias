import {
    obtenerIntencionesRepository,
    obtenerIntencionPorIdRepository,
    crearIntencionRepository,
    asignarIntencionRepository,
    rechazarIntencionRepository,
    eliminarIntencionRepository
} from '../repositories/intencionesMisa.repository.js';

const TIPOS_VALIDOS = ['Por Difunto', 'Por matrimonio', 'Por nacimiento'];

export const obtenerIntencionesService = async(filtros) => {
    return await obtenerIntencionesRepository(filtros);
};

export const obtenerIntencionPorIdService = async(id) => {
    return await obtenerIntencionPorIdRepository(id);
};

export const crearIntencionService = async(datos) => {
    if (!TIPOS_VALIDOS.includes(datos.tipo)) {
        throw new Error(`Tipo inválido. Tipos permitidos: ${TIPOS_VALIDOS.join(', ')}`);
    }

    return await crearIntencionRepository({
        id_usuario: datos.id_usuario,
        nombre_mencionar: datos.nombre_mencionar,
        tipo: datos.tipo,
        fecha_deseada: datos.fecha_deseada,
        id_eucaristia: datos.id_eucaristia || null
    });
};

export const asignarIntencionService = async(id, idEucaristia) => {
    return await asignarIntencionRepository(id, idEucaristia);
};

export const rechazarIntencionService = async(id) => {
    return await rechazarIntencionRepository(id);
};

export const eliminarIntencionService = async(id) => {
    return await eliminarIntencionRepository(id);
};
