import {
    obtenerCapillasRepository,
    obtenerCapillaPorIdRepository,
    crearCapillaRepository,
    actualizarCapillaRepository,
    eliminarCapillaRepository
} from '../repositories/capillas.repository.js';

export const obtenerCapillasService = async() => {
    return await obtenerCapillasRepository();
};

export const obtenerCapillaPorIdService = async(id) => {
    return await obtenerCapillaPorIdRepository(id);
};

export const crearCapillaService = async(datos) => {
    return await crearCapillaRepository({
        nombre: datos.nombre,
        direccion: datos.direccion,
        telefono: datos.telefono
    });
};

export const actualizarCapillaService = async(id, datos) => {
    return await actualizarCapillaRepository(id, {
        nombre: datos.nombre,
        direccion: datos.direccion,
        telefono: datos.telefono,
        activa: datos.activa !== undefined ? datos.activa : true
    });
};

export const eliminarCapillaService = async(id) => {
    return await eliminarCapillaRepository(id);
};
