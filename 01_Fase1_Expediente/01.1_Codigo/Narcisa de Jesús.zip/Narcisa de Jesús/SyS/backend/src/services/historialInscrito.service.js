import {
    obtenerHistorialPorInscritoRepository,
    obtenerHistorialPorIdRepository,
    crearHistorialInscritoRepository
} from '../repositories/historialInscrito.repository.js';

export const obtenerHistorialPorInscritoService = async(idInscrito) => {
    return await obtenerHistorialPorInscritoRepository(idInscrito);
};

export const obtenerHistorialPorIdService = async(id) => {
    return await obtenerHistorialPorIdRepository(id);
};

export const crearHistorialInscritoService = async(datos) => {
    return await crearHistorialInscritoRepository({
        id_inscrito: datos.id_inscrito,
        comprobante: datos.comprobante,
        estado_anterior: datos.estado_anterior,
        estado_nuevo: datos.estado_nuevo,
        nota: datos.nota
    });
};
