import {
    obtenerAuditoriaRepository,
    obtenerAuditoriaPorIdRepository
} from '../repositories/auditoria.repository.js';

export const obtenerAuditoriaService = async(filtros) => {
    return await obtenerAuditoriaRepository(filtros);
};

export const obtenerAuditoriaPorIdService = async(id) => {
    return await obtenerAuditoriaPorIdRepository(id);
};
