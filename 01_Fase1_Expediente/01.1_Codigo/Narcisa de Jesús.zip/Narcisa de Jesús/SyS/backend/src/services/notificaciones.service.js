import {
    obtenerNotificacionesRepository,
    contarPendientesRepository,
    crearNotificacionRepository,
    marcarLeidaRepository,
    marcarTodasLeidasRepository
} from '../repositories/notificaciones.repository.js';
import { obtenerUsuariosPorCapillaRepository, obtenerUsuarioPorIdRepository, obtenerUsuariosRepository } from '../repositories/usuarios.repository.js';

export const listarNotificacionesService = async(idUsuario, soloPendientes = false) => {
    const notificaciones = await obtenerNotificacionesRepository(idUsuario, soloPendientes);
    const pendientes = await contarPendientesRepository(idUsuario);
    return { notificaciones, pendientes };
};

export const crearNotificacionService = async(idUsuario, titulo, mensaje) => {
    if (!idUsuario || !titulo || !mensaje) {
        throw new Error('id_usuario, titulo y mensaje son obligatorios');
    }
    return await crearNotificacionRepository(idUsuario, titulo, mensaje);
};

export const marcarLeidaService = async(idNotificacion, idUsuario) => {
    const notificacion = await marcarLeidaRepository(idNotificacion, idUsuario);
    if (!notificacion) {
        throw new Error('Notificación no encontrada');
    }
    return notificacion;
};

export const marcarTodasLeidasService = async(idUsuario) => {
    return await marcarTodasLeidasRepository(idUsuario);
};

/**
 * El Coordinador envía un aviso personalizado a los miembros de su propia capilla:
 * a un miembro puntual (id_usuario) o, si no se indica, a todos los miembros activos
 * de su capilla (sin incluirse a sí mismo).
 */
export const enviarNotificacionMiembrosService = async(usuario, { id_usuario, titulo, mensaje }) => {
    if (!titulo || !mensaje) {
        throw new Error('titulo y mensaje son obligatorios');
    }

    if (!usuario.id_capilla) {
        throw new Error('No tienes una capilla asignada');
    }

    let destinatarios;
    if (id_usuario) {
        const destinatario = await obtenerUsuarioPorIdRepository(id_usuario);
        if (!destinatario || destinatario.id_capilla !== usuario.id_capilla) {
            throw new Error('El miembro indicado no pertenece a tu capilla');
        }
        // El envío masivo solo alcanza miembros activos, así que el envío puntual
        // tampoco debe poder notificar a un miembro desactivado.
        if (!destinatario.activo) {
            throw new Error('El miembro indicado está desactivado');
        }
        destinatarios = [destinatario.id_usuario];
    } else {
        const idsCapilla = await obtenerUsuariosPorCapillaRepository(usuario.id_capilla);
        destinatarios = idsCapilla.filter((id) => id !== usuario.id_usuario);
    }

    await Promise.all(destinatarios.map((idDestinatario) =>
        crearNotificacionRepository(idDestinatario, titulo, mensaje)
    ));

    return destinatarios.length;
};

/**
 * Avisa al Coordinador de una capilla cuando se registra un nuevo miembro en ella
 * (auto-registro público de un Laico, o alta hecha por el Sacerdote). Si la capilla no
 * tiene Coordinador asignado, simplemente no hay a quién notificar.
 */
export const notificarCoordinadorNuevoMiembroService = async(idCapilla, nombreCompleto) => {
    if (!idCapilla) return;

    const coordinadores = await obtenerUsuariosRepository({ rol: 'Coordinador', id_capilla: idCapilla, activo: true });

    await Promise.all(coordinadores.map((coordinador) =>
        crearNotificacionRepository(
            coordinador.id_usuario,
            'Nuevo miembro en tu capilla',
            `${nombreCompleto} se registró en tu capilla.`
        )
    ));
};

/**
 * Avisa al Sacerdote (solo puede haber uno activo). Se usa para los tres avisos que le
 * interesan a nivel parroquial: nuevos usuarios, nuevos eventos de capilla y comunicados
 * enviados por un Coordinador.
 */
export const notificarSacerdoteService = async(titulo, mensaje) => {
    const sacerdotes = await obtenerUsuariosRepository({ rol: 'Sacerdote', activo: true });

    await Promise.all(sacerdotes.map((sacerdote) =>
        crearNotificacionRepository(sacerdote.id_usuario, titulo, mensaje)
    ));
};
