import {
    obtenerMovimientosRepository,
    obtenerMovimientoPorIdRepository,
    crearMovimientoRepository,
    actualizarMovimientoRepository,
    eliminarMovimientoRepository
} from '../repositories/movimientosFinancieros.repository.js';

const TIPOS_VALIDOS = ['Ingreso', 'Egreso'];

export const obtenerMovimientosService = async(filtros, usuario) => {
    const filtrosAplicados = { ...filtros };

    if (usuario.rol === 'Tesorero' || usuario.rol === 'Coordinador') {
        filtrosAplicados.id_capilla = usuario.id_capilla;
    }

    return await obtenerMovimientosRepository(filtrosAplicados);
};

export const obtenerMovimientoPorIdService = async(id) => {
    return await obtenerMovimientoPorIdRepository(id);
};

export const crearMovimientoService = async(datos, usuario) => {
    if (!TIPOS_VALIDOS.includes(datos.tipo)) {
        throw new Error(`Tipo inválido. Tipos permitidos: ${TIPOS_VALIDOS.join(', ')}`);
    }

    return await crearMovimientoRepository({
        tipo: datos.tipo,
        categoria: datos.categoria,
        descripcion: datos.descripcion,
        id_fondo: datos.id_fondo,
        monto: datos.monto,
        fecha: datos.fecha,
        justificacion: datos.justificacion,
        registrado_por: usuario.id_usuario
    }, usuario.id_usuario);
};

export const actualizarMovimientoService = async(id, datos, usuario) => {
    if (!TIPOS_VALIDOS.includes(datos.tipo)) {
        throw new Error(`Tipo inválido. Tipos permitidos: ${TIPOS_VALIDOS.join(', ')}`);
    }

    return await actualizarMovimientoRepository(id, {
        tipo: datos.tipo,
        categoria: datos.categoria,
        descripcion: datos.descripcion,
        id_fondo: datos.id_fondo,
        monto: datos.monto,
        fecha: datos.fecha,
        justificacion: datos.justificacion
    }, usuario.id_usuario);
};

export const eliminarMovimientoService = async(id, usuario) => {
    return await eliminarMovimientoRepository(id, usuario.id_usuario);
};
