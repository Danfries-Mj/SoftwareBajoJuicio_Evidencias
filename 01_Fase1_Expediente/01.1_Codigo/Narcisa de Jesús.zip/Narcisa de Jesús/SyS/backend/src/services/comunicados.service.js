import {
    obtenerComunicadosRepository,
    obtenerComunicadoPorIdRepository,
    crearComunicadoRepository,
    actualizarComunicadoRepository,
    eliminarComunicadoRepository
} from '../repositories/comunicados.repository.js';

const validarAlcanceCoordinador = (usuario, id_capilla) => {
    if (usuario.rol === 'Coordinador' && Number(id_capilla) !== Number(usuario.id_capilla)) {
        throw new Error('El coordinador solo puede gestionar comunicados de su propia capilla');
    }
};

export const obtenerComunicadosPublicosService = async(idCapilla) => {
    // Un usuario de una capilla específica ve los comunicados de su capilla más los
    // generales de toda la parroquia (id_capilla nulo); uno sin capilla asignada
    // (alcance parroquial) ve los de todas las capillas al no aplicarse filtro.
    return await obtenerComunicadosRepository({ id_capilla: idCapilla, estado: 'Enviado', incluirGenerales: true });
};

export const obtenerComunicadosService = async(filtros) => {
    return await obtenerComunicadosRepository(filtros);
};

export const obtenerComunicadoPorIdService = async(id) => {
    return await obtenerComunicadoPorIdRepository(id);
};

export const crearComunicadoService = async(datos, usuario) => {
    validarAlcanceCoordinador(usuario, datos.id_capilla);

    return await crearComunicadoRepository({
        titulo: datos.titulo,
        mensaje: datos.mensaje,
        id_capilla: datos.id_capilla,
        estado: datos.estado || 'Borrador',
        creado_por: usuario.id_usuario
    });
};

export const actualizarComunicadoService = async(id, datos, usuario) => {
    validarAlcanceCoordinador(usuario, datos.id_capilla);

    return await actualizarComunicadoRepository(id, {
        titulo: datos.titulo,
        mensaje: datos.mensaje,
        id_capilla: datos.id_capilla,
        estado: datos.estado || 'Borrador'
    });
};

export const eliminarComunicadoService = async(id) => {
    return await eliminarComunicadoRepository(id);
};
