import {
    obtenerDocumentosRepository,
    obtenerDocumentoPorIdRepository,
    crearDocumentoRepository,
    actualizarNombreDocumentoRepository,
    eliminarDocumentoRepository
} from '../repositories/documentos.repository.js';

export const obtenerDocumentosService = async(filtros) => {
    return await obtenerDocumentosRepository(filtros);
};

export const obtenerDocumentoPorIdService = async(id) => {
    return await obtenerDocumentoPorIdRepository(id);
};

export const crearDocumentoService = async(datos) => {
    return await crearDocumentoRepository({
        id_usuario: datos.id_usuario,
        tipo: datos.tipo,
        archivo_nombre: datos.archivo_nombre,
        archivo_url: datos.archivo_url,
        mime_type: datos.mime_type
    });
};

export const actualizarNombreDocumentoService = async(id, archivoNombre) => {
    return await actualizarNombreDocumentoRepository(id, archivoNombre);
};

export const eliminarDocumentoService = async(id) => {
    return await eliminarDocumentoRepository(id);
};
