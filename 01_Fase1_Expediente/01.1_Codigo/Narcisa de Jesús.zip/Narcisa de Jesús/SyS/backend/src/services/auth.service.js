import jwt from 'jsonwebtoken';
import bcrypt from 'bcryptjs';
import {
    obtenerUsuarioPorCorreoRepository,
    guardarCodigoRecuperacionRepository,
    actualizarContrasenaYLimpiarCodigoRepository
} from '../repositories/usuarios.repository.js';
import { enviarCorreoRecuperacion } from './mailer.service.js';
import { jwtConfig } from '../config/jwt.config.js';

const DURACION_CODIGO_MINUTOS = 15;

export const validarFortalezaContrasena = (contrasena) => {
    const errores = [];
    if (contrasena.length < 8) errores.push('mínimo 8 caracteres');
    if (!/[A-Z]/.test(contrasena)) errores.push('una mayúscula');
    if (!/[a-z]/.test(contrasena)) errores.push('una minúscula');
    if (!/\d/.test(contrasena)) errores.push('un número');
    if (!/[^A-Za-z0-9]/.test(contrasena)) errores.push('un carácter especial');
    if (errores.length > 0) {
        throw new Error(`La contraseña debe tener: ${errores.join(', ')}`);
    }
};

export const hashearContrasena = async(contrasena) => {
    const salt = await bcrypt.genSalt(10);
    return await bcrypt.hash(contrasena, salt);
};

export const compararContrasena = async(contrasena, hash) => {
    return await bcrypt.compare(contrasena, hash);
};

export const generarToken = (usuario) => {
    return jwt.sign({
        id_usuario: usuario.id_usuario,
        rol: usuario.rol,
        id_capilla: usuario.id_capilla,
        correo: usuario.correo
    }, jwtConfig.secret, { expiresIn: jwtConfig.expiresIn });
};

/**
 * Devuelve un resultado discriminado (en vez de null) para que el controlador pueda
 * distinguir "credenciales incorrectas" de "credenciales correctas pero cuenta inactiva"
 * — solo en ese segundo caso tiene sentido avisarle al Sacerdote, y solo cuando la
 * contraseña era realmente la correcta (para no generar una notificación con solo
 * adivinar el correo de alguien).
 */
export const loginService = async(correo, contrasena) => {
    const usuario = await obtenerUsuarioPorCorreoRepository(correo);

    if (!usuario) {
        return { ok: false };
    }

    const contrasenaValida = await compararContrasena(contrasena, usuario.contrasena_hash);

    if (!contrasenaValida) {
        return { ok: false };
    }

    if (!usuario.activo) {
        return { ok: false, inactivo: true, usuario };
    }

    const token = generarToken(usuario);

    delete usuario.contrasena_hash;
    delete usuario.codigo_recuperacion_hash;
    delete usuario.codigo_recuperacion_expira;

    return { ok: true, usuario, token };
};

const generarCodigoRecuperacion = () => {
    return String(Math.floor(100000 + Math.random() * 900000));
};

export const solicitarRecuperacionService = async(correo) => {
    const usuario = await obtenerUsuarioPorCorreoRepository(correo);

    if (!usuario || !usuario.activo) {
        return;
    }

    const codigo = generarCodigoRecuperacion();
    const codigoHash = await hashearContrasena(codigo);
    const expira = new Date(Date.now() + DURACION_CODIGO_MINUTOS * 60 * 1000);

    await guardarCodigoRecuperacionRepository(usuario.id_usuario, codigoHash, expira);
    await enviarCorreoRecuperacion(correo, codigo);
};

export const restablecerContrasenaService = async(correo, codigo, contrasenaNueva) => {
    const usuario = await obtenerUsuarioPorCorreoRepository(correo);

    if (!usuario || !usuario.codigo_recuperacion_hash || !usuario.codigo_recuperacion_expira) {
        return false;
    }

    if (new Date(usuario.codigo_recuperacion_expira) < new Date()) {
        return false;
    }

    const codigoValido = await compararContrasena(codigo, usuario.codigo_recuperacion_hash);

    if (!codigoValido) {
        return false;
    }

    const contrasenaHash = await hashearContrasena(contrasenaNueva);
    await actualizarContrasenaYLimpiarCodigoRepository(usuario.id_usuario, contrasenaHash);

    return true;
};
