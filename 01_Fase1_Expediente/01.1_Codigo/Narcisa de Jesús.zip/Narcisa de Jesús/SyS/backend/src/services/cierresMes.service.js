import {
    obtenerCierresRepository,
    obtenerCierresPorAlcanceRepository,
    obtenerCierrePorIdRepository,
    obtenerCierrePorMesAnioRepository,
    calcularTotalesMesRepository,
    crearCierreRepository,
    eliminarCierreRepository
} from '../repositories/cierresMes.repository.js';

export const obtenerCierresService = async(usuario) => {
    if (usuario.rol === 'Tesorero') {
        return await obtenerCierresPorAlcanceRepository(usuario.id_capilla ?? null);
    }

    return await obtenerCierresRepository();
};

export const obtenerCierrePorIdService = async(id) => {
    return await obtenerCierrePorIdRepository(id);
};

/**
 * El cierre de la PARROQUIA (todos los fondos) solo lo genera el tesorero general
 * (sin capilla asignada). Un tesorero de capilla solo puede generar el cierre del
 * fondo de su propia capilla, nunca el de toda la parroquia — por eso el alcance
 * se deriva siempre del usuario autenticado, no de la petición.
 */
export const crearCierreService = async(datos, usuario) => {
    const hoy = new Date();
    const mesActual = hoy.getMonth() + 1;
    const anioActual = hoy.getFullYear();
    const mes = Number(datos.mes);
    const anio = Number(datos.anio);

    if (anio > anioActual || (anio === anioActual && mes >= mesActual)) {
        throw new Error('No se puede cerrar un mes que todavía está en curso o que no ha comenzado.');
    }

    const idCapilla = usuario.rol === 'Tesorero' ? (usuario.id_capilla ?? null) : null;

    const existente = await obtenerCierrePorMesAnioRepository(mes, anio, idCapilla);

    if (existente) {
        throw new Error(`Ya existe un cierre registrado para ${mes}/${anio}`);
    }

    const totales = await calcularTotalesMesRepository(mes, anio, idCapilla);

    return await crearCierreRepository({
        mes,
        anio,
        total_ingresos: totales.total_ingresos,
        total_egresos: totales.total_egresos,
        generado_por: usuario.id_usuario,
        id_capilla: idCapilla
    });
};

export const eliminarCierreService = async(id) => {
    return await eliminarCierreRepository(id);
};
