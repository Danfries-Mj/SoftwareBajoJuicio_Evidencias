import {
    obtenerBeneficiariosPorSolicitudRepository,
    obtenerBeneficiarioPorIdRepository,
    crearBeneficiarioRepository,
    eliminarBeneficiarioRepository
} from '../repositories/beneficiariosSolicitud.repository.js';
import {
    obtenerSolicitudPorIdRepository,
    existeSolicitudAtendidaPorCedulaRepository
} from '../repositories/solicitudesSacramento.repository.js';
import { obtenerCertificadoPrerequisitoRepository } from '../repositories/certificados.repository.js';
import { TIPO_CERTIFICADO_POR_SACRAMENTO } from './solicitudesSacramento.service.js';

export const obtenerBeneficiariosPorSolicitudService = async(idSolicitud) => {
    return await obtenerBeneficiariosPorSolicitudRepository(idSolicitud);
};

export const obtenerBeneficiarioPorIdService = async(id) => {
    return await obtenerBeneficiarioPorIdRepository(id);
};

export const crearBeneficiarioService = async(datos) => {
    const solicitud = datos.cedula || datos.id_persona
        ? await obtenerSolicitudPorIdRepository(datos.id_solicitud)
        : null;

    // No se debe permitir una nueva solicitud del mismo sacramento para una cédula que ya
    // tiene una solicitud 'Atendida' vigente. Se levanta si esa solicitud se rechaza o se
    // elimina (deja de cumplir la condición estado='Atendida').
    if (datos.cedula && solicitud) {
        const yaAtendida = await existeSolicitudAtendidaPorCedulaRepository(datos.cedula, solicitud.sacramento);
        if (yaAtendida) {
            throw new Error(`Ya existe una solicitud de ${solicitud.sacramento} aceptada para la cédula ${datos.cedula}. No se puede enviar otra mientras siga vigente.`);
        }
    }

    // Tampoco tiene sentido si el beneficiario (esté o no ligado a una cuenta) ya tiene
    // el certificado de ese sacramento emitido: ya lo recibió, no hay nada que tramitar.
    if (datos.id_persona && solicitud) {
        const tipoCertificado = TIPO_CERTIFICADO_POR_SACRAMENTO[solicitud.sacramento];
        if (tipoCertificado) {
            const yaEmitido = await obtenerCertificadoPrerequisitoRepository(datos.id_persona, tipoCertificado);
            if (yaEmitido) {
                throw new Error(`Esta persona ya tiene el certificado de ${tipoCertificado} emitido. No se puede volver a solicitar este sacramento para ella.`);
            }
        }
    }

    return await crearBeneficiarioRepository({
        id_solicitud: datos.id_solicitud,
        rol_beneficiario: datos.rol_beneficiario,
        nombres: datos.nombres,
        apellidos: datos.apellidos,
        cedula: datos.cedula,
        id_persona: datos.id_persona
    });
};

export const eliminarBeneficiarioService = async(id) => {
    return await eliminarBeneficiarioRepository(id);
};
