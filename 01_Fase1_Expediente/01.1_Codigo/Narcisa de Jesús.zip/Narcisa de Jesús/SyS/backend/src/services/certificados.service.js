import {
    obtenerCertificadosRepository,
    obtenerCertificadoPorIdRepository,
    obtenerCertificadoPrerequisitoRepository,
    crearCertificadoRepository,
    emitirCertificadoRepository,
    rechazarCertificadoRepository,
    eliminarCertificadoRepository
} from '../repositories/certificados.repository.js';
import { generarCertificadoPdfDataUri } from './certificadoPdf.service.js';

const TIPOS_VALIDOS = ['Bautismo', 'Primera Comunion', 'Confirmacion'];

const PRERREQUISITO_MAPA = {
    'Bautismo': null,
    'Primera Comunion': 'Bautismo',
    'Confirmacion': 'Primera Comunion'
};

export const obtenerCertificadosService = async(filtros) => {
    return await obtenerCertificadosRepository(filtros);
};

export const obtenerCertificadoPorIdService = async(id) => {
    return await obtenerCertificadoPorIdRepository(id);
};

// Comprueba si una persona tiene Emitido un certificado de ese tipo exacto (el tipo que se
// pasa YA es el prerrequisito en cuestión, p. ej. 'Bautismo' al inscribir a Primera Comunión;
// no se vuelve a mapear a otro prerrequisito). Solo expone un booleano y la fecha de emisión
// -nunca el archivo ni otros datos del certificado- porque un Laico puede consultar el
// prerrequisito de un tercero que está inscribiendo (no solo el suyo propio).
export const verificarPrerequisitoCertificadoService = async(id_persona, tipo) => {
    if (!TIPOS_VALIDOS.includes(tipo)) {
        throw new Error(`Tipo inválido. Tipos permitidos: ${TIPOS_VALIDOS.join(', ')}`);
    }

    const certificado = await obtenerCertificadoPrerequisitoRepository(id_persona, tipo);

    return {
        cumple: Boolean(certificado),
        fecha_emision: certificado ? certificado.fecha_emision : null
    };
};

export const crearCertificadoService = async(datos) => {
    if (!TIPOS_VALIDOS.includes(datos.tipo)) {
        throw new Error(`Tipo inválido. Tipos permitidos: ${TIPOS_VALIDOS.join(', ')}`);
    }

    // No se debe permitir subir un certificado de un tipo que la persona ya tiene
    // registrado (independiente por tipo de certificado).
    const existentes = await obtenerCertificadosRepository({ id_persona: datos.id_persona, tipo: datos.tipo });
    if (existentes.length > 0) {
        throw new Error(`Ya existe un certificado de ${datos.tipo} registrado para esta persona.`);
    }

    const prerequisito = PRERREQUISITO_MAPA[datos.tipo];
    if (prerequisito) {
        const emitido = await obtenerCertificadoPrerequisitoRepository(datos.id_persona, prerequisito);
        if (!emitido) {
            throw new Error(`No cumple con el prerrequisito. Necesita el certificado de ${prerequisito} emitido.`);
        }
    }

    // Un certificado autosubido por el Laico (con archivo adjunto, sin revisar) nunca debe
    // quedar "Emitido" solo por traer un archivo: eso permitía inscribirse a un nivel de
    // catequesis superior sin que el Sacerdote lo haya validado. Solo cuando lo genera el
    // propio Sacerdote (esCreadoPorSacerdote) el archivo adjunto se considera ya validado.
    const tieneArchivo = Boolean(datos.archivo_url);
    const estadoFinal = datos.estado || (datos.esCreadoPorSacerdote && tieneArchivo ? 'Emitido' : 'Pendiente');
    const fechaEmision = (estadoFinal === 'Emitido' && !datos.fecha_emision)
        ? new Date().toISOString().slice(0, 10)
        : datos.fecha_emision;

    return await crearCertificadoRepository({
        id_persona: datos.id_persona,
        tipo: datos.tipo,
        id_capilla: datos.id_capilla,
        archivo_nombre: datos.archivo_nombre,
        archivo_url: datos.archivo_url,
        mime_type: datos.mime_type,
        estado: estadoFinal,
        fecha_emision: fechaEmision
    });
};

export const emitirCertificadoService = async(id, datos) => {
    let { fecha_emision, archivo_url, archivo_nombre, mime_type } = datos;

    // Si no se adjunta un archivo manualmente, se genera el PDF del certificado con
    // el diseño oficial de la parroquia (mismo layout para Bautismo/Primera Comunión/
    // Confirmación/Matrimonio, solo cambia el texto del sacramento y los datos).
    if (!archivo_url) {
        const certificado = await obtenerCertificadoPorIdRepository(id);
        if (!certificado) return null;

        const nombreCompleto = `${certificado.solicitante_nombres ?? ''} ${certificado.solicitante_apellidos ?? ''}`.trim();

        archivo_url = await generarCertificadoPdfDataUri({
            tipo: certificado.tipo,
            nombreCompleto: nombreCompleto || 'Sin nombre registrado',
            capillaNombre: certificado.capilla_nombre ?? 'la parroquia',
            fechaEmision: fecha_emision,
            parrocoNombre: datos.parrocoNombre ?? 'Sacerdote'
        });
        archivo_nombre = `certificado-${certificado.tipo.toLowerCase().replace(/\s+/g, '-')}-${id}.pdf`;
        mime_type = 'application/pdf';
    }

    return await emitirCertificadoRepository(id, { fecha_emision, archivo_url, archivo_nombre, mime_type });
};

export const rechazarCertificadoService = async(id) => {
    const certificado = await obtenerCertificadoPorIdRepository(id);
    if (!certificado) return null;

    if (certificado.estado === 'Emitido') {
        throw new Error('No se puede rechazar un certificado que ya fue emitido.');
    }

    return await rechazarCertificadoRepository(id);
};

export const eliminarCertificadoService = async(id) => {
    return await eliminarCertificadoRepository(id);
};
