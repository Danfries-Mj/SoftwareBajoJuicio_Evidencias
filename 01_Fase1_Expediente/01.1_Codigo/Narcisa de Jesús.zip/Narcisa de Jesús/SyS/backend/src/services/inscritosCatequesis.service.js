import {
    obtenerInscritosRepository,
    obtenerInscritoPorIdRepository,
    obtenerInscritoPendientePorCedulaRepository,
    crearInscritoRepository,
    actualizarInscritoRepository,
    eliminarInscritoRepository
} from '../repositories/inscritosCatequesis.repository.js';
import { obtenerPersonaPorCedulaRepository } from '../repositories/personas.repository.js';
import { obtenerCertificadoPrerequisitoRepository } from '../repositories/certificados.repository.js';
import { crearHistorialInscritoService } from './historialInscrito.service.js';

const NIVELES_VALIDOS = ['Primera Comunion', 'Confirmacion'];

const CERTIFICADOS_REQUERIDOS = {
    'Primera Comunion': ['Bautismo'],
    'Confirmacion': ['Bautismo', 'Primera Comunion']
};

// Se valida por persona (no por cuenta de usuario): un tercero inscrito sin cuenta
// registrada igual puede tener certificados propios asociados a su id_persona.
const validarCertificadosPrevios = async(cedula, nivel) => {
    const requeridos = CERTIFICADOS_REQUERIDOS[nivel];
    if (!requeridos) {
        return;
    }

    const persona = await obtenerPersonaPorCedulaRepository(cedula);
    if (!persona) {
        throw new Error('Falta certificados pendientes de subir');
    }

    for (const tipo of requeridos) {
        const certificado = await obtenerCertificadoPrerequisitoRepository(persona.id_persona, tipo);
        if (!certificado) {
            throw new Error('Falta certificados pendientes de subir');
        }
    }
};

/**
 * No tiene sentido inscribir (ni siquiera como Pendiente) a alguien que ya tiene el
 * certificado de ese mismo nivel emitido: ya lo completó. Igual que en el autoservicio
 * del Laico, pero aquí lo puede disparar Catequista, Coordinador o Sacerdote, que son
 * quienes inscriben directamente (con o sin cuenta de usuario del inscrito).
 */
const validarSinCertificadoDelNivel = async(cedula, nivel) => {
    const persona = await obtenerPersonaPorCedulaRepository(cedula);
    if (!persona) return;

    const certificado = await obtenerCertificadoPrerequisitoRepository(persona.id_persona, nivel);
    if (certificado) {
        throw new Error(`Esta persona ya tiene el certificado de ${nivel} emitido. No se puede volver a inscribir en este nivel.`);
    }
};

export const obtenerInscritosService = async(filtros) => {
    return await obtenerInscritosRepository(filtros);
};

export const obtenerInscritoPorIdService = async(id) => {
    return await obtenerInscritoPorIdRepository(id);
};

export const crearInscritoService = async(datos) => {
    if (!NIVELES_VALIDOS.includes(datos.nivel)) {
        throw new Error(`Nivel inválido. Niveles permitidos: ${NIVELES_VALIDOS.join(', ')}`);
    }

    // Sin importar el estado con el que nazca (ni siquiera Pendiente): si ya tiene el
    // certificado de este nivel, no hay nada que inscribir.
    await validarSinCertificadoDelNivel(datos.cedula, datos.nivel);

    // El certificado prerrequisito solo se exige cuando el inscrito nace directamente
    // Activo. Si se crea como Pendiente a propósito (el certificado todavía no lo valida
    // el Sacerdote), se permite: cuando el Sacerdote apruebe o rechace ese certificado,
    // este inscrito se promueve a Activo o se elimina automáticamente (ver
    // certificados.controller.js).
    const estadoFinal = datos.estado || 'Pendiente';
    if (estadoFinal === 'Activo') {
        await validarCertificadosPrevios(datos.cedula, datos.nivel);
    }

    return await crearInscritoRepository({
        id_inscripcion: datos.id_inscripcion || null,
        cedula: datos.cedula,
        nombres: datos.nombres,
        nivel: datos.nivel,
        id_capilla: datos.id_capilla,
        id_catequista: datos.id_catequista || null,
        fecha_inscripcion: datos.fecha_inscripcion,
        monto: datos.monto || 5.00,
        comprobante: datos.comprobante,
        estado: estadoFinal
    });
};

export const obtenerInscritoPendientePorCedulaService = async(cedula, nivel) => {
    return await obtenerInscritoPendientePorCedulaRepository(cedula, nivel);
};

/**
 * Un inscrito Finalizado que ya tiene su certificado de catequesis Emitido es un
 * registro cerrado: no tiene sentido editarlo ni eliminarlo (el certificado ya salió
 * a su nombre con esos datos). Se valida por persona (vía cédula), igual que el resto
 * de las validaciones de certificado de este archivo.
 */
const validarNoFinalizadoConCertificado = async(inscrito) => {
    if (inscrito.estado !== 'Finalizado') return;

    const persona = await obtenerPersonaPorCedulaRepository(inscrito.cedula);
    if (!persona) return;

    const certificado = await obtenerCertificadoPrerequisitoRepository(persona.id_persona, inscrito.nivel);
    if (certificado) {
        throw new Error('Este inscrito ya está Finalizado con el certificado emitido: no se puede editar ni eliminar.');
    }
};

export const actualizarInscritoService = async(id, datos) => {
    const inscritoActual = await obtenerInscritoPorIdRepository(id);

    if (!inscritoActual) {
        return null;
    }

    await validarNoFinalizadoConCertificado(inscritoActual);

    const actualizado = await actualizarInscritoRepository(id, {
        id_catequista: datos.id_catequista || null,
        estado: datos.estado
    });

    if (inscritoActual.estado !== datos.estado) {
        await crearHistorialInscritoService({
            id_inscrito: id,
            comprobante: inscritoActual.comprobante,
            estado_anterior: inscritoActual.estado,
            estado_nuevo: datos.estado,
            nota: datos.nota || 'Actualización de estado'
        });
    }

    return actualizado;
};

export const eliminarInscritoService = async(id) => {
    const inscrito = await obtenerInscritoPorIdRepository(id);
    if (!inscrito) return null;

    await validarNoFinalizadoConCertificado(inscrito);

    return await eliminarInscritoRepository(id);
};
