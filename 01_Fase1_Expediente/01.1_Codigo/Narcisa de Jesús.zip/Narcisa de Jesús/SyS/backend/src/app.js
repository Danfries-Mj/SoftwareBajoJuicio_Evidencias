import 'dotenv/config';
import express from 'express';
import cors from 'cors';
import authRoutes from './routes/auth.routes.js';
import personasRoutes from './routes/personas.routes.js';
import usuariosRoutes from './routes/usuarios.routes.js';
import capillasRoutes from './routes/capillas.routes.js';
import eucaristiasRoutes from './routes/eucaristias.routes.js';
import eventosRoutes from './routes/eventos.routes.js';
import actasRoutes from './routes/actas.routes.js';
import inscripcionesCatequesisRoutes from './routes/inscripcionesCatequesis.routes.js';
import inscritosCatequesisRoutes from './routes/inscritosCatequesis.routes.js';
import historialInscritoRoutes from './routes/historialInscrito.routes.js';
import fondosRoutes from './routes/fondos.routes.js';
import movimientosFinancierosRoutes from './routes/movimientosFinancieros.routes.js';
import cierresMesRoutes from './routes/cierresMes.routes.js';
import donacionesRoutes from './routes/donaciones.routes.js';
import solicitudesSacramentoRoutes from './routes/solicitudesSacramento.routes.js';
import beneficiariosSolicitudRoutes from './routes/beneficiariosSolicitud.routes.js';
import intencionesMisaRoutes from './routes/intencionesMisa.routes.js';
import certificadosRoutes from './routes/certificados.routes.js';
import documentosRoutes from './routes/documentos.routes.js';
import comunicadosRoutes, { comunicadosAdminRoutes } from './routes/comunicados.routes.js';
import notificacionesRoutes from './routes/notificaciones.routes.js';
import auditoriaRoutes from './routes/auditoria.routes.js';
import estadisticasRoutes from './routes/estadisticas.routes.js';
import { verificarConexion } from './database/connection.js';

const app = express();
const PORT = process.env.PORT || 3000;

app.use(cors());
app.use(express.json({ limit: '10mb' }));

app.get('/', (req, res) => {
    res.json({
        mensaje: 'API REST del Sistema de Gestión Parroquial - Parroquia Nuestra Señora de Guadalupe',
        arquitectura: 'routes, controllers, services, repositories, database'
    });
});

app.use('/api/auth', authRoutes);
app.use('/api/personas', personasRoutes);
app.use('/api/usuarios', usuariosRoutes);
app.use('/api/capillas', capillasRoutes);
app.use('/api/eucaristias', eucaristiasRoutes);
app.use('/api/eventos', eventosRoutes);
app.use('/api/actas', actasRoutes);
app.use('/api/inscripciones-catequesis', inscripcionesCatequesisRoutes);
app.use('/api/inscritos-catequesis', inscritosCatequesisRoutes);
app.use('/api/historial-inscrito', historialInscritoRoutes);
app.use('/api/fondos', fondosRoutes);
app.use('/api/movimientos-financieros', movimientosFinancierosRoutes);
app.use('/api/cierres-mes', cierresMesRoutes);
app.use('/api/donaciones', donacionesRoutes);
app.use('/api/solicitudes-sacramento', solicitudesSacramentoRoutes);
app.use('/api/beneficiarios-solicitud', beneficiariosSolicitudRoutes);
app.use('/api/intenciones-misa', intencionesMisaRoutes);
app.use('/api/certificados', certificadosRoutes);
app.use('/api/documentos', documentosRoutes);
app.use('/api/comunicados', comunicadosRoutes);
app.use('/api/admin/comunicados', comunicadosAdminRoutes);
app.use('/api/notificaciones', notificacionesRoutes);
app.use('/api/auditoria', auditoriaRoutes);
app.use('/api/estadisticas', estadisticasRoutes);

app.listen(PORT, async() => {
    console.log(`Servidor ejecutándose en http://localhost:${PORT}`);
    await verificarConexion();
});
