import {
    obtenerAuditoriaService,
    obtenerAuditoriaPorIdService
} from '../services/auditoria.service.js';

export const listarAuditoria = async(req, res) => {
    try {
        const { tabla_afectada, id_usuario } = req.query;

        const auditoria = await obtenerAuditoriaService({ tabla_afectada, id_usuario });

        res.json({
            mensaje: 'Listado de auditoría',
            total: auditoria.length,
            auditoria
        });
    } catch (error) {
        res.status(500).json({
            mensaje: 'Error al listar auditoría',
            error: error.message
        });
    }
};

export const buscarAuditoriaPorId = async(req, res) => {
    try {
        const id = Number(req.params.id);

        const registro = await obtenerAuditoriaPorIdService(id);

        if (!registro) {
            return res.status(404).json({
                mensaje: 'Registro de auditoría no encontrado'
            });
        }

        res.json({
            mensaje: 'Registro de auditoría encontrado',
            registro
        });
    } catch (error) {
        res.status(500).json({
            mensaje: 'Error al buscar registro de auditoría',
            error: error.message
        });
    }
};
