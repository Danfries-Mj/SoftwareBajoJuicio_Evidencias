import {
    obtenerIntencionesService,
    obtenerIntencionPorIdService,
    crearIntencionService,
    asignarIntencionService,
    rechazarIntencionService,
    eliminarIntencionService
} from '../services/intencionesMisa.service.js';
import { crearNotificacionService } from '../services/notificaciones.service.js';
import { obtenerEucaristiaPorIdService } from '../services/eucaristias.service.js';

// El campo "fecha" de eucaristías es un DATE de Postgres, que pg devuelve como
// Date a medianoche UTC; se formatea con timeZone 'UTC' para no correr el día
// hacia atrás en zonas horarias negativas (p. ej. Ecuador, GMT-5).
const formatearFechaEucaristia = (fecha) => {
    const formateada = new Intl.DateTimeFormat('es-EC', {
        weekday: 'long', day: 'numeric', month: 'long', timeZone: 'UTC'
    }).format(new Date(fecha));

    return formateada.charAt(0).toUpperCase() + formateada.slice(1);
};

export const listarIntenciones = async(req, res) => {
    try {
        const { estado } = req.query;

        const filtros = { estado };

        if (req.usuario.rol === 'Laico') {
            filtros.id_usuario = req.usuario.id_usuario;
        }

        const intenciones = await obtenerIntencionesService(filtros);

        res.json({
            mensaje: 'Listado de intenciones de misa',
            total: intenciones.length,
            intenciones
        });
    } catch (error) {
        res.status(500).json({
            mensaje: 'Error al listar intenciones de misa',
            error: error.message
        });
    }
};

export const buscarIntencionPorId = async(req, res) => {
    try {
        const id = Number(req.params.id);

        const intencion = await obtenerIntencionPorIdService(id);

        if (!intencion) {
            return res.status(404).json({
                mensaje: 'Intención de misa no encontrada'
            });
        }

        res.json({
            mensaje: 'Intención de misa encontrada',
            intencion
        });
    } catch (error) {
        res.status(500).json({
            mensaje: 'Error al buscar intención de misa',
            error: error.message
        });
    }
};

export const registrarIntencion = async(req, res) => {
    try {
        const { nombre_mencionar, tipo, fecha_deseada, id_eucaristia } = req.body;

        if (!nombre_mencionar || !tipo || !fecha_deseada) {
            return res.status(400).json({
                mensaje: 'Los campos nombre_mencionar, tipo y fecha_deseada son obligatorios'
            });
        }

        const hoy = new Date();
        hoy.setHours(0, 0, 0, 0);
        const fechaDeseada = new Date(fecha_deseada + 'T00:00:00');

        if (fechaDeseada < hoy) {
            return res.status(400).json({
                mensaje: 'La fecha deseada no puede ser anterior a la fecha actual'
            });
        }

        const intencion = await crearIntencionService({
            id_usuario: req.usuario.id_usuario, nombre_mencionar, tipo, fecha_deseada, id_eucaristia
        });

        res.status(201).json({
            mensaje: 'Intención de misa enviada correctamente',
            intencion
        });
    } catch (error) {
        res.status(400).json({
            mensaje: 'Error al registrar intención de misa',
            error: error.message
        });
    }
};

export const asignarIntencion = async(req, res) => {
    try {
        const id = Number(req.params.id);
        const { id_eucaristia } = req.body;

        if (!id_eucaristia) {
            return res.status(400).json({
                mensaje: 'El campo id_eucaristia es obligatorio'
            });
        }

        const intencionAnterior = await obtenerIntencionPorIdService(id);
        const esEdicion = Boolean(intencionAnterior?.id_eucaristia);

        const intencion = await asignarIntencionService(id, id_eucaristia);

        if (!intencion) {
            return res.status(404).json({
                mensaje: 'Intención de misa no encontrada'
            });
        }

        const eucaristia = await obtenerEucaristiaPorIdService(id_eucaristia);
        const detalleEucaristia = eucaristia
            ? ` Se celebrará el ${formatearFechaEucaristia(eucaristia.fecha)} en ${eucaristia.capilla_nombre ?? 'la parroquia'}.`
            : '';

        await crearNotificacionService(
            intencion.id_usuario,
            esEdicion ? 'Intención de misa reasignada' : 'Intención de misa asignada',
            esEdicion
                ? `El sacerdote cambió la misa asignada a tu intención "${intencion.nombre_mencionar}" (${intencion.tipo}).${detalleEucaristia}`
                : `Tu intención de misa "${intencion.nombre_mencionar}" (${intencion.tipo}) fue asignada por el sacerdote.${detalleEucaristia}`
        );

        res.json({
            mensaje: 'Intención de misa asignada correctamente',
            intencion
        });
    } catch (error) {
        res.status(500).json({
            mensaje: 'Error al asignar intención de misa',
            error: error.message
        });
    }
};

export const rechazarIntencion = async(req, res) => {
    try {
        const id = Number(req.params.id);

        const intencion = await rechazarIntencionService(id);

        if (!intencion) {
            return res.status(404).json({
                mensaje: 'Intención de misa no encontrada'
            });
        }

        await crearNotificacionService(
            intencion.id_usuario,
            'Intención de misa rechazada',
            `Tu intención de misa "${intencion.nombre_mencionar}" (${intencion.tipo}) fue rechazada por el sacerdote.`
        );

        res.json({
            mensaje: 'Intención de misa rechazada correctamente',
            intencion
        });
    } catch (error) {
        res.status(500).json({
            mensaje: 'Error al rechazar intención de misa',
            error: error.message
        });
    }
};

export const borrarIntencion = async(req, res) => {
    try {
        const id = Number(req.params.id);

        const intencion = await eliminarIntencionService(id);

        if (!intencion) {
            return res.status(404).json({
                mensaje: 'Intención de misa no encontrada'
            });
        }

        res.json({
            mensaje: 'Intención de misa eliminada correctamente',
            intencion
        });
    } catch (error) {
        res.status(500).json({
            mensaje: 'Error al eliminar intención de misa',
            error: error.message
        });
    }
};
