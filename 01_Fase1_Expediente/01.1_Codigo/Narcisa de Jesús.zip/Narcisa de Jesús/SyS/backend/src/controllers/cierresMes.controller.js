import {
    obtenerCierresService,
    obtenerCierrePorIdService,
    crearCierreService,
    eliminarCierreService
} from '../services/cierresMes.service.js';

export const listarCierres = async(req, res) => {
    try {
        const cierres = await obtenerCierresService(req.usuario);

        res.json({
            mensaje: 'Listado de cierres mensuales',
            total: cierres.length,
            cierres
        });
    } catch (error) {
        res.status(500).json({
            mensaje: 'Error al listar cierres mensuales',
            error: error.message
        });
    }
};

export const buscarCierrePorId = async(req, res) => {
    try {
        const id = Number(req.params.id);

        const cierre = await obtenerCierrePorIdService(id);

        if (!cierre) {
            return res.status(404).json({
                mensaje: 'Cierre mensual no encontrado'
            });
        }

        res.json({
            mensaje: 'Cierre mensual encontrado',
            cierre
        });
    } catch (error) {
        res.status(500).json({
            mensaje: 'Error al buscar cierre mensual',
            error: error.message
        });
    }
};

export const registrarCierre = async(req, res) => {
    try {
        const { mes, anio } = req.body;

        if (!mes || !anio) {
            return res.status(400).json({
                mensaje: 'Los campos mes y anio son obligatorios'
            });
        }

        const cierre = await crearCierreService({ mes, anio }, req.usuario);

        res.status(201).json({
            mensaje: 'Cierre mensual generado correctamente',
            cierre
        });
    } catch (error) {
        res.status(409).json({
            mensaje: 'Error al generar cierre mensual',
            error: error.message
        });
    }
};

export const borrarCierre = async(req, res) => {
    try {
        const id = Number(req.params.id);

        const cierre = await eliminarCierreService(id);

        if (!cierre) {
            return res.status(404).json({
                mensaje: 'Cierre mensual no encontrado'
            });
        }

        res.json({
            mensaje: 'Cierre mensual eliminado correctamente',
            cierre
        });
    } catch (error) {
        res.status(500).json({
            mensaje: 'Error al eliminar cierre mensual',
            error: error.message
        });
    }
};
