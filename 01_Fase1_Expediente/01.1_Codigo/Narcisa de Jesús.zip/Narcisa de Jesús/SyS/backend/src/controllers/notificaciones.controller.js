import {
    listarNotificacionesService,
    crearNotificacionService,
    marcarLeidaService,
    marcarTodasLeidasService,
    enviarNotificacionMiembrosService
} from '../services/notificaciones.service.js';

export const listarNotificaciones = async(req, res) => {
    try {
        const soloPendientes = req.query.solo_pendientes === 'true';
        const resultado = await listarNotificacionesService(req.usuario.id_usuario, soloPendientes);

        res.json({
            mensaje: 'Notificaciones obtenidas correctamente',
            ...resultado
        });
    } catch (error) {
        res.status(500).json({
            mensaje: 'Error al obtener notificaciones',
            error: error.message
        });
    }
};

export const marcarLeida = async(req, res) => {
    try {
        const id = Number(req.params.id);
        const notificacion = await marcarLeidaService(id, req.usuario.id_usuario);

        res.json({
            mensaje: 'Notificación marcada como leída',
            notificacion
        });
    } catch (error) {
        const status = error.message === 'Notificación no encontrada' ? 404 : 500;
        res.status(status).json({
            mensaje: error.message,
            error: error.message
        });
    }
};

export const enviarNotificacionMiembros = async(req, res) => {
    try {
        const { id_usuario, titulo, mensaje } = req.body;
        const enviadas = await enviarNotificacionMiembrosService(req.usuario, { id_usuario, titulo, mensaje });

        res.status(201).json({
            mensaje: 'Notificación enviada correctamente',
            enviadas
        });
    } catch (error) {
        res.status(400).json({
            mensaje: error.message,
            error: error.message
        });
    }
};

export const marcarTodasLeidas = async(req, res) => {
    try {
        const marcadas = await marcarTodasLeidasService(req.usuario.id_usuario);

        res.json({
            mensaje: 'Todas las notificaciones fueron marcadas como leídas',
            marcadas: marcadas.length
        });
    } catch (error) {
        res.status(500).json({
            mensaje: 'Error al marcar notificaciones como leídas',
            error: error.message
        });
    }
};
