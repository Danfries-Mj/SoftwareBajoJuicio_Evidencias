import {
    obtenerInscripcionesService,
    obtenerInscripcionPorIdService,
    crearInscripcionService,
    aprobarInscripcionService,
    rechazarInscripcionService,
    eliminarInscripcionService
} from '../services/inscripcionesCatequesis.service.js';
import { crearNotificacionService } from '../services/notificaciones.service.js';

export const listarInscripciones = async(req, res) => {
    try {
        const { id_capilla, nivel, estado } = req.query;

        const filtros = { id_capilla, nivel, estado };

        if (req.usuario.rol === 'Laico') {
            filtros.id_laico = req.usuario.id_usuario;
        } else if (['Catequista', 'Coordinador'].includes(req.usuario.rol)) {
            filtros.id_capilla = req.usuario.id_capilla;
        }

        const inscripciones = await obtenerInscripcionesService(filtros);

        res.json({
            mensaje: 'Listado de solicitudes de inscripción a catequesis',
            total: inscripciones.length,
            inscripciones
        });
    } catch (error) {
        res.status(500).json({
            mensaje: 'Error al listar solicitudes de inscripción',
            error: error.message
        });
    }
};

export const buscarInscripcionPorId = async(req, res) => {
    try {
        const id = Number(req.params.id);

        const inscripcion = await obtenerInscripcionPorIdService(id);

        if (!inscripcion) {
            return res.status(404).json({
                mensaje: 'Solicitud de inscripción no encontrada'
            });
        }

        res.json({
            mensaje: 'Solicitud de inscripción encontrada',
            inscripcion
        });
    } catch (error) {
        res.status(500).json({
            mensaje: 'Error al buscar solicitud de inscripción',
            error: error.message
        });
    }
};

export const registrarInscripcion = async(req, res) => {
    try {
        const { nivel, id_capilla, monto, id_documento, id_laico } = req.body;

        if (!nivel || !id_capilla) {
            return res.status(400).json({
                mensaje: 'Los campos nivel e id_capilla son obligatorios'
            });
        }

        if (!id_documento) {
            return res.status(400).json({
                mensaje: 'La foto del comprobante es obligatoria'
            });
        }

        // Un Laico solo puede registrar su propia solicitud; un Catequista/Coordinador/
        // Sacerdote la registra a nombre de la persona que inscribe (id_laico en el body).
        const idLaico = req.usuario.rol === 'Laico' ? req.usuario.id_usuario : id_laico;

        if (!idLaico) {
            return res.status(400).json({
                mensaje: 'El campo id_laico es obligatorio cuando la solicitud la registra personal de la parroquia'
            });
        }

        const inscripcion = await crearInscripcionService({
            id_laico: idLaico, nivel, id_capilla, monto, id_documento
        });

        res.status(201).json({
            mensaje: 'Solicitud de inscripción enviada correctamente, queda pendiente de validación',
            inscripcion
        });
    } catch (error) {
        res.status(400).json({
            mensaje: error.message,
            error: error.message
        });
    }
};

export const aprobarInscripcion = async(req, res) => {
    try {
        const id = Number(req.params.id);

        const inscripcion = await aprobarInscripcionService(id, req.usuario.id_usuario);

        if (!inscripcion) {
            return res.status(404).json({
                mensaje: 'Solicitud de inscripción no encontrada'
            });
        }

        await crearNotificacionService(
            inscripcion.id_laico,
            'Inscripción de catequesis aprobada',
            `Tu inscripción a ${inscripcion.nivel} fue aprobada por el catequista.`
        );

        res.json({
            mensaje: 'Solicitud de inscripción aprobada correctamente',
            inscripcion
        });
    } catch (error) {
        res.status(500).json({
            mensaje: 'Error al aprobar solicitud de inscripción',
            error: error.message
        });
    }
};

export const rechazarInscripcion = async(req, res) => {
    try {
        const id = Number(req.params.id);

        const inscripcion = await rechazarInscripcionService(id, req.usuario.id_usuario);

        if (!inscripcion) {
            return res.status(404).json({
                mensaje: 'Solicitud de inscripción no encontrada'
            });
        }

        await crearNotificacionService(
            inscripcion.id_laico,
            'Inscripción de catequesis rechazada',
            `Tu inscripción a ${inscripcion.nivel} fue rechazada por el catequista.`
        );

        res.json({
            mensaje: 'Solicitud de inscripción rechazada correctamente',
            inscripcion
        });
    } catch (error) {
        res.status(500).json({
            mensaje: 'Error al rechazar solicitud de inscripción',
            error: error.message
        });
    }
};

export const borrarInscripcion = async(req, res) => {
    try {
        const id = Number(req.params.id);

        const inscripcion = await eliminarInscripcionService(id);

        if (!inscripcion) {
            return res.status(404).json({
                mensaje: 'Solicitud de inscripción no encontrada'
            });
        }

        res.json({
            mensaje: 'Solicitud de inscripción eliminada correctamente',
            inscripcion
        });
    } catch (error) {
        res.status(500).json({
            mensaje: 'Error al eliminar solicitud de inscripción',
            error: error.message
        });
    }
};
