import {
    obtenerSolicitudesService,
    obtenerSolicitudPorIdService,
    crearSolicitudService,
    asignarSolicitudService,
    aprobarSolicitudService,
    rechazarSolicitudService,
    eliminarSolicitudService,
    existeSolicitudAtendidaPorCedulaService
} from '../services/solicitudesSacramento.service.js';
import { cedulaValida } from '../utils/validators.js';
import { crearNotificacionService } from '../services/notificaciones.service.js';

// El Sacerdote agenda los sacramentos de evento único (Bautizo/Matrimonio); Primera
// Comunión y Confirmación son catequesis y las gestiona el Catequista de la capilla.
const SACRAMENTOS_SACERDOTE = ['Bautizo', 'Matrimonio'];
const SACRAMENTOS_CATEQUISTA = ['Primera Comunion', 'Confirmacion'];

export const listarSolicitudes = async(req, res) => {
    try {
        const { sacramento, estado } = req.query;

        const filtros = { sacramento, estado };

        if (req.usuario.rol === 'Laico') {
            filtros.id_usuario = req.usuario.id_usuario;
        } else if (req.usuario.rol === 'Sacerdote') {
            filtros.sacramentos = SACRAMENTOS_SACERDOTE;
        } else if (req.usuario.rol === 'Catequista') {
            filtros.sacramentos = SACRAMENTOS_CATEQUISTA;
            filtros.id_capilla = req.usuario.id_capilla;
        }

        const solicitudes = await obtenerSolicitudesService(filtros);

        res.json({
            mensaje: 'Listado de solicitudes de sacramentos',
            total: solicitudes.length,
            solicitudes
        });
    } catch (error) {
        res.status(500).json({
            mensaje: 'Error al listar solicitudes de sacramentos',
            error: error.message
        });
    }
};

export const verificarSolicitudDuplicada = async(req, res) => {
    try {
        const { cedula, sacramento } = req.query;

        if (!cedula || !cedulaValida(cedula)) {
            return res.status(400).json({
                mensaje: 'El parámetro cedula no es válido'
            });
        }

        if (!sacramento) {
            return res.status(400).json({
                mensaje: 'El parámetro sacramento es obligatorio'
            });
        }

        const duplicada = await existeSolicitudAtendidaPorCedulaService(cedula, sacramento);

        res.json({
            mensaje: 'Verificación de solicitud duplicada completada',
            duplicada
        });
    } catch (error) {
        res.status(400).json({
            mensaje: 'Error al verificar solicitud duplicada',
            error: error.message
        });
    }
};

export const buscarSolicitudPorId = async(req, res) => {
    try {
        const id = Number(req.params.id);

        const solicitud = await obtenerSolicitudPorIdService(id);

        if (!solicitud) {
            return res.status(404).json({
                mensaje: 'Solicitud no encontrada'
            });
        }

        res.json({
            mensaje: 'Solicitud encontrada',
            solicitud
        });
    } catch (error) {
        res.status(500).json({
            mensaje: 'Error al buscar solicitud',
            error: error.message
        });
    }
};

export const registrarSolicitud = async(req, res) => {
    try {
        const { sacramento, modalidad, id_capilla, id_documento, beneficiarios } = req.body;

        if (!sacramento) {
            return res.status(400).json({
                mensaje: 'El campo sacramento es obligatorio'
            });
        }

        const cedulaInvalida = (beneficiarios ?? []).find((b) => b.cedula && !cedulaValida(b.cedula));
        if (cedulaInvalida) {
            return res.status(400).json({
                mensaje: 'La cédula ingresada no es válida'
            });
        }

        const solicitud = await crearSolicitudService({
            id_usuario: req.usuario.id_usuario, sacramento, modalidad, id_capilla, id_documento, beneficiarios
        });

        res.status(201).json({
            mensaje: 'Solicitud enviada correctamente, queda pendiente de asignación',
            solicitud
        });
    } catch (error) {
        res.status(400).json({
            mensaje: error.message,
            error: error.message
        });
    }
};

export const asignarSolicitud = async(req, res) => {
    try {
        const id = Number(req.params.id);
        const { fecha_asignada, hora_inicio, hora_fin, id_capilla } = req.body;

        if (!fecha_asignada) {
            return res.status(400).json({
                mensaje: 'El campo fecha_asignada es obligatorio'
            });
        }

        if (!hora_inicio || !hora_fin) {
            return res.status(400).json({
                mensaje: 'Los campos hora_inicio y hora_fin son obligatorios'
            });
        }

        if (hora_inicio >= hora_fin) {
            return res.status(400).json({
                mensaje: 'La hora de inicio debe ser anterior a la hora de fin'
            });
        }

        const hoy = new Date();
        hoy.setHours(0, 0, 0, 0);
        const fechaAsignada = new Date(fecha_asignada + 'T00:00:00');

        if (fechaAsignada < hoy) {
            return res.status(400).json({
                mensaje: 'La fecha asignada no puede ser anterior a la fecha actual'
            });
        }

        const solicitudActual = await obtenerSolicitudPorIdService(id);

        if (solicitudActual?.sacramento === 'Bautizo') {
            const bautizosAtendidos = await obtenerSolicitudesService({ sacramento: 'Bautizo', estado: 'Atendida' });
            const aIso = (f) => (f instanceof Date ? f.toISOString() : String(f)).slice(0, 10);
            const yaHayBautizo = bautizosAtendidos.some((s) =>
                s.id_solicitud !== id && s.fecha_asignada && aIso(s.fecha_asignada) === fecha_asignada
            );

            if (yaHayBautizo) {
                return res.status(400).json({
                    mensaje: 'Ya hay un bautizo agendado para esa fecha. Elige otra fecha.'
                });
            }
        }

        const solicitud = await asignarSolicitudService(id, { fecha_asignada, hora_inicio, hora_fin, id_capilla });

        if (!solicitud) {
            return res.status(404).json({
                mensaje: 'Solicitud no encontrada'
            });
        }

        await crearNotificacionService(
            solicitud.id_usuario,
            `Solicitud de ${solicitud.sacramento} atendida`,
            `Se te asignó fecha: ${fecha_asignada}.`
        );

        res.json({
            mensaje: 'Solicitud asignada correctamente',
            solicitud
        });
    } catch (error) {
        res.status(500).json({
            mensaje: 'Error al asignar solicitud',
            error: error.message
        });
    }
};

export const aprobarSolicitud = async(req, res) => {
    try {
        const id = Number(req.params.id);

        const solicitud = await aprobarSolicitudService(id);

        if (!solicitud) {
            return res.status(404).json({
                mensaje: 'Solicitud no encontrada'
            });
        }

        await crearNotificacionService(
            solicitud.id_usuario,
            `Solicitud de ${solicitud.sacramento} aprobada`,
            `Tu solicitud de ${solicitud.sacramento} fue aprobada. El catequista se pondrá en contacto para la inscripción.`
        );

        res.json({
            mensaje: 'Solicitud aprobada correctamente',
            solicitud
        });
    } catch (error) {
        res.status(400).json({
            mensaje: 'Error al aprobar solicitud',
            error: error.message
        });
    }
};

export const rechazarSolicitud = async(req, res) => {
    try {
        const id = Number(req.params.id);

        const solicitud = await rechazarSolicitudService(id);

        if (!solicitud) {
            return res.status(404).json({
                mensaje: 'Solicitud no encontrada'
            });
        }

        await crearNotificacionService(
            solicitud.id_usuario,
            `Solicitud de ${solicitud.sacramento} rechazada`,
            `Tu solicitud de ${solicitud.sacramento} fue rechazada.`
        );

        res.json({
            mensaje: 'Solicitud rechazada correctamente',
            solicitud
        });
    } catch (error) {
        res.status(500).json({
            mensaje: 'Error al rechazar solicitud',
            error: error.message
        });
    }
};

export const borrarSolicitud = async(req, res) => {
    try {
        const id = Number(req.params.id);

        const solicitud = await eliminarSolicitudService(id);

        if (!solicitud) {
            return res.status(404).json({
                mensaje: 'Solicitud no encontrada'
            });
        }

        res.json({
            mensaje: 'Solicitud eliminada correctamente',
            solicitud
        });
    } catch (error) {
        res.status(500).json({
            mensaje: 'Error al eliminar solicitud',
            error: error.message
        });
    }
};
