import { obtenerEstadisticasPublicasService } from '../services/estadisticas.service.js';

export const listarEstadisticasPublicas = async(req, res) => {
    try {
        const estadisticas = await obtenerEstadisticasPublicasService();

        res.json({
            mensaje: 'Estadísticas públicas obtenidas correctamente',
            estadisticas
        });
    } catch (error) {
        res.status(500).json({
            mensaje: 'Error al obtener estadísticas públicas',
            error: error.message
        });
    }
};
