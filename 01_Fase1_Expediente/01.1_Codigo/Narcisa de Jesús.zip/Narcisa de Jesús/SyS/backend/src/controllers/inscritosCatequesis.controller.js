import {
    obtenerInscritosService,
    obtenerInscritoPorIdService,
    crearInscritoService,
    actualizarInscritoService,
    eliminarInscritoService
} from '../services/inscritosCatequesis.service.js';
import { cedulaValida } from '../utils/validators.js';

export const listarInscritos = async(req, res) => {
    try {
        const { nivel, estado, nombre } = req.query;

        const filtros = { nivel, estado, nombre };

        if (['Catequista', 'Coordinador'].includes(req.usuario.rol)) {
            filtros.id_capilla = req.usuario.id_capilla;
        } else if (req.usuario.rol === 'Tesorero' && req.usuario.id_capilla) {
            // El tesorero de una capilla solo ve los valores de catequesis de su
            // propia capilla; el tesorero general (sin capilla) los ve todos.
            filtros.id_capilla = req.usuario.id_capilla;
        } else if (req.query.id_capilla) {
            filtros.id_capilla = req.query.id_capilla;
        }

        const inscritos = await obtenerInscritosService(filtros);

        res.json({
            mensaje: 'Listado de inscritos en catequesis',
            total: inscritos.length,
            inscritos
        });
    } catch (error) {
        res.status(500).json({
            mensaje: 'Error al listar inscritos en catequesis',
            error: error.message
        });
    }
};

export const buscarInscritoPorId = async(req, res) => {
    try {
        const id = Number(req.params.id);

        const inscrito = await obtenerInscritoPorIdService(id);

        if (!inscrito) {
            return res.status(404).json({
                mensaje: 'Inscrito no encontrado'
            });
        }

        res.json({
            mensaje: 'Inscrito encontrado',
            inscrito
        });
    } catch (error) {
        res.status(500).json({
            mensaje: 'Error al buscar inscrito',
            error: error.message
        });
    }
};

export const registrarInscrito = async(req, res) => {
    try {
        const { cedula, nombres, nivel, id_capilla, id_catequista, fecha_inscripcion, monto, comprobante, id_inscripcion } = req.body;

        if (!cedula || !nombres || !nivel || !id_capilla || !fecha_inscripcion) {
            return res.status(400).json({
                mensaje: 'Los campos cedula, nombres, nivel, id_capilla y fecha_inscripcion son obligatorios'
            });
        }

        if (!cedulaValida(cedula)) {
            return res.status(400).json({
                mensaje: 'La cédula ingresada no es válida'
            });
        }

        const inscrito = await crearInscritoService({
            cedula, nombres, nivel, id_capilla, id_catequista, fecha_inscripcion, monto, comprobante, id_inscripcion
        });

        res.status(201).json({
            mensaje: 'Inscrito registrado correctamente',
            inscrito
        });
    } catch (error) {
        res.status(400).json({
            mensaje: error.message,
            error: error.message
        });
    }
};

export const editarInscrito = async(req, res) => {
    try {
        const id = Number(req.params.id);
        const { id_catequista, estado, nota } = req.body;

        if (!estado) {
            return res.status(400).json({
                mensaje: 'El campo estado es obligatorio'
            });
        }

        const inscrito = await actualizarInscritoService(id, { id_catequista, estado, nota });

        if (!inscrito) {
            return res.status(404).json({
                mensaje: 'Inscrito no encontrado'
            });
        }

        res.json({
            mensaje: 'Inscrito actualizado correctamente',
            inscrito
        });
    } catch (error) {
        res.status(400).json({
            mensaje: error.message,
            error: error.message
        });
    }
};

export const borrarInscrito = async(req, res) => {
    try {
        const id = Number(req.params.id);

        const inscrito = await eliminarInscritoService(id);

        if (!inscrito) {
            return res.status(404).json({
                mensaje: 'Inscrito no encontrado'
            });
        }

        res.json({
            mensaje: 'Inscrito eliminado correctamente',
            inscrito
        });
    } catch (error) {
        res.status(400).json({
            mensaje: error.message,
            error: error.message
        });
    }
};
