import {
    obtenerComunicadosPublicosService,
    obtenerComunicadosService,
    obtenerComunicadoPorIdService,
    crearComunicadoService,
    actualizarComunicadoService,
    eliminarComunicadoService
} from '../services/comunicados.service.js';
import { crearNotificacionService, notificarSacerdoteService } from '../services/notificaciones.service.js';
import { obtenerUsuariosRepository } from '../repositories/usuarios.repository.js';
import { obtenerComunicadoPorIdRepository } from '../repositories/comunicados.repository.js';

/**
 * Notifica un comunicado enviado a todos los Laicos y también al Coordinador de la(s)
 * capilla(s) afectada(s): el Coordinador administra su capilla y necesita enterarse de
 * los avisos igual que sus miembros, no solo revisándolo manualmente. Si quien lo envió
 * fue un Coordinador, también se avisa al Sacerdote (si lo envía el propio Sacerdote no
 * hace falta auto-notificarlo).
 */
const notificarComunicadoEnviado = async(comunicado, usuarioQueEnvia) => {
    const destinatarios = await Promise.all([
        obtenerUsuariosRepository({ rol: 'Laico', id_capilla: comunicado.id_capilla || undefined, activo: true }),
        obtenerUsuariosRepository({ rol: 'Coordinador', id_capilla: comunicado.id_capilla || undefined, activo: true })
    ]);

    await Promise.all(destinatarios.flat().map((usuario) =>
        crearNotificacionService(usuario.id_usuario, comunicado.titulo, comunicado.mensaje)
    ));

    if (usuarioQueEnvia?.rol === 'Coordinador') {
        await notificarSacerdoteService(
            `Comunicado de un Coordinador: ${comunicado.titulo}`,
            comunicado.mensaje
        );
    }
};

export const listarComunicadosPublicos = async(req, res) => {
    try {
        const { id_capilla } = req.query;

        const comunicados = await obtenerComunicadosPublicosService(id_capilla);

        res.json({
            mensaje: 'Listado de comunicados publicados',
            total: comunicados.length,
            comunicados
        });
    } catch (error) {
        res.status(500).json({
            mensaje: 'Error al listar comunicados',
            error: error.message
        });
    }
};

export const listarComunicados = async(req, res) => {
    try {
        const { id_capilla, estado } = req.query;

        const filtros = { id_capilla, estado };

        if (req.usuario.rol === 'Coordinador') {
            filtros.id_capilla = req.usuario.id_capilla;
        }

        const comunicados = await obtenerComunicadosService(filtros);

        res.json({
            mensaje: 'Listado de comunicados',
            total: comunicados.length,
            comunicados
        });
    } catch (error) {
        res.status(500).json({
            mensaje: 'Error al listar comunicados',
            error: error.message
        });
    }
};

export const buscarComunicadoPorId = async(req, res) => {
    try {
        const id = Number(req.params.id);

        const comunicado = await obtenerComunicadoPorIdService(id);

        if (!comunicado) {
            return res.status(404).json({
                mensaje: 'Comunicado no encontrado'
            });
        }

        res.json({
            mensaje: 'Comunicado encontrado',
            comunicado
        });
    } catch (error) {
        res.status(500).json({
            mensaje: 'Error al buscar comunicado',
            error: error.message
        });
    }
};

export const registrarComunicado = async(req, res) => {
    try {
        const { titulo, mensaje, id_capilla, estado } = req.body;

        if (!titulo || !mensaje) {
            return res.status(400).json({
                mensaje: 'Los campos titulo y mensaje son obligatorios'
            });
        }

        const comunicado = await crearComunicadoService({ titulo, mensaje, id_capilla, estado }, req.usuario);

        if (comunicado.estado === 'Enviado') {
            await notificarComunicadoEnviado(comunicado, req.usuario);
        }

        res.status(201).json({
            mensaje: 'Comunicado creado correctamente',
            comunicado
        });
    } catch (error) {
        res.status(403).json({
            mensaje: 'Error al crear comunicado',
            error: error.message
        });
    }
};

export const editarComunicado = async(req, res) => {
    try {
        const id = Number(req.params.id);
        const { titulo, mensaje, id_capilla, estado } = req.body;

        if (!titulo || !mensaje) {
            return res.status(400).json({
                mensaje: 'Los campos titulo y mensaje son obligatorios'
            });
        }

        const comunicadoAnterior = await obtenerComunicadoPorIdRepository(id);
        const comunicado = await actualizarComunicadoService(id, { titulo, mensaje, id_capilla, estado }, req.usuario);

        if (!comunicado) {
            return res.status(404).json({
                mensaje: 'Comunicado no encontrado'
            });
        }

        if (comunicado.estado === 'Enviado' && comunicadoAnterior?.estado !== 'Enviado') {
            await notificarComunicadoEnviado(comunicado, req.usuario);
        }

        res.json({
            mensaje: 'Comunicado actualizado correctamente',
            comunicado
        });
    } catch (error) {
        res.status(403).json({
            mensaje: 'Error al actualizar comunicado',
            error: error.message
        });
    }
};

export const borrarComunicado = async(req, res) => {
    try {
        const id = Number(req.params.id);

        const comunicado = await eliminarComunicadoService(id);

        if (!comunicado) {
            return res.status(404).json({
                mensaje: 'Comunicado no encontrado'
            });
        }

        res.json({
            mensaje: 'Comunicado eliminado correctamente',
            comunicado
        });
    } catch (error) {
        res.status(500).json({
            mensaje: 'Error al eliminar comunicado',
            error: error.message
        });
    }
};
