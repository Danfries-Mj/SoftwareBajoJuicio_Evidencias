import {
    obtenerCertificadosService,
    obtenerCertificadoPorIdService,
    verificarPrerequisitoCertificadoService,
    crearCertificadoService,
    emitirCertificadoService,
    rechazarCertificadoService,
    eliminarCertificadoService
} from '../services/certificados.service.js';
import { obtenerUsuarioPorIdService, obtenerUsuarioPorPersonaService } from '../services/usuarios.service.js';
import { crearNotificacionService } from '../services/notificaciones.service.js';
import { obtenerSolicitudPendientePorBeneficiarioService, rechazarSolicitudService } from '../services/solicitudesSacramento.service.js';
import { obtenerPersonaPorIdService } from '../services/personas.service.js';
import {
    obtenerInscritoPendientePorCedulaService,
    actualizarInscritoService,
    eliminarInscritoService
} from '../services/inscritosCatequesis.service.js';

// Sacramento de catequesis que depende de cada tipo de certificado como prerrequisito.
const SACRAMENTO_DEPENDIENTE = {
    'Bautismo': 'Primera Comunion',
    'Primera Comunion': 'Confirmacion'
};

export const listarCertificados = async(req, res) => {
    try {
        const { tipo, estado, id_persona } = req.query;

        const filtros = { tipo, estado, id_persona };

        // Un Laico solo puede consultar sus propios certificados, sin importar qué
        // id_persona venga en la query; otros roles (Sacerdote, Catequista, etc.)
        // sí pueden consultar por id_persona para validar prerrequisitos de terceros
        // (que pueden no tener cuenta de usuario).
        if (req.usuario.rol === 'Laico') {
            const usuario = await obtenerUsuarioPorIdService(req.usuario.id_usuario);
            filtros.id_persona = usuario?.id_persona;
        }

        const certificados = await obtenerCertificadosService(filtros);

        res.json({
            mensaje: 'Listado de certificados',
            total: certificados.length,
            certificados
        });
    } catch (error) {
        res.status(500).json({
            mensaje: 'Error al listar certificados',
            error: error.message
        });
    }
};

export const buscarCertificadoPorId = async(req, res) => {
    try {
        const id = Number(req.params.id);

        const certificado = await obtenerCertificadoPorIdService(id);

        if (!certificado) {
            return res.status(404).json({
                mensaje: 'Certificado no encontrado'
            });
        }

        res.json({
            mensaje: 'Certificado encontrado',
            certificado
        });
    } catch (error) {
        res.status(500).json({
            mensaje: 'Error al buscar certificado',
            error: error.message
        });
    }
};

export const verificarPrerequisitoCertificado = async(req, res) => {
    try {
        const { id_persona, tipo } = req.query;

        if (!id_persona || !tipo) {
            return res.status(400).json({
                mensaje: 'Los parámetros id_persona y tipo son obligatorios'
            });
        }

        const resultado = await verificarPrerequisitoCertificadoService(Number(id_persona), tipo);

        res.json({
            mensaje: 'Verificación de prerrequisito completada',
            ...resultado
        });
    } catch (error) {
        res.status(400).json({
            mensaje: 'Error al verificar el prerrequisito del certificado',
            error: error.message
        });
    }
};

export const registrarCertificado = async(req, res) => {
    try {
        const { tipo, id_capilla, archivo_nombre, archivo_url, mime_type, id_persona } = req.body;

        if (!tipo) {
            return res.status(400).json({
                mensaje: 'El campo tipo es obligatorio'
            });
        }

        // Por defecto un Laico sube su propio certificado (se resuelve su id_persona desde
        // su propia cuenta); pero también puede adjuntar el certificado de un tercero que
        // está inscribiendo (id_persona explícito en el body, tenga o no cuenta de usuario).
        // Un Sacerdote siempre puede generarlo a nombre de cualquier persona.
        let idPersona = id_persona;
        if (req.usuario.rol === 'Laico' && !idPersona) {
            const usuario = await obtenerUsuarioPorIdService(req.usuario.id_usuario);
            idPersona = usuario?.id_persona;
        }

        if (!idPersona) {
            return res.status(400).json({
                mensaje: 'El campo id_persona es obligatorio'
            });
        }

        const certificado = await crearCertificadoService({
            id_persona: idPersona, tipo, id_capilla,
            archivo_nombre, archivo_url, mime_type,
            esCreadoPorSacerdote: req.usuario.rol === 'Sacerdote'
        });

        res.status(201).json({
            mensaje: 'Solicitud de certificado registrada correctamente',
            certificado
        });
    } catch (error) {
        res.status(400).json({
            mensaje: 'Error al registrar solicitud de certificado',
            error: error.message
        });
    }
};

export const emitirCertificado = async(req, res) => {
    try {
        const id = Number(req.params.id);
        const { fecha_emision, archivo_url, archivo_nombre, mime_type } = req.body;

        if (!fecha_emision) {
            return res.status(400).json({
                mensaje: 'El campo fecha_emision es obligatorio'
            });
        }

        const hoy = new Date();
        hoy.setHours(0, 0, 0, 0);
        const fechaEmision = new Date(fecha_emision + 'T00:00:00');

        if (fechaEmision < hoy) {
            return res.status(400).json({
                mensaje: 'La fecha de emisión no puede ser anterior a la fecha actual'
            });
        }

        const certificadoActual = await obtenerCertificadoPorIdService(id);

        if (certificadoActual && certificadoActual.fecha_solicitud) {
            const fechaSolicitud = new Date(certificadoActual.fecha_solicitud);
            fechaSolicitud.setHours(0, 0, 0, 0);
            if (fechaEmision < fechaSolicitud) {
                return res.status(400).json({
                    mensaje: 'La fecha de emisión no puede ser anterior a la fecha de solicitud'
                });
            }
        }

        // Nombre del sacerdote que emite, para la firma del certificado cuando se
        // genera el PDF automáticamente (no aplica si se adjunta un archivo manual).
        let parrocoNombre;
        if (!archivo_url) {
            const sacerdote = await obtenerUsuarioPorIdService(req.usuario.id_usuario);
            parrocoNombre = sacerdote ? `${sacerdote.nombres} ${sacerdote.apellidos}` : undefined;
        }

        const certificado = await emitirCertificadoService(id, { fecha_emision, archivo_url, archivo_nombre, mime_type, parrocoNombre });

        if (!certificado) {
            return res.status(404).json({
                mensaje: 'Certificado no encontrado'
            });
        }

        // Solo se puede notificar dentro del sistema si la persona tiene una cuenta de
        // usuario; un tercero sin cuenta simplemente no recibe notificación in-app.
        const usuarioNotificar = await obtenerUsuarioPorPersonaService(certificado.id_persona);
        if (usuarioNotificar) {
            await crearNotificacionService(
                usuarioNotificar.id_usuario,
                'Certificado emitido',
                `Tu certificado de ${certificado.tipo} fue validado y emitido por el sacerdote. Ya puedes descargarlo.`
            );
        }

        // Si un Catequista había registrado a esta persona en un nivel de catequesis que
        // dependía de este certificado (quedó "Pendiente" porque el certificado todavía no
        // estaba validado), ahora que se emitió se promueve el inscrito a "Activo".
        const nivelDependiente = SACRAMENTO_DEPENDIENTE[certificado.tipo];
        if (nivelDependiente) {
            const persona = await obtenerPersonaPorIdService(certificado.id_persona);
            const inscritoPendiente = persona
                ? await obtenerInscritoPendientePorCedulaService(persona.cedula, nivelDependiente)
                : null;
            if (inscritoPendiente) {
                await actualizarInscritoService(inscritoPendiente.id_inscrito, {
                    id_catequista: inscritoPendiente.id_catequista,
                    estado: 'Activo',
                    nota: 'Certificado prerrequisito validado por el Sacerdote'
                });
                if (inscritoPendiente.id_catequista) {
                    await crearNotificacionService(
                        inscritoPendiente.id_catequista,
                        'Inscrito activado',
                        `El certificado de ${certificado.tipo} de ${inscritoPendiente.nombres} fue validado: su inscripción a ${inscritoPendiente.nivel} ya está Activa.`
                    );
                }
            }
        }

        res.json({
            mensaje: 'Certificado emitido correctamente',
            certificado
        });
    } catch (error) {
        res.status(500).json({
            mensaje: 'Error al emitir certificado',
            error: error.message
        });
    }
};

export const rechazarCertificado = async(req, res) => {
    try {
        const id = Number(req.params.id);

        const certificado = await rechazarCertificadoService(id);

        if (!certificado) {
            return res.status(404).json({
                mensaje: 'Certificado no encontrado'
            });
        }

        const usuarioNotificar = await obtenerUsuarioPorPersonaService(certificado.id_persona);
        if (usuarioNotificar) {
            await crearNotificacionService(
                usuarioNotificar.id_usuario,
                'Certificado rechazado',
                `Tu certificado de ${certificado.tipo} fue rechazado por el sacerdote. Revísalo y vuelve a subirlo.`
            );
        }

        // Si había una solicitud de catequesis Pendiente esperando este certificado como
        // prerrequisito, no puede seguir esperando una validación que ya no llegará: se
        // rechaza también y se avisa a quien la envió (incluyendo su comprobante de pago).
        const sacramentoDependiente = SACRAMENTO_DEPENDIENTE[certificado.tipo];
        if (sacramentoDependiente) {
            const solicitudVinculada = await obtenerSolicitudPendientePorBeneficiarioService(certificado.id_persona, sacramentoDependiente);
            if (solicitudVinculada) {
                await rechazarSolicitudService(solicitudVinculada.id_solicitud);
                await crearNotificacionService(
                    solicitudVinculada.id_usuario,
                    `Solicitud de ${solicitudVinculada.sacramento} rechazada`,
                    `Tu solicitud de ${solicitudVinculada.sacramento} fue rechazada porque el certificado de ${certificado.tipo} no fue validado. Acércate a la parroquia para gestionar tu comprobante de pago.`
                );
            }

            // Igual, si un Catequista había registrado a esta persona en "Mi Catequesis"
            // (inscrito Pendiente esperando este certificado), ese inscrito nunca podrá
            // activarse: se elimina y se notifica al Catequista para que lo corrija.
            const persona = await obtenerPersonaPorIdService(certificado.id_persona);
            const inscritoPendiente = persona
                ? await obtenerInscritoPendientePorCedulaService(persona.cedula, sacramentoDependiente)
                : null;
            if (inscritoPendiente) {
                await eliminarInscritoService(inscritoPendiente.id_inscrito);
                if (inscritoPendiente.id_catequista) {
                    await crearNotificacionService(
                        inscritoPendiente.id_catequista,
                        'Inscrito eliminado',
                        `El certificado de ${certificado.tipo} de ${inscritoPendiente.nombres} fue rechazado: su inscripción pendiente a ${inscritoPendiente.nivel} fue eliminada. Corrige el certificado y vuelve a registrarla.`
                    );
                }
            }
        }

        res.json({
            mensaje: 'Certificado rechazado correctamente',
            certificado
        });
    } catch (error) {
        res.status(400).json({
            mensaje: 'Error al rechazar certificado',
            error: error.message
        });
    }
};

export const borrarCertificado = async(req, res) => {
    try {
        const id = Number(req.params.id);

        const certificado = await eliminarCertificadoService(id);

        if (!certificado) {
            return res.status(404).json({
                mensaje: 'Certificado no encontrado'
            });
        }

        res.json({
            mensaje: 'Certificado eliminado correctamente',
            certificado
        });
    } catch (error) {
        res.status(500).json({
            mensaje: 'Error al eliminar certificado',
            error: error.message
        });
    }
};
