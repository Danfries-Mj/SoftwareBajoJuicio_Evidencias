import {
    obtenerEventosService,
    obtenerEventoPorIdService,
    crearEventoService,
    actualizarEventoService,
    eliminarEventoService
} from '../services/eventos.service.js';
import { notificarSacerdoteService } from '../services/notificaciones.service.js';
import { obtenerCapillaPorIdRepository } from '../repositories/capillas.repository.js';

const ESTADOS_EVENTO = ['Proximo', 'Realizado'];

/** Un evento marcado como "Realizado" puede tener fecha pasada; los demás no. */
function validarFechaEvento(fecha, estado) {
    const hoy = new Date();
    hoy.setHours(0, 0, 0, 0);
    const fechaEvento = new Date(fecha + 'T00:00:00');

    if (estado !== 'Realizado' && fechaEvento < hoy) {
        return 'La fecha del evento no puede ser anterior a la fecha actual';
    }

    return null;
}

export const listarEventos = async(req, res) => {
    try {
        const { id_capilla, tipo_ambito, estado } = req.query;

        const eventos = await obtenerEventosService({ id_capilla, tipo_ambito, estado });

        res.json({
            mensaje: 'Listado de eventos',
            total: eventos.length,
            eventos
        });
    } catch (error) {
        res.status(500).json({
            mensaje: 'Error al listar eventos',
            error: error.message
        });
    }
};

export const buscarEventoPorId = async(req, res) => {
    try {
        const id = Number(req.params.id);

        const evento = await obtenerEventoPorIdService(id);

        if (!evento) {
            return res.status(404).json({
                mensaje: 'Evento no encontrado'
            });
        }

        res.json({
            mensaje: 'Evento encontrado',
            evento
        });
    } catch (error) {
        res.status(500).json({
            mensaje: 'Error al buscar evento',
            error: error.message
        });
    }
};

export const registrarEvento = async(req, res) => {
    try {
        const { nombre, tipo_ambito, categoria, id_capilla, fecha, hora_inicio, hora_fin, lugar, capacidad, descripcion, estado } = req.body;

        if (!nombre || !tipo_ambito || !fecha) {
            return res.status(400).json({
                mensaje: 'Los campos nombre, tipo_ambito y fecha son obligatorios'
            });
        }

        const estadoEvento = estado || 'Proximo';
        if (!ESTADOS_EVENTO.includes(estadoEvento)) {
            return res.status(400).json({
                mensaje: 'El estado del evento debe ser Proximo o Realizado'
            });
        }

        const errorFecha = validarFechaEvento(fecha, estadoEvento);
        if (errorFecha) {
            return res.status(400).json({
                mensaje: errorFecha
            });
        }

        if (hora_inicio && hora_fin && hora_inicio >= hora_fin) {
            return res.status(400).json({
                mensaje: 'La hora de inicio debe ser anterior a la hora de fin'
            });
        }

        const evento = await crearEventoService({
            nombre, tipo_ambito, categoria, id_capilla, fecha, hora_inicio, hora_fin, lugar, capacidad, descripcion, estado: estadoEvento
        }, req.usuario);

        // Al Sacerdote le interesa enterarse de los eventos que crea un Coordinador en su
        // capilla; si el evento lo crea el propio Sacerdote, no hace falta avisarle.
        if (req.usuario.rol !== 'Sacerdote' && tipo_ambito === 'Capilla') {
            const capilla = await obtenerCapillaPorIdRepository(id_capilla);
            await notificarSacerdoteService(
                'Nuevo evento en una capilla',
                `Se creó el evento "${evento.nombre}" en ${capilla?.nombre ?? 'una capilla'}.`
            );
        }

        res.status(201).json({
            mensaje: 'Evento creado correctamente',
            evento
        });
    } catch (error) {
        res.status(error.message?.includes('Ya hay una eucaristía') ? 409 : 403).json({
            mensaje: error.message,
            error: error.message
        });
    }
};

export const editarEvento = async(req, res) => {
    try {
        const id = Number(req.params.id);
        const { nombre, tipo_ambito, categoria, id_capilla, fecha, hora_inicio, hora_fin, lugar, capacidad, descripcion, estado } = req.body;

        if (!nombre || !tipo_ambito || !fecha) {
            return res.status(400).json({
                mensaje: 'Los campos nombre, tipo_ambito y fecha son obligatorios'
            });
        }

        const hoy = new Date();
        hoy.setHours(0, 0, 0, 0);
        const fechaEvento = new Date(fecha + 'T00:00:00');

        if (estado !== 'Realizado' && fechaEvento < hoy) {
            return res.status(400).json({
                mensaje: 'La fecha del evento no puede ser anterior a la fecha actual'
            });
        }

        if (hora_inicio && hora_fin && hora_inicio >= hora_fin) {
            return res.status(400).json({
                mensaje: 'La hora de inicio debe ser anterior a la hora de fin'
            });
        }

        const evento = await actualizarEventoService(id, {
            nombre, tipo_ambito, categoria, id_capilla, fecha, hora_inicio, hora_fin, lugar, capacidad, descripcion, estado
        }, req.usuario);

        if (!evento) {
            return res.status(404).json({
                mensaje: 'Evento no encontrado'
            });
        }

        res.json({
            mensaje: 'Evento actualizado correctamente',
            evento
        });
    } catch (error) {
        res.status(error.message?.includes('Ya hay una eucaristía') ? 409 : 403).json({
            mensaje: error.message,
            error: error.message
        });
    }
};

export const borrarEvento = async(req, res) => {
    try {
        const id = Number(req.params.id);

        const evento = await eliminarEventoService(id, req.usuario);

        if (!evento) {
            return res.status(404).json({
                mensaje: 'Evento no encontrado'
            });
        }

        res.json({
            mensaje: 'Evento eliminado correctamente',
            evento
        });
    } catch (error) {
        res.status(403).json({
            mensaje: 'Error al eliminar evento',
            error: error.message
        });
    }
};
