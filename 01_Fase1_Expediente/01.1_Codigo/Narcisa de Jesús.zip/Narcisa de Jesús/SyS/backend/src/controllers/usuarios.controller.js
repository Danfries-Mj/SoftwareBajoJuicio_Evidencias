import {
    obtenerUsuariosService,
    obtenerUsuarioPorIdService,
    obtenerUsuarioPorCedulaService,
    crearUsuarioService,
    actualizarUsuarioService,
    actualizarPerfilUsuarioService,
    desactivarUsuarioService,
    activarUsuarioService
} from '../services/usuarios.service.js';
import { notificarCoordinadorNuevoMiembroService } from '../services/notificaciones.service.js';
import { cedulaValida } from '../utils/validators.js';

const MENSAJE_SACERDOTE_UNICO = 'Error. No puede haber un sacerdote más';
const ERROR_SACERDOTE_UNICO = 'Ya existe un usuario con rol Sacerdote. Solo puede haber uno activo a la vez.';

/** Devuelve el mensaje público adecuado para un error de servicio. */
function mensajeDeErrorServicio(error) {
    return error.message === ERROR_SACERDOTE_UNICO ? MENSAJE_SACERDOTE_UNICO : null;
}

export const listarUsuarios = async(req, res) => {
    try {
        const { rol } = req.query;
        // Un Coordinador solo puede ver los miembros de su propia capilla,
        // sin importar qué id_capilla venga en la query.
        const id_capilla = req.usuario.rol === 'Coordinador'
            ? req.usuario.id_capilla
            : req.query.id_capilla;

        const usuarios = await obtenerUsuariosService({ rol, id_capilla });

        res.json({
            mensaje: 'Listado de usuarios',
            total: usuarios.length,
            usuarios
        });
    } catch (error) {
        res.status(500).json({
            mensaje: 'Error al listar usuarios',
            error: error.message
        });
    }
};

export const buscarUsuarioPorId = async(req, res) => {
    try {
        const id = Number(req.params.id);

        const usuario = await obtenerUsuarioPorIdService(id);

        if (!usuario) {
            return res.status(404).json({
                mensaje: 'Usuario no encontrado'
            });
        }

        res.json({
            mensaje: 'Usuario encontrado',
            usuario
        });
    } catch (error) {
        res.status(500).json({
            mensaje: 'Error al buscar usuario',
            error: error.message
        });
    }
};

export const buscarUsuarioPorCedula = async(req, res) => {
    try {
        const { cedula } = req.params;

        const usuario = await obtenerUsuarioPorCedulaService(cedula);

        if (!usuario) {
            return res.status(404).json({
                mensaje: 'Usuario no encontrado'
            });
        }

        res.json({
            mensaje: 'Usuario encontrado',
            usuario
        });
    } catch (error) {
        res.status(500).json({
            mensaje: 'Error al buscar usuario por cédula',
            error: error.message
        });
    }
};

export const registrarUsuario = async(req, res) => {
    try {
        const { cedula, nombres, apellidos, telefono, correo, contrasena, rol, id_capilla } = req.body;

        if (!cedula || !nombres || !apellidos || !correo || !contrasena || !rol) {
            return res.status(400).json({
                mensaje: 'Los campos cedula, nombres, apellidos, correo, contrasena y rol son obligatorios'
            });
        }

        if (!cedulaValida(cedula)) {
            return res.status(400).json({
                mensaje: 'La cédula ingresada no es válida'
            });
        }

        const usuario = await crearUsuarioService({
            cedula, nombres, apellidos, telefono, correo, contrasena, rol, id_capilla
        }, req.usuario.id_usuario);

        await notificarCoordinadorNuevoMiembroService(id_capilla || null, `${nombres} ${apellidos}`);

        res.status(201).json({
            mensaje: 'Usuario creado correctamente',
            usuario
        });
    } catch (error) {
        res.status(400).json({
            mensaje: mensajeDeErrorServicio(error) ?? 'Error al crear usuario',
            error: error.message
        });
    }
};

export const editarUsuario = async(req, res) => {
    try {
        const id = Number(req.params.id);
        const { rol, id_capilla, activo } = req.body;

        if (!rol) {
            return res.status(400).json({
                mensaje: 'El campo rol es obligatorio'
            });
        }

        const usuario = await actualizarUsuarioService(id, { rol, id_capilla, activo }, req.usuario.id_usuario);

        if (!usuario) {
            return res.status(404).json({
                mensaje: 'Usuario no encontrado'
            });
        }

        res.json({
            mensaje: 'Usuario actualizado correctamente',
            usuario
        });
    } catch (error) {
        res.status(400).json({
            mensaje: mensajeDeErrorServicio(error) ?? 'Error al actualizar usuario',
            error: error.message
        });
    }
};

export const editarPerfilPropio = async(req, res) => {
    try {
        const id = Number(req.params.id);

        if (id !== req.usuario.id_usuario) {
            return res.status(403).json({
                mensaje: 'Solo puede editar su propio perfil'
            });
        }

        const { nombres, apellidos, telefono, correo, contrasena, contrasenaActual } = req.body;

        if (!nombres || !apellidos || !correo) {
            return res.status(400).json({
                mensaje: 'Los campos nombres, apellidos y correo son obligatorios'
            });
        }

        if (contrasena && !contrasenaActual) {
            return res.status(400).json({
                mensaje: 'Debe ingresar su contraseña actual para cambiar la contraseña'
            });
        }

        const usuario = await actualizarPerfilUsuarioService(id, {
            nombres, apellidos, telefono, correo, contrasena, contrasenaActual
        });

        res.json({
            mensaje: 'Perfil actualizado correctamente',
            usuario
        });
    } catch (error) {
        res.status(400).json({
            mensaje: 'Error al actualizar el perfil',
            error: error.message
        });
    }
};

export const desactivarUsuario = async(req, res) => {
    try {
        const id = Number(req.params.id);

        const usuario = await desactivarUsuarioService(id, req.usuario.id_usuario);

        if (!usuario) {
            return res.status(404).json({
                mensaje: 'Usuario no encontrado'
            });
        }

        res.json({
            mensaje: 'Usuario desactivado correctamente',
            usuario
        });
    } catch (error) {
        res.status(500).json({
            mensaje: 'Error al desactivar usuario',
            error: error.message
        });
    }
};

export const activarUsuario = async(req, res) => {
    try {
        const id = Number(req.params.id);

        const usuario = await activarUsuarioService(id, req.usuario.id_usuario);

        if (!usuario) {
            return res.status(404).json({
                mensaje: 'Usuario no encontrado'
            });
        }

        res.json({
            mensaje: 'Usuario activado correctamente',
            usuario
        });
    } catch (error) {
        res.status(400).json({
            mensaje: mensajeDeErrorServicio(error) ?? 'Error al activar usuario',
            error: error.message
        });
    }
};
