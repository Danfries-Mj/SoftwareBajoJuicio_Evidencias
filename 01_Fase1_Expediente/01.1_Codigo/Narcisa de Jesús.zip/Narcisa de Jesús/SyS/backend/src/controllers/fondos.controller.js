import {
    obtenerFondosService,
    obtenerFondoPorIdService,
    crearFondoService,
    actualizarFondoService,
    eliminarFondoService,
    puedeEditarDatosFondo
} from '../services/fondos.service.js';
import { obtenerFondoPorIdRepository } from '../repositories/fondos.repository.js';

export const listarFondos = async(req, res) => {
    try {
        const fondos = await obtenerFondosService(req.usuario);

        res.json({
            mensaje: 'Listado de fondos',
            total: fondos.length,
            fondos
        });
    } catch (error) {
        res.status(500).json({
            mensaje: 'Error al listar fondos',
            error: error.message
        });
    }
};

export const buscarFondoPorId = async(req, res) => {
    try {
        const id = Number(req.params.id);

        const fondo = await obtenerFondoPorIdService(id);

        if (!fondo) {
            return res.status(404).json({
                mensaje: 'Fondo no encontrado'
            });
        }

        res.json({
            mensaje: 'Fondo encontrado',
            fondo
        });
    } catch (error) {
        res.status(500).json({
            mensaje: 'Error al buscar fondo',
            error: error.message
        });
    }
};

export const registrarFondo = async(req, res) => {
    try {
        const { nombre, descripcion, saldo_actual, id_capilla } = req.body;

        if (!nombre) {
            return res.status(400).json({
                mensaje: 'El nombre es obligatorio'
            });
        }

        const fondo = await crearFondoService({ nombre, descripcion, saldo_actual, id_capilla });

        res.status(201).json({
            mensaje: 'Fondo creado correctamente',
            fondo
        });
    } catch (error) {
        res.status(500).json({
            mensaje: 'Error al crear fondo',
            error: error.message
        });
    }
};

export const editarFondo = async(req, res) => {
    try {
        const id = Number(req.params.id);
        const { nombre, descripcion, id_capilla } = req.body;

        if (!nombre) {
            return res.status(400).json({
                mensaje: 'El nombre es obligatorio'
            });
        }

        const fondoActual = await obtenerFondoPorIdRepository(id);

        if (!fondoActual) {
            return res.status(404).json({
                mensaje: 'Fondo no encontrado'
            });
        }

        if (!puedeEditarDatosFondo(req.usuario)) {
            return res.status(403).json({
                mensaje: 'No tiene permisos para editar este fondo'
            });
        }

        const datosActualizados = {
            nombre,
            descripcion,
            id_capilla: req.usuario.rol === 'Tesorero' ? fondoActual.id_capilla : id_capilla
        };

        const fondo = await actualizarFondoService(id, datosActualizados);

        res.json({
            mensaje: 'Fondo actualizado correctamente',
            fondo
        });
    } catch (error) {
        res.status(500).json({
            mensaje: 'Error al actualizar fondo',
            error: error.message
        });
    }
};

export const borrarFondo = async(req, res) => {
    try {
        const id = Number(req.params.id);

        const fondo = await eliminarFondoService(id);

        if (!fondo) {
            return res.status(404).json({
                mensaje: 'Fondo no encontrado'
            });
        }

        res.json({
            mensaje: 'Fondo eliminado correctamente',
            fondo
        });
    } catch (error) {
        res.status(500).json({
            mensaje: 'Error al eliminar fondo',
            error: error.message
        });
    }
};
