import {
    obtenerEucaristiasService,
    obtenerEucaristiaPorIdService,
    crearEucaristiaService,
    actualizarEucaristiaService,
    eliminarEucaristiaService,
    marcarEucaristiasPasadasComoRealizadasService
} from '../services/eucaristias.service.js';

/** true si la fecha (string 'YYYY-MM-DD') es el día de hoy. */
const esHoy = (fechaEucaristia, hoy) => fechaEucaristia.getTime() === hoy.getTime();

/** La hora de inicio de una eucaristía programada para hoy debe ser posterior a la hora actual. */
const horaYaPaso = (horaInicio) => {
    const ahora = new Date();
    const horaActual = `${String(ahora.getHours()).padStart(2, '0')}:${String(ahora.getMinutes()).padStart(2, '0')}`;
    return horaInicio <= horaActual;
};

/**
 * No tiene sentido marcar como 'Realizada' una misa que todavía no ha ocurrido: ni con
 * fecha futura, ni con fecha de hoy pero hora que aún no ha llegado.
 */
const realizadaEsFutura = (estado, fechaEucaristia, hoy, horaInicio) => {
    if (estado !== 'Realizada') return false;
    if (fechaEucaristia > hoy) return true;
    return esHoy(fechaEucaristia, hoy) && !horaYaPaso(horaInicio);
};

export const listarEucaristias = async(req, res) => {
    try {
        const { id_capilla, dia_semana, estado } = req.query;

        const eucaristias = await obtenerEucaristiasService({ id_capilla, dia_semana, estado });

        res.json({
            mensaje: 'Listado de horarios de eucaristías',
            total: eucaristias.length,
            eucaristias
        });
    } catch (error) {
        res.status(500).json({
            mensaje: 'Error al listar horarios de eucaristías',
            error: error.message
        });
    }
};

export const buscarEucaristiaPorId = async(req, res) => {
    try {
        const id = Number(req.params.id);

        const eucaristia = await obtenerEucaristiaPorIdService(id);

        if (!eucaristia) {
            return res.status(404).json({
                mensaje: 'Horario de eucaristía no encontrado'
            });
        }

        res.json({
            mensaje: 'Horario de eucaristía encontrado',
            eucaristia
        });
    } catch (error) {
        res.status(500).json({
            mensaje: 'Error al buscar horario de eucaristía',
            error: error.message
        });
    }
};

export const registrarEucaristia = async(req, res) => {
    try {
        const { id_capilla, dia_semana, fecha, hora_inicio, hora_fin, id_sacerdote, estado } = req.body;

        if (!id_capilla || !dia_semana || !fecha || !hora_inicio || !hora_fin) {
            return res.status(400).json({
                mensaje: 'Los campos id_capilla, dia_semana, fecha, hora_inicio y hora_fin son obligatorios'
            });
        }

        const hoy = new Date();
        hoy.setHours(0, 0, 0, 0);
        const fechaEucaristia = new Date(fecha + 'T00:00:00');

        if (fechaEucaristia < hoy) {
            return res.status(400).json({
                mensaje: 'La fecha de la eucaristía no puede ser anterior a la fecha actual'
            });
        }

        if (esHoy(fechaEucaristia, hoy) && horaYaPaso(hora_inicio)) {
            return res.status(400).json({
                mensaje: 'La hora de la eucaristía debe ser posterior a la hora actual'
            });
        }

        if (hora_inicio >= hora_fin) {
            return res.status(400).json({
                mensaje: 'La hora de inicio debe ser anterior a la hora de fin'
            });
        }

        if (realizadaEsFutura(estado, fechaEucaristia, hoy, hora_inicio)) {
            return res.status(400).json({
                mensaje: 'No se puede marcar como Realizada una misa cuya fecha u hora todavía no ha ocurrido'
            });
        }

        const eucaristia = await crearEucaristiaService({
            id_capilla, dia_semana, fecha, hora_inicio, hora_fin, id_sacerdote, estado
        });

        res.status(201).json({
            mensaje: 'Horario de eucaristía creado correctamente',
            eucaristia
        });
    } catch (error) {
        res.status(409).json({
            mensaje: 'Error al crear horario de eucaristía',
            error: error.message
        });
    }
};

export const editarEucaristia = async(req, res) => {
    try {
        const id = Number(req.params.id);
        const { id_capilla, dia_semana, fecha, hora_inicio, hora_fin, id_sacerdote, estado } = req.body;

        if (!id_capilla || !dia_semana || !fecha || !hora_inicio || !hora_fin) {
            return res.status(400).json({
                mensaje: 'Los campos id_capilla, dia_semana, fecha, hora_inicio y hora_fin son obligatorios'
            });
        }

        const hoy = new Date();
        hoy.setHours(0, 0, 0, 0);
        const fechaEucaristia = new Date(fecha + 'T00:00:00');

        if (fechaEucaristia < hoy) {
            return res.status(400).json({
                mensaje: 'La fecha de la eucaristía no puede ser anterior a la fecha actual'
            });
        }

        if (esHoy(fechaEucaristia, hoy) && horaYaPaso(hora_inicio)) {
            return res.status(400).json({
                mensaje: 'La hora de la eucaristía debe ser posterior a la hora actual'
            });
        }

        if (hora_inicio >= hora_fin) {
            return res.status(400).json({
                mensaje: 'La hora de inicio debe ser anterior a la hora de fin'
            });
        }

        if (realizadaEsFutura(estado, fechaEucaristia, hoy, hora_inicio)) {
            return res.status(400).json({
                mensaje: 'No se puede marcar como Realizada una misa cuya fecha u hora todavía no ha ocurrido'
            });
        }

        const eucaristia = await actualizarEucaristiaService(id, {
            id_capilla, dia_semana, fecha, hora_inicio, hora_fin, id_sacerdote, estado
        });

        if (!eucaristia) {
            return res.status(404).json({
                mensaje: 'Horario de eucaristía no encontrado'
            });
        }

        res.json({
            mensaje: 'Horario de eucaristía actualizado correctamente',
            eucaristia
        });
    } catch (error) {
        res.status(409).json({
            mensaje: 'Error al actualizar horario de eucaristía',
            error: error.message
        });
    }
};

export const marcarEucaristiasComoRealizadas = async(req, res) => {
    try {
        const eucaristias = await marcarEucaristiasPasadasComoRealizadasService();

        res.json({
            mensaje: 'Misas pasadas actualizadas a Realizada',
            total: eucaristias.length,
            eucaristias
        });
    } catch (error) {
        res.status(500).json({
            mensaje: 'Error al marcar misas pasadas como realizadas',
            error: error.message
        });
    }
};

export const borrarEucaristia = async(req, res) => {
    try {
        const id = Number(req.params.id);

        const eucaristia = await eliminarEucaristiaService(id);

        if (!eucaristia) {
            return res.status(404).json({
                mensaje: 'Horario de eucaristía no encontrado'
            });
        }

        res.json({
            mensaje: 'Horario de eucaristía eliminado correctamente',
            eucaristia
        });
    } catch (error) {
        res.status(500).json({
            mensaje: 'Error al eliminar horario de eucaristía',
            error: error.message
        });
    }
};
