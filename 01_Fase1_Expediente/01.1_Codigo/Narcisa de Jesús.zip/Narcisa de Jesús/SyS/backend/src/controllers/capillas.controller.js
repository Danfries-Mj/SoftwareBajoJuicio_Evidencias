import {
    obtenerCapillasService,
    obtenerCapillaPorIdService,
    crearCapillaService,
    actualizarCapillaService,
    eliminarCapillaService
} from '../services/capillas.service.js';

export const listarCapillas = async(req, res) => {
    try {
        const capillas = await obtenerCapillasService();

        res.json({
            mensaje: 'Listado de capillas',
            total: capillas.length,
            capillas
        });
    } catch (error) {
        res.status(500).json({
            mensaje: 'Error al listar capillas',
            error: error.message
        });
    }
};

export const buscarCapillaPorId = async(req, res) => {
    try {
        const id = Number(req.params.id);

        const capilla = await obtenerCapillaPorIdService(id);

        if (!capilla) {
            return res.status(404).json({
                mensaje: 'Capilla no encontrada'
            });
        }

        res.json({
            mensaje: 'Capilla encontrada',
            capilla
        });
    } catch (error) {
        res.status(500).json({
            mensaje: 'Error al buscar capilla',
            error: error.message
        });
    }
};

export const registrarCapilla = async(req, res) => {
    try {
        const { nombre, direccion, telefono } = req.body;

        if (!nombre) {
            return res.status(400).json({
                mensaje: 'El nombre es obligatorio'
            });
        }

        const capilla = await crearCapillaService({ nombre, direccion, telefono });

        res.status(201).json({
            mensaje: 'Capilla creada correctamente',
            capilla
        });
    } catch (error) {
        res.status(500).json({
            mensaje: 'Error al crear capilla',
            error: error.message
        });
    }
};

export const editarCapilla = async(req, res) => {
    try {
        const id = Number(req.params.id);
        const { nombre, direccion, telefono, activa } = req.body;

        if (!nombre) {
            return res.status(400).json({
                mensaje: 'El nombre es obligatorio'
            });
        }

        const capilla = await actualizarCapillaService(id, { nombre, direccion, telefono, activa });

        if (!capilla) {
            return res.status(404).json({
                mensaje: 'Capilla no encontrada'
            });
        }

        res.json({
            mensaje: 'Capilla actualizada correctamente',
            capilla
        });
    } catch (error) {
        res.status(500).json({
            mensaje: 'Error al actualizar capilla',
            error: error.message
        });
    }
};

export const borrarCapilla = async(req, res) => {
    try {
        const id = Number(req.params.id);

        const capilla = await eliminarCapillaService(id);

        if (!capilla) {
            return res.status(404).json({
                mensaje: 'Capilla no encontrada'
            });
        }

        res.json({
            mensaje: 'Capilla eliminada correctamente',
            capilla
        });
    } catch (error) {
        res.status(500).json({
            mensaje: 'Error al eliminar capilla',
            error: error.message
        });
    }
};
