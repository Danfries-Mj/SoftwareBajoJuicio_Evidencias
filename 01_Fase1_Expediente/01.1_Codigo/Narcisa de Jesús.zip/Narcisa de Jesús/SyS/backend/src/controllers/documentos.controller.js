import {
    obtenerDocumentosService,
    obtenerDocumentoPorIdService,
    crearDocumentoService,
    eliminarDocumentoService
} from '../services/documentos.service.js';

export const listarDocumentos = async(req, res) => {
    try {
        const filtros = {};

        if (req.usuario.rol !== 'Sacerdote') {
            filtros.id_usuario = req.usuario.id_usuario;
        }

        const documentos = await obtenerDocumentosService(filtros);

        res.json({
            mensaje: 'Listado de documentos',
            total: documentos.length,
            documentos
        });
    } catch (error) {
        res.status(500).json({
            mensaje: 'Error al listar documentos',
            error: error.message
        });
    }
};

export const buscarDocumentoPorId = async(req, res) => {
    try {
        const id = Number(req.params.id);

        const documento = await obtenerDocumentoPorIdService(id);

        if (!documento) {
            return res.status(404).json({
                mensaje: 'Documento no encontrado'
            });
        }

        // Solo el dueño del documento o los roles que validan comprobantes de
        // pago (Tesorero, Sacerdote, Catequista, Coordinador) pueden ver un
        // documento ajeno.
        const esDueno = documento.id_usuario === req.usuario.id_usuario;
        const puedeValidar = ['Tesorero', 'Sacerdote', 'Catequista', 'Coordinador'].includes(req.usuario.rol);
        if (!esDueno && !puedeValidar) {
            return res.status(403).json({
                mensaje: 'No tiene permisos para ver este documento'
            });
        }

        res.json({
            mensaje: 'Documento encontrado',
            documento
        });
    } catch (error) {
        res.status(500).json({
            mensaje: 'Error al buscar documento',
            error: error.message
        });
    }
};

export const registrarDocumento = async(req, res) => {
    try {
        const { tipo, archivo_nombre, archivo_url, mime_type } = req.body;

        if (!archivo_nombre || !archivo_url) {
            return res.status(400).json({
                mensaje: 'Los campos archivo_nombre y archivo_url son obligatorios'
            });
        }

        if (typeof archivo_url === 'string' && archivo_url.length < 100) {
            return res.status(400).json({
                mensaje: 'El archivo adjunto está vacío o es inválido'
            });
        }

        const documento = await crearDocumentoService({
            id_usuario: req.usuario.id_usuario, tipo, archivo_nombre, archivo_url, mime_type
        });

        res.status(201).json({
            mensaje: 'Documento registrado correctamente',
            documento
        });
    } catch (error) {
        res.status(400).json({
            mensaje: 'Error al registrar documento',
            error: error.message
        });
    }
};

export const borrarDocumento = async(req, res) => {
    try {
        const id = Number(req.params.id);

        const documento = await obtenerDocumentoPorIdService(id);

        if (!documento) {
            return res.status(404).json({
                mensaje: 'Documento no encontrado'
            });
        }

        if (req.usuario.rol !== 'Sacerdote' && documento.id_usuario !== req.usuario.id_usuario) {
            return res.status(403).json({
                mensaje: 'No tiene permisos para eliminar este documento'
            });
        }

        await eliminarDocumentoService(id);

        res.json({
            mensaje: 'Documento eliminado correctamente',
            documento
        });
    } catch (error) {
        res.status(500).json({
            mensaje: 'Error al eliminar documento',
            error: error.message
        });
    }
};
