import {
    obtenerPersonasService,
    obtenerPersonaPorIdService,
    obtenerPersonaPorCedulaService,
    crearPersonaService,
    actualizarPersonaService,
    eliminarPersonaService
} from '../services/personas.service.js';

export const listarPersonas = async(req, res) => {
    try {
        const personas = await obtenerPersonasService();

        res.json({
            mensaje: 'Listado de personas',
            total: personas.length,
            personas
        });
    } catch (error) {
        res.status(500).json({
            mensaje: 'Error al listar personas',
            error: error.message
        });
    }
};

export const buscarPersonaPorId = async(req, res) => {
    try {
        const id = Number(req.params.id);

        const persona = await obtenerPersonaPorIdService(id);

        if (!persona) {
            return res.status(404).json({
                mensaje: 'Persona no encontrada'
            });
        }

        res.json({
            mensaje: 'Persona encontrada',
            persona
        });
    } catch (error) {
        res.status(500).json({
            mensaje: 'Error al buscar persona',
            error: error.message
        });
    }
};

export const buscarPersonaPorCedula = async(req, res) => {
    try {
        const { cedula } = req.params;

        const persona = await obtenerPersonaPorCedulaService(cedula);

        if (!persona) {
            return res.status(404).json({
                mensaje: 'Persona no encontrada'
            });
        }

        res.json({
            mensaje: 'Persona encontrada',
            persona
        });
    } catch (error) {
        res.status(500).json({
            mensaje: 'Error al buscar persona por cédula',
            error: error.message
        });
    }
};

export const registrarPersona = async(req, res) => {
    try {
        const { cedula, nombres, apellidos, telefono } = req.body;

        const persona = await crearPersonaService({ cedula, nombres, apellidos, telefono });

        res.status(201).json({
            mensaje: 'Persona registrada correctamente',
            persona
        });
    } catch (error) {
        res.status(400).json({
            mensaje: 'Error al registrar persona',
            error: error.message
        });
    }
};

export const editarPersona = async(req, res) => {
    try {
        const id = Number(req.params.id);
        const { nombres, apellidos, telefono } = req.body;

        if (!nombres || !apellidos) {
            return res.status(400).json({
                mensaje: 'Los campos nombres y apellidos son obligatorios'
            });
        }

        const persona = await actualizarPersonaService(id, { nombres, apellidos, telefono });

        if (!persona) {
            return res.status(404).json({
                mensaje: 'Persona no encontrada'
            });
        }

        res.json({
            mensaje: 'Persona actualizada correctamente',
            persona
        });
    } catch (error) {
        res.status(500).json({
            mensaje: 'Error al actualizar persona',
            error: error.message
        });
    }
};

export const borrarPersona = async(req, res) => {
    try {
        const id = Number(req.params.id);

        const persona = await eliminarPersonaService(id);

        if (!persona) {
            return res.status(404).json({
                mensaje: 'Persona no encontrada'
            });
        }

        res.json({
            mensaje: 'Persona eliminada correctamente',
            persona
        });
    } catch (error) {
        res.status(500).json({
            mensaje: 'Error al eliminar persona',
            error: error.message
        });
    }
};
