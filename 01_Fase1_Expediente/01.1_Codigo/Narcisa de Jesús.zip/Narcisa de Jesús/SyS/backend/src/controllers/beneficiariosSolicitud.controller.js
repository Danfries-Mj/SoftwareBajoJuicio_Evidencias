import {
    obtenerBeneficiariosPorSolicitudService,
    crearBeneficiarioService,
    eliminarBeneficiarioService
} from '../services/beneficiariosSolicitud.service.js';
import { cedulaValida } from '../utils/validators.js';

export const listarBeneficiariosPorSolicitud = async(req, res) => {
    try {
        const idSolicitud = Number(req.params.idSolicitud);

        const beneficiarios = await obtenerBeneficiariosPorSolicitudService(idSolicitud);

        res.json({
            mensaje: 'Listado de beneficiarios de la solicitud',
            total: beneficiarios.length,
            beneficiarios
        });
    } catch (error) {
        res.status(500).json({
            mensaje: 'Error al listar beneficiarios',
            error: error.message
        });
    }
};

export const registrarBeneficiario = async(req, res) => {
    try {
        const { id_solicitud, rol_beneficiario, nombres, apellidos, cedula, id_persona } = req.body;

        if (!id_solicitud || !rol_beneficiario) {
            return res.status(400).json({
                mensaje: 'Los campos id_solicitud y rol_beneficiario son obligatorios'
            });
        }

        if (cedula && !cedulaValida(cedula)) {
            return res.status(400).json({
                mensaje: 'La cédula ingresada no es válida'
            });
        }

        const beneficiario = await crearBeneficiarioService({
            id_solicitud, rol_beneficiario, nombres, apellidos, cedula, id_persona
        });

        res.status(201).json({
            mensaje: 'Beneficiario registrado correctamente',
            beneficiario
        });
    } catch (error) {
        res.status(400).json({
            mensaje: error.message,
            error: error.message
        });
    }
};

export const borrarBeneficiario = async(req, res) => {
    try {
        const id = Number(req.params.id);

        const beneficiario = await eliminarBeneficiarioService(id);

        if (!beneficiario) {
            return res.status(404).json({
                mensaje: 'Beneficiario no encontrado'
            });
        }

        res.json({
            mensaje: 'Beneficiario eliminado correctamente',
            beneficiario
        });
    } catch (error) {
        res.status(500).json({
            mensaje: 'Error al eliminar beneficiario',
            error: error.message
        });
    }
};
