import {
    loginService,
    hashearContrasena,
    validarFortalezaContrasena,
    solicitarRecuperacionService,
    restablecerContrasenaService
} from '../services/auth.service.js';
import {
    crearUsuarioConPersonaRepository,
    obtenerUsuarioPorCorreoRepository,
    obtenerUsuarioPorCedulaRepository
} from '../repositories/usuarios.repository.js';
import { obtenerPersonaPorCedulaRepository } from '../repositories/personas.repository.js';
import { notificarCoordinadorNuevoMiembroService, notificarSacerdoteService } from '../services/notificaciones.service.js';
import { cedulaValida } from '../utils/validators.js';

export const iniciarSesion = async(req, res) => {
    try {
        const { correo, contrasena } = req.body;

        if (!correo || !contrasena) {
            return res.status(400).json({
                mensaje: 'Los campos correo y contrasena son obligatorios'
            });
        }

        const resultado = await loginService(correo, contrasena);

        if (!resultado.ok) {
            // Solo cuando la contraseña era la correcta pero la cuenta está inactiva:
            // avisa al Sacerdote de que alguien está intentando entrar con esa cuenta.
            if (resultado.inactivo) {
                const u = resultado.usuario;
                await notificarSacerdoteService(
                    'Intento de inicio de sesión con cuenta inactiva',
                    `${u.nombres} ${u.apellidos} (${u.rol}, cédula ${u.cedula}) intentó iniciar sesión con su cuenta inactiva.`
                );
            }
            return res.status(401).json({
                mensaje: 'Credenciales inválidas o usuario inactivo'
            });
        }

        res.json({
            mensaje: 'Inicio de sesión exitoso',
            usuario: resultado.usuario,
            token: resultado.token
        });
    } catch (error) {
        res.status(500).json({
            mensaje: 'Error al iniciar sesión',
            error: error.message
        });
    }
};

export const olvideContrasena = async(req, res) => {
    const { correo } = req.body;

    if (!correo) {
        return res.status(400).json({
            mensaje: 'El campo correo es obligatorio'
        });
    }

    try {
        await solicitarRecuperacionService(correo);
    } catch (error) {
        console.error('Error al procesar recuperación de contraseña:', error.message);
    }

    res.json({
        mensaje: 'Si el correo está registrado, recibirás un mensaje con instrucciones para restablecer tu contraseña'
    });
};

export const restablecerContrasena = async(req, res) => {
    try {
        const { correo, codigo, contrasena } = req.body;

        if (!correo || !codigo || !contrasena) {
            return res.status(400).json({
                mensaje: 'Los campos correo, codigo y contrasena son obligatorios'
            });
        }

        validarFortalezaContrasena(contrasena);

        const exito = await restablecerContrasenaService(correo, codigo, contrasena);

        if (!exito) {
            return res.status(400).json({
                mensaje: 'El código es inválido o ha expirado'
            });
        }

        res.json({
            mensaje: 'Contraseña restablecida correctamente'
        });
    } catch (error) {
        res.status(500).json({
            mensaje: 'Error al restablecer la contraseña',
            error: error.message
        });
    }
};

/**
 * Endpoint público (sin autenticación) usado por el formulario de registro para
 * validar en tiempo real, mientras el usuario escribe, si la cédula ya está en uso.
 *
 * Si la cédula ya tiene una persona registrada sin cuenta de usuario (p. ej. porque un
 * catequista la inscribió como tercero, o es el bautizando de una solicitud), se
 * consideran datos "encontrados" para que el formulario los autocomplete: el registro
 * sigue estando disponible, solo que se vinculará a esa persona en vez de crear una
 * nueva (persona.cedula es UNIQUE).
 */
export const cedulaDisponible = async(req, res) => {
    try {
        const { cedula } = req.params;
        const usuario = await obtenerUsuarioPorCedulaRepository(cedula);

        if (usuario) {
            return res.json({ disponible: false, personaExistente: null });
        }

        const persona = await obtenerPersonaPorCedulaRepository(cedula);

        res.json({
            disponible: true,
            personaExistente: persona
                ? { nombres: persona.nombres, apellidos: persona.apellidos, telefono: persona.telefono }
                : null
        });
    } catch (error) {
        res.status(500).json({
            mensaje: 'Error al verificar la cédula',
            error: error.message
        });
    }
};

export const registrarLaico = async(req, res) => {
    try {
        const { cedula, nombres, apellidos, telefono, correo, contrasena, id_capilla } = req.body;

        if (!cedula || !nombres || !apellidos || !correo || !contrasena) {
            return res.status(400).json({
                mensaje: 'Los campos cedula, nombres, apellidos, correo y contrasena son obligatorios'
            });
        }

        if (!cedulaValida(cedula)) {
            return res.status(400).json({
                mensaje: 'La cédula ingresada no es válida'
            });
        }

        const correoExistente = await obtenerUsuarioPorCorreoRepository(correo);

        if (correoExistente) {
            return res.status(409).json({
                mensaje: 'Ya existe un usuario registrado con ese correo'
            });
        }

        const cedulaExistente = await obtenerUsuarioPorCedulaRepository(cedula);

        if (cedulaExistente) {
            return res.status(409).json({
                mensaje: 'Ya existe una cuenta registrada con esta cédula'
            });
        }

        // La cédula puede ya tener una persona registrada sin cuenta (inscripción de
        // tercero, bautizando de una solicitud, etc.). En ese caso el usuario nuevo se
        // vincula a esa persona en vez de crear una duplicada.
        const personaExistente = await obtenerPersonaPorCedulaRepository(cedula);

        validarFortalezaContrasena(contrasena);

        const contrasenaHash = await hashearContrasena(contrasena);

        const usuario = await crearUsuarioConPersonaRepository({
            cedula,
            nombres,
            apellidos,
            telefono,
            correo,
            idPersonaExistente: personaExistente?.id_persona ?? null,
            contrasenaHash,
            rol: 'Laico',
            id_capilla: id_capilla || null
        }, null);

        await notificarCoordinadorNuevoMiembroService(id_capilla || null, `${nombres} ${apellidos}`);
        await notificarSacerdoteService('Nuevo usuario registrado', `${nombres} ${apellidos} (Laico) se registró en el sistema.`);

        res.status(201).json({
            mensaje: 'Registro exitoso, ya puede iniciar sesión',
            usuario
        });
    } catch (error) {
        res.status(400).json({
            mensaje: 'Error al registrar el usuario',
            error: error.message
        });
    }
};
