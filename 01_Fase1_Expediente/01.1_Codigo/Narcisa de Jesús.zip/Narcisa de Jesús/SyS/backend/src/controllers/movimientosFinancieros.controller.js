import {
    obtenerMovimientosService,
    obtenerMovimientoPorIdService,
    crearMovimientoService,
    actualizarMovimientoService,
    eliminarMovimientoService
} from '../services/movimientosFinancieros.service.js';
import { puedeEditarFondo, puedeEditarMovimientoDeFondo } from '../services/fondos.service.js';
import { obtenerFondoPorIdRepository } from '../repositories/fondos.repository.js';
import { obtenerMovimientoPorIdRepository } from '../repositories/movimientosFinancieros.repository.js';
import { crearNotificacionService } from '../services/notificaciones.service.js';
import { obtenerUsuariosService } from '../services/usuarios.service.js';

/**
 * Cuando el Sacerdote crea o edita un movimiento financiero, el tesorero dueño del
 * fondo no tiene forma de enterarse salvo revisando manualmente. Se notifica solo
 * al tesorero cuyo alcance coincide con el del fondo afectado: si el fondo es de
 * una capilla (Virgen de Fátima, etc.), solo al tesorero de ESA capilla; si el fondo
 * es parroquial (sin capilla), solo al tesorero general — nunca a ambos a la vez.
 */
const notificarTesoreroPorMovimientoDelSacerdote = async(movimiento, fondo, accion) => {
    const tesoreros = await obtenerUsuariosService({ rol: 'Tesorero', activo: true });
    // El alcance sí se resuelve en memoria: un fondo parroquial tiene id_capilla null y
    // el filtro del repositorio no puede expresar "capilla nula" (ignora los valores falsy).
    const idCapillaFondo = fondo?.id_capilla ?? null;
    const tesorerosDelAlcance = tesoreros.filter((t) => (t.id_capilla ?? null) === idCapillaFondo);

    const nombreFondo = fondo?.nombre ?? 'un fondo';
    const mensaje = `El sacerdote ${accion} el movimiento "${movimiento.categoria ?? movimiento.tipo}" de ${nombreFondo} por $${Number(movimiento.monto).toFixed(2)}.`;

    await Promise.all(tesorerosDelAlcance.map((t) =>
        crearNotificacionService(t.id_usuario, `Movimiento financiero ${accion} por el sacerdote`, mensaje)
    ));
};

export const listarMovimientos = async(req, res) => {
    try {
        const { id_fondo, tipo, fecha_desde, fecha_hasta } = req.query;

        const movimientos = await obtenerMovimientosService(
            { id_fondo, tipo, fecha_desde, fecha_hasta }, req.usuario
        );

        res.json({
            mensaje: 'Listado de movimientos financieros',
            total: movimientos.length,
            movimientos
        });
    } catch (error) {
        res.status(500).json({
            mensaje: 'Error al listar movimientos financieros',
            error: error.message
        });
    }
};

export const buscarMovimientoPorId = async(req, res) => {
    try {
        const id = Number(req.params.id);

        const movimiento = await obtenerMovimientoPorIdService(id);

        if (!movimiento) {
            return res.status(404).json({
                mensaje: 'Movimiento financiero no encontrado'
            });
        }

        res.json({
            mensaje: 'Movimiento financiero encontrado',
            movimiento
        });
    } catch (error) {
        res.status(500).json({
            mensaje: 'Error al buscar movimiento financiero',
            error: error.message
        });
    }
};

export const registrarMovimiento = async(req, res) => {
    try {
        const { tipo, categoria, descripcion, id_fondo, monto, fecha, justificacion } = req.body;

        if (!tipo || !id_fondo || monto === undefined || !fecha) {
            return res.status(400).json({
                mensaje: 'Los campos tipo, id_fondo, monto y fecha son obligatorios'
            });
        }

        if (Number(monto) <= 0) {
            return res.status(400).json({
                mensaje: 'El monto debe ser mayor a cero'
            });
        }

        const fondoDestino = await obtenerFondoPorIdRepository(Number(id_fondo));

        if (!puedeEditarFondo(req.usuario, fondoDestino)) {
            return res.status(403).json({
                mensaje: 'No tiene permisos para registrar movimientos en este fondo'
            });
        }

        const movimiento = await crearMovimientoService({
            tipo, categoria, descripcion, id_fondo, monto, fecha, justificacion
        }, req.usuario);

        if (req.usuario.rol === 'Sacerdote') {
            await notificarTesoreroPorMovimientoDelSacerdote(movimiento, fondoDestino, 'registró');
        }

        res.status(201).json({
            mensaje: 'Movimiento financiero registrado correctamente',
            movimiento
        });
    } catch (error) {
        res.status(400).json({
            mensaje: 'Error al registrar movimiento financiero',
            error: error.message
        });
    }
};

export const editarMovimiento = async(req, res) => {
    try {
        const id = Number(req.params.id);
        const { tipo, categoria, descripcion, id_fondo, monto, fecha, justificacion } = req.body;

        if (!tipo || !id_fondo || monto === undefined || !fecha) {
            return res.status(400).json({
                mensaje: 'Los campos tipo, id_fondo, monto y fecha son obligatorios'
            });
        }

        const movimientoActual = await obtenerMovimientoPorIdRepository(id);

        if (!movimientoActual) {
            return res.status(404).json({
                mensaje: 'Movimiento financiero no encontrado'
            });
        }

        const fondoActual = await obtenerFondoPorIdRepository(movimientoActual.id_fondo);
        const fondoDestino = await obtenerFondoPorIdRepository(Number(id_fondo));

        if (!puedeEditarMovimientoDeFondo(req.usuario, fondoActual) || !puedeEditarMovimientoDeFondo(req.usuario, fondoDestino)) {
            return res.status(403).json({
                mensaje: 'No tiene permisos para editar movimientos de este fondo'
            });
        }

        const movimiento = await actualizarMovimientoService(id, {
            tipo, categoria, descripcion, id_fondo, monto, fecha, justificacion
        }, req.usuario);

        if (req.usuario.rol === 'Sacerdote') {
            await notificarTesoreroPorMovimientoDelSacerdote(movimiento, fondoDestino, 'modificó');
        }

        res.json({
            mensaje: 'Movimiento financiero actualizado correctamente',
            movimiento
        });
    } catch (error) {
        res.status(400).json({
            mensaje: 'Error al actualizar movimiento financiero',
            error: error.message
        });
    }
};

export const borrarMovimiento = async(req, res) => {
    try {
        const id = Number(req.params.id);

        const movimiento = await eliminarMovimientoService(id, req.usuario);

        if (!movimiento) {
            return res.status(404).json({
                mensaje: 'Movimiento financiero no encontrado'
            });
        }

        res.json({
            mensaje: 'Movimiento financiero eliminado correctamente',
            movimiento
        });
    } catch (error) {
        res.status(500).json({
            mensaje: 'Error al eliminar movimiento financiero',
            error: error.message
        });
    }
};
