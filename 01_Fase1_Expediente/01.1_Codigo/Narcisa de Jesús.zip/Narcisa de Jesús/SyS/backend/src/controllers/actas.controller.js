import {
    obtenerActasService,
    obtenerActaPorIdService,
    crearActaService,
    actualizarActaService,
    eliminarActaService
} from '../services/actas.service.js';

export const listarActas = async(req, res) => {
    try {
        const { id_capilla, tipo } = req.query;

        const actas = await obtenerActasService({ id_capilla, tipo }, req.usuario);

        res.json({
            mensaje: 'Listado de actas',
            total: actas.length,
            actas
        });
    } catch (error) {
        res.status(500).json({
            mensaje: 'Error al listar actas',
            error: error.message
        });
    }
};

export const buscarActaPorId = async(req, res) => {
    try {
        const id = Number(req.params.id);

        const acta = await obtenerActaPorIdService(id);

        if (!acta) {
            return res.status(404).json({
                mensaje: 'Acta no encontrada'
            });
        }

        // El Coordinador no puede leer el detalle de un acta de otra capilla.
        if (req.usuario.rol === 'Coordinador' && acta.id_capilla !== null && acta.id_capilla !== req.usuario.id_capilla) {
            return res.status(403).json({
                mensaje: 'No tiene permisos para ver esta acta'
            });
        }

        res.json({
            mensaje: 'Acta encontrada',
            acta
        });
    } catch (error) {
        res.status(500).json({
            mensaje: 'Error al buscar acta',
            error: error.message
        });
    }
};

export const registrarActa = async(req, res) => {
    try {
        const { titulo, tipo, id_capilla, lugar, descripcion, asistentes, fecha, proxima_reunion } = req.body;

        if (!titulo || !tipo || !fecha) {
            return res.status(400).json({
                mensaje: 'Los campos titulo, tipo y fecha son obligatorios'
            });
        }

        const hoy = new Date();
        hoy.setHours(0, 0, 0, 0);
        const fechaActa = new Date(fecha + 'T00:00:00');

        if (fechaActa < hoy) {
            return res.status(400).json({
                mensaje: 'La fecha del acta no puede ser anterior a la fecha actual'
            });
        }

        if (proxima_reunion) {
            const fechaProxima = new Date(proxima_reunion + 'T00:00:00');
            if (fechaProxima < fechaActa) {
                return res.status(400).json({
                    mensaje: 'La próxima reunión no puede ser anterior a la fecha del acta'
                });
            }
            const diffDias = (fechaProxima - fechaActa) / (1000 * 60 * 60 * 24);
            if (diffDias > 40) {
                return res.status(400).json({
                    mensaje: 'La próxima reunión no puede alejarse más de 40 días de la fecha del acta'
                });
            }
        }

        const acta = await crearActaService({
            titulo, tipo, id_capilla, lugar, descripcion, asistentes, fecha, proxima_reunion
        }, req.usuario);

        res.status(201).json({
            mensaje: 'Acta registrada correctamente',
            acta
        });
    } catch (error) {
        res.status(403).json({
            mensaje: 'Error al registrar acta',
            error: error.message
        });
    }
};

export const editarActa = async(req, res) => {
    try {
        const id = Number(req.params.id);
        const { titulo, tipo, id_capilla, lugar, descripcion, asistentes, fecha, proxima_reunion, estado } = req.body;

        if (!titulo || !tipo || !fecha) {
            return res.status(400).json({
                mensaje: 'Los campos titulo, tipo y fecha son obligatorios'
            });
        }

        // A diferencia del registro, aquí NO se valida que la fecha no sea anterior a hoy:
        // el acta que se está editando puede ser legítimamente de una reunión ya pasada
        // (se corrige la descripción, asistentes, etc.), y eso es válido.
        const fechaActa = new Date(fecha + 'T00:00:00');

        if (proxima_reunion) {
            const fechaProxima = new Date(proxima_reunion + 'T00:00:00');
            if (fechaProxima < fechaActa) {
                return res.status(400).json({
                    mensaje: 'La próxima reunión no puede ser anterior a la fecha del acta'
                });
            }
            const diffDias = (fechaProxima - fechaActa) / (1000 * 60 * 60 * 24);
            if (diffDias > 40) {
                return res.status(400).json({
                    mensaje: 'La próxima reunión no puede alejarse más de 40 días de la fecha del acta'
                });
            }
        }

        const acta = await actualizarActaService(id, {
            titulo, tipo, id_capilla, lugar, descripcion, asistentes, fecha, proxima_reunion, estado
        }, req.usuario);

        if (!acta) {
            return res.status(404).json({
                mensaje: 'Acta no encontrada'
            });
        }

        res.json({
            mensaje: 'Acta actualizada correctamente',
            acta
        });
    } catch (error) {
        res.status(403).json({
            mensaje: 'Error al actualizar acta',
            error: error.message
        });
    }
};

export const borrarActa = async(req, res) => {
    try {
        const id = Number(req.params.id);

        const acta = await eliminarActaService(id);

        if (!acta) {
            return res.status(404).json({
                mensaje: 'Acta no encontrada'
            });
        }

        res.json({
            mensaje: 'Acta eliminada correctamente',
            acta
        });
    } catch (error) {
        res.status(500).json({
            mensaje: 'Error al eliminar acta',
            error: error.message
        });
    }
};
