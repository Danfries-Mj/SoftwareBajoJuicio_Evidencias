import {
    obtenerHistorialPorInscritoService,
    obtenerHistorialPorIdService,
    crearHistorialInscritoService
} from '../services/historialInscrito.service.js';

export const listarHistorialPorInscrito = async(req, res) => {
    try {
        const idInscrito = Number(req.params.idInscrito);

        const historial = await obtenerHistorialPorInscritoService(idInscrito);

        res.json({
            mensaje: 'Historial del inscrito',
            total: historial.length,
            historial
        });
    } catch (error) {
        res.status(500).json({
            mensaje: 'Error al listar historial del inscrito',
            error: error.message
        });
    }
};

export const buscarHistorialPorId = async(req, res) => {
    try {
        const id = Number(req.params.id);

        const registro = await obtenerHistorialPorIdService(id);

        if (!registro) {
            return res.status(404).json({
                mensaje: 'Registro de historial no encontrado'
            });
        }

        res.json({
            mensaje: 'Registro de historial encontrado',
            registro
        });
    } catch (error) {
        res.status(500).json({
            mensaje: 'Error al buscar registro de historial',
            error: error.message
        });
    }
};

export const registrarHistorialInscrito = async(req, res) => {
    try {
        const { id_inscrito, comprobante, estado_anterior, estado_nuevo, nota } = req.body;

        if (!id_inscrito || !estado_nuevo) {
            return res.status(400).json({
                mensaje: 'Los campos id_inscrito y estado_nuevo son obligatorios'
            });
        }

        const registro = await crearHistorialInscritoService({
            id_inscrito, comprobante, estado_anterior, estado_nuevo, nota
        });

        res.status(201).json({
            mensaje: 'Historial registrado correctamente',
            registro
        });
    } catch (error) {
        res.status(500).json({
            mensaje: 'Error al registrar historial',
            error: error.message
        });
    }
};
