import 'dotenv/config';

const secret = process.env.JWT_SECRET;

if (!secret) {
    throw new Error('JWT_SECRET no está definido en el entorno (.env)');
}

export const jwtConfig = {
    secret,
    expiresIn: process.env.JWT_EXPIRA_EN || '8h'
};
