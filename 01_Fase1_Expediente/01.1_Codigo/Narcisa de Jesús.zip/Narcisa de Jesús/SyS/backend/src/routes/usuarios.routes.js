import { Router } from 'express';

import {
    listarUsuarios,
    buscarUsuarioPorId,
    buscarUsuarioPorCedula,
    registrarUsuario,
    editarUsuario,
    editarPerfilPropio,
    desactivarUsuario,
    activarUsuario
} from '../controllers/usuarios.controller.js';
import { verificarToken, autorizarRoles } from '../middlewares/auth.middleware.js';

const router = Router();

router.use(verificarToken);

router.get('/', autorizarRoles('Sacerdote', 'Coordinador'), listarUsuarios);
router.get('/cedula/:cedula', autorizarRoles('Laico', 'Sacerdote', 'Catequista', 'Coordinador'), buscarUsuarioPorCedula);
router.get('/:id', autorizarRoles('Sacerdote'), buscarUsuarioPorId);
router.post('/', autorizarRoles('Sacerdote'), registrarUsuario);
router.put('/:id', autorizarRoles('Sacerdote'), editarUsuario);
router.put('/:id/perfil', editarPerfilPropio);
router.put('/:id/desactivar', autorizarRoles('Sacerdote'), desactivarUsuario);
router.put('/:id/activar', autorizarRoles('Sacerdote'), activarUsuario);

export default router;
