import { Router } from 'express';

import {
    listarDonaciones,
    buscarDonacionPorId,
    registrarDonacion,
    aprobarDonacion,
    rechazarDonacion,
    borrarDonacion
} from '../controllers/donaciones.controller.js';
import { verificarToken, autorizarRoles } from '../middlewares/auth.middleware.js';

const router = Router();

router.use(verificarToken);

router.get('/', autorizarRoles('Laico', 'Tesorero', 'Sacerdote'), listarDonaciones);
router.get('/:id', autorizarRoles('Laico', 'Tesorero', 'Sacerdote'), buscarDonacionPorId);
router.post('/', autorizarRoles('Laico'), registrarDonacion);
router.put('/:id/aprobar', autorizarRoles('Tesorero', 'Sacerdote'), aprobarDonacion);
router.put('/:id/rechazar', autorizarRoles('Tesorero', 'Sacerdote'), rechazarDonacion);
router.delete('/:id', autorizarRoles('Sacerdote'), borrarDonacion);

export default router;
