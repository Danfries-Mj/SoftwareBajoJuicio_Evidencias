import { Router } from 'express';

import {
    listarComunicadosPublicos,
    listarComunicados,
    buscarComunicadoPorId,
    registrarComunicado,
    editarComunicado,
    borrarComunicado
} from '../controllers/comunicados.controller.js';
import { verificarToken, autorizarRoles } from '../middlewares/auth.middleware.js';

const router = Router();

router.get('/', listarComunicadosPublicos);

export default router;

const adminRouter = Router();

adminRouter.use(verificarToken, autorizarRoles('Coordinador', 'Sacerdote'));

adminRouter.get('/', listarComunicados);
adminRouter.get('/:id', buscarComunicadoPorId);
adminRouter.post('/', registrarComunicado);
adminRouter.put('/:id', editarComunicado);
adminRouter.delete('/:id', autorizarRoles('Sacerdote'), borrarComunicado);

export const comunicadosAdminRoutes = adminRouter;
