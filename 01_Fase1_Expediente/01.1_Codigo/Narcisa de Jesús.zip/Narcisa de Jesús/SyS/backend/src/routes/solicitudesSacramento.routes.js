import { Router } from 'express';

import {
    listarSolicitudes,
    buscarSolicitudPorId,
    registrarSolicitud,
    asignarSolicitud,
    aprobarSolicitud,
    rechazarSolicitud,
    borrarSolicitud,
    verificarSolicitudDuplicada
} from '../controllers/solicitudesSacramento.controller.js';
import { verificarToken, autorizarRoles } from '../middlewares/auth.middleware.js';

const router = Router();

router.use(verificarToken);

router.get('/', autorizarRoles('Laico', 'Sacerdote', 'Catequista'), listarSolicitudes);
router.get('/verificar-duplicada', autorizarRoles('Laico', 'Sacerdote', 'Catequista'), verificarSolicitudDuplicada);
router.get('/:id', autorizarRoles('Laico', 'Sacerdote', 'Catequista'), buscarSolicitudPorId);
router.post('/', autorizarRoles('Laico'), registrarSolicitud);
router.put('/:id/asignar', autorizarRoles('Sacerdote'), asignarSolicitud);
router.put('/:id/aprobar', autorizarRoles('Catequista'), aprobarSolicitud);
router.put('/:id/rechazar', autorizarRoles('Sacerdote', 'Catequista'), rechazarSolicitud);
router.delete('/:id', autorizarRoles('Sacerdote'), borrarSolicitud);

export default router;
