import { Router } from 'express';
import {
    listarNotificaciones,
    marcarLeida,
    marcarTodasLeidas,
    enviarNotificacionMiembros
} from '../controllers/notificaciones.controller.js';
import { verificarToken, autorizarRoles } from '../middlewares/auth.middleware.js';

const router = Router();

router.use(verificarToken);

router.get('/', listarNotificaciones);
router.post('/enviar-miembros', autorizarRoles('Coordinador'), enviarNotificacionMiembros);
router.put('/leer-todas', marcarTodasLeidas);
router.put('/:id/leer', marcarLeida);

export default router;
