import { Router } from 'express';
import { listarEstadisticasPublicas } from '../controllers/estadisticas.controller.js';

const router = Router();

// Público: usado por la página "Sobre Nosotros". Solo expone conteos agregados, nunca
// listados ni datos personales, así que no requiere sesión.
router.get('/publicas', listarEstadisticasPublicas);

export default router;
