import { Router } from 'express';

import {
    listarFondos,
    buscarFondoPorId,
    registrarFondo,
    editarFondo,
    borrarFondo
} from '../controllers/fondos.controller.js';
import { verificarToken, autorizarRoles } from '../middlewares/auth.middleware.js';

const router = Router();

router.use(verificarToken, autorizarRoles('Tesorero', 'Coordinador', 'Sacerdote'));

router.get('/', listarFondos);
router.get('/:id', buscarFondoPorId);
router.post('/', autorizarRoles('Sacerdote'), registrarFondo);
router.put('/:id', autorizarRoles('Sacerdote', 'Tesorero'), editarFondo);
router.delete('/:id', autorizarRoles('Sacerdote'), borrarFondo);

export default router;
