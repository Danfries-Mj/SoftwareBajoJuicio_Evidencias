import { Router } from 'express';

import {
    listarCierres,
    buscarCierrePorId,
    registrarCierre,
    borrarCierre
} from '../controllers/cierresMes.controller.js';
import { verificarToken, autorizarRoles } from '../middlewares/auth.middleware.js';

const router = Router();

router.use(verificarToken, autorizarRoles('Tesorero', 'Sacerdote'));

router.get('/', listarCierres);
router.get('/:id', buscarCierrePorId);
router.post('/', registrarCierre);
router.delete('/:id', autorizarRoles('Sacerdote'), borrarCierre);

export default router;
