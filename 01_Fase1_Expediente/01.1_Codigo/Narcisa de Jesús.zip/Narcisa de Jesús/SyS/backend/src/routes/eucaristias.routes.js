import { Router } from 'express';

import {
    listarEucaristias,
    buscarEucaristiaPorId,
    registrarEucaristia,
    editarEucaristia,
    marcarEucaristiasComoRealizadas,
    borrarEucaristia
} from '../controllers/eucaristias.controller.js';
import { verificarToken, autorizarRoles } from '../middlewares/auth.middleware.js';

const router = Router();

router.get('/', listarEucaristias);
// Antes de '/:id': si no, Express interpreta "marcar-realizadas" como un :id.
router.put('/marcar-realizadas', verificarToken, autorizarRoles('Sacerdote'), marcarEucaristiasComoRealizadas);
router.get('/:id', buscarEucaristiaPorId);
router.post('/', verificarToken, autorizarRoles('Sacerdote'), registrarEucaristia);
router.put('/:id', verificarToken, autorizarRoles('Sacerdote'), editarEucaristia);
router.delete('/:id', verificarToken, autorizarRoles('Sacerdote'), borrarEucaristia);

export default router;
