import { Router } from 'express';

import {
    listarHistorialPorInscrito,
    buscarHistorialPorId,
    registrarHistorialInscrito
} from '../controllers/historialInscrito.controller.js';
import { verificarToken, autorizarRoles } from '../middlewares/auth.middleware.js';

const router = Router();

router.use(verificarToken, autorizarRoles('Catequista', 'Coordinador', 'Sacerdote'));

router.get('/inscrito/:idInscrito', listarHistorialPorInscrito);
router.get('/:id', buscarHistorialPorId);
router.post('/', registrarHistorialInscrito);

export default router;
