import { Router } from 'express';

import {
    listarBeneficiariosPorSolicitud,
    registrarBeneficiario,
    borrarBeneficiario
} from '../controllers/beneficiariosSolicitud.controller.js';
import { verificarToken, autorizarRoles } from '../middlewares/auth.middleware.js';

const router = Router();

router.use(verificarToken);

router.get('/solicitud/:idSolicitud', listarBeneficiariosPorSolicitud);
router.post('/', registrarBeneficiario);
router.delete('/:id', autorizarRoles('Sacerdote'), borrarBeneficiario);

export default router;
