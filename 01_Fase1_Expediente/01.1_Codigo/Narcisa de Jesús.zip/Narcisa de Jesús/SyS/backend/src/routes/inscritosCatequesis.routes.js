import { Router } from 'express';

import {
    listarInscritos,
    buscarInscritoPorId,
    registrarInscrito,
    editarInscrito,
    borrarInscrito
} from '../controllers/inscritosCatequesis.controller.js';
import { verificarToken, autorizarRoles } from '../middlewares/auth.middleware.js';

const router = Router();

router.use(verificarToken, autorizarRoles('Catequista', 'Coordinador', 'Sacerdote', 'Tesorero'));

router.get('/', listarInscritos);
router.get('/:id', buscarInscritoPorId);
router.post('/', autorizarRoles('Catequista', 'Coordinador', 'Sacerdote'), registrarInscrito);
router.put('/:id', editarInscrito);
router.delete('/:id', autorizarRoles('Catequista', 'Coordinador', 'Sacerdote'), borrarInscrito);

export default router;
