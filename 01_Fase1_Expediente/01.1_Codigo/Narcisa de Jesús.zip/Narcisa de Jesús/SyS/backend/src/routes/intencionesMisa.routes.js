import { Router } from 'express';

import {
    listarIntenciones,
    buscarIntencionPorId,
    registrarIntencion,
    asignarIntencion,
    rechazarIntencion,
    borrarIntencion
} from '../controllers/intencionesMisa.controller.js';
import { verificarToken, autorizarRoles } from '../middlewares/auth.middleware.js';

const router = Router();

router.use(verificarToken);

router.get('/', autorizarRoles('Laico', 'Sacerdote'), listarIntenciones);
router.get('/:id', autorizarRoles('Laico', 'Sacerdote'), buscarIntencionPorId);
router.post('/', autorizarRoles('Laico'), registrarIntencion);
router.put('/:id/asignar', autorizarRoles('Sacerdote'), asignarIntencion);
router.put('/:id/rechazar', autorizarRoles('Sacerdote'), rechazarIntencion);
router.delete('/:id', autorizarRoles('Sacerdote'), borrarIntencion);

export default router;
