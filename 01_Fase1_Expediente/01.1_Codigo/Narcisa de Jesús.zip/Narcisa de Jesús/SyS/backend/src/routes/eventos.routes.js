import { Router } from 'express';

import {
    listarEventos,
    buscarEventoPorId,
    registrarEvento,
    editarEvento,
    borrarEvento
} from '../controllers/eventos.controller.js';
import { verificarToken, autorizarRoles } from '../middlewares/auth.middleware.js';

const router = Router();

router.get('/', listarEventos);
router.get('/:id', buscarEventoPorId);
router.post('/', verificarToken, autorizarRoles('Coordinador', 'Sacerdote'), registrarEvento);
router.put('/:id', verificarToken, autorizarRoles('Coordinador', 'Sacerdote'), editarEvento);
router.delete('/:id', verificarToken, autorizarRoles('Coordinador', 'Sacerdote'), borrarEvento);

export default router;
