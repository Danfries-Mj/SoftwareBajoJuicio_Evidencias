import { Router } from 'express';

import {
    listarInscripciones,
    buscarInscripcionPorId,
    registrarInscripcion,
    aprobarInscripcion,
    rechazarInscripcion,
    borrarInscripcion
} from '../controllers/inscripcionesCatequesis.controller.js';
import { verificarToken, autorizarRoles } from '../middlewares/auth.middleware.js';

const router = Router();

router.use(verificarToken);

router.get('/', autorizarRoles('Laico', 'Catequista', 'Coordinador', 'Sacerdote', 'Tesorero'), listarInscripciones);
router.get('/:id', autorizarRoles('Laico', 'Catequista', 'Coordinador', 'Sacerdote', 'Tesorero'), buscarInscripcionPorId);
router.post('/', autorizarRoles('Laico', 'Catequista', 'Coordinador', 'Sacerdote'), registrarInscripcion);
router.put('/:id/aprobar', autorizarRoles('Catequista', 'Coordinador', 'Sacerdote'), aprobarInscripcion);
router.put('/:id/rechazar', autorizarRoles('Catequista', 'Coordinador', 'Sacerdote'), rechazarInscripcion);
router.delete('/:id', autorizarRoles('Sacerdote'), borrarInscripcion);

export default router;
