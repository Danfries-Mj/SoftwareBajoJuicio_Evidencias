import { Router } from 'express';

import {
    listarActas,
    buscarActaPorId,
    registrarActa,
    editarActa,
    borrarActa
} from '../controllers/actas.controller.js';
import { verificarToken, autorizarRoles } from '../middlewares/auth.middleware.js';

const router = Router();

router.use(verificarToken, autorizarRoles('Coordinador', 'Tesorero', 'Sacerdote'));

router.get('/', listarActas);
router.get('/:id', buscarActaPorId);
router.post('/', autorizarRoles('Coordinador', 'Sacerdote'), registrarActa);
router.put('/:id', autorizarRoles('Coordinador', 'Sacerdote'), editarActa);
router.delete('/:id', autorizarRoles('Sacerdote'), borrarActa);

export default router;
