import { Router } from 'express';

import {
    listarCapillas,
    buscarCapillaPorId,
    registrarCapilla,
    editarCapilla,
    borrarCapilla
} from '../controllers/capillas.controller.js';
import { verificarToken, autorizarRoles } from '../middlewares/auth.middleware.js';

const router = Router();

router.get('/', listarCapillas);
router.get('/:id', buscarCapillaPorId);
router.post('/', verificarToken, autorizarRoles('Sacerdote'), registrarCapilla);
router.put('/:id', verificarToken, autorizarRoles('Sacerdote'), editarCapilla);
router.delete('/:id', verificarToken, autorizarRoles('Sacerdote'), borrarCapilla);

export default router;
