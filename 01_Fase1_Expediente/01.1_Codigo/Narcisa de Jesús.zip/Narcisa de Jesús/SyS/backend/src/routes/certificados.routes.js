import { Router } from 'express';

import {
    listarCertificados,
    buscarCertificadoPorId,
    verificarPrerequisitoCertificado,
    registrarCertificado,
    emitirCertificado,
    rechazarCertificado,
    borrarCertificado
} from '../controllers/certificados.controller.js';
import { verificarToken, autorizarRoles } from '../middlewares/auth.middleware.js';

const router = Router();

router.use(verificarToken);

router.get('/', autorizarRoles('Laico', 'Sacerdote', 'Catequista', 'Coordinador'), listarCertificados);
router.get('/verificar-prerequisito', autorizarRoles('Laico', 'Sacerdote', 'Catequista', 'Coordinador'), verificarPrerequisitoCertificado);
router.get('/:id', autorizarRoles('Laico', 'Sacerdote'), buscarCertificadoPorId);
// El Catequista y el Coordinador también pueden adjuntar el certificado prerrequisito al
// registrar un nuevo inscrito en catequesis, cuando la persona todavía no lo tiene emitido.
router.post('/', autorizarRoles('Laico', 'Sacerdote', 'Catequista', 'Coordinador'), registrarCertificado);
router.put('/:id/emitir', autorizarRoles('Sacerdote'), emitirCertificado);
router.put('/:id/rechazar', autorizarRoles('Sacerdote'), rechazarCertificado);
router.delete('/:id', autorizarRoles('Sacerdote'), borrarCertificado);

export default router;
