import { Router } from 'express';

import {
    listarPersonas,
    buscarPersonaPorId,
    buscarPersonaPorCedula,
    registrarPersona,
    editarPersona,
    borrarPersona
} from '../controllers/personas.controller.js';
import { verificarToken, autorizarRoles } from '../middlewares/auth.middleware.js';

const router = Router();

router.use(verificarToken);

// El Catequista y el Coordinador también buscan por cédula al registrar un nuevo
// inscrito en catequesis (autocompletar datos y verificar su certificado prerrequisito).
router.get('/cedula/:cedula', autorizarRoles('Laico', 'Sacerdote', 'Catequista', 'Coordinador'), buscarPersonaPorCedula);
// Un Laico necesita poder registrar la persona (tercero) que inscribe a un sacramento
// cuando esa cédula todavía no existe en el sistema (no tiene cuenta de usuario).
router.post('/', registrarPersona);

router.use(autorizarRoles('Sacerdote'));

router.get('/', listarPersonas);
router.get('/:id', buscarPersonaPorId);
router.put('/:id', editarPersona);
router.delete('/:id', borrarPersona);

export default router;
