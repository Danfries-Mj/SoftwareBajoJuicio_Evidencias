import { Router } from 'express';

import { listarAuditoria, buscarAuditoriaPorId } from '../controllers/auditoria.controller.js';
import { verificarToken, autorizarRoles } from '../middlewares/auth.middleware.js';

const router = Router();

router.use(verificarToken, autorizarRoles('Sacerdote'));

router.get('/', listarAuditoria);
router.get('/:id', buscarAuditoriaPorId);

export default router;
