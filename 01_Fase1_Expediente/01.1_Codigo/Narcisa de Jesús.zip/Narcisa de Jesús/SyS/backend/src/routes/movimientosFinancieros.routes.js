import { Router } from 'express';

import {
    listarMovimientos,
    buscarMovimientoPorId,
    registrarMovimiento,
    editarMovimiento,
    borrarMovimiento
} from '../controllers/movimientosFinancieros.controller.js';
import { verificarToken, autorizarRoles } from '../middlewares/auth.middleware.js';

const router = Router();

router.use(verificarToken, autorizarRoles('Tesorero', 'Coordinador', 'Sacerdote'));

router.get('/', listarMovimientos);
router.get('/:id', buscarMovimientoPorId);
router.post('/', registrarMovimiento);
router.put('/:id', autorizarRoles('Tesorero', 'Sacerdote'), editarMovimiento);
router.delete('/:id', autorizarRoles('Sacerdote'), borrarMovimiento);

export default router;
