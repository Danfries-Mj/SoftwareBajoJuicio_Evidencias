import { Router } from 'express';

import {
    listarDocumentos,
    buscarDocumentoPorId,
    registrarDocumento,
    borrarDocumento
} from '../controllers/documentos.controller.js';
import { verificarToken } from '../middlewares/auth.middleware.js';

const router = Router();

router.use(verificarToken);

router.get('/', listarDocumentos);
router.get('/:id', buscarDocumentoPorId);
router.post('/', registrarDocumento);
router.delete('/:id', borrarDocumento);

export default router;
