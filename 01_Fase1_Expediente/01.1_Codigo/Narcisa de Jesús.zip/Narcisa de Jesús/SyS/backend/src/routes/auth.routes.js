import { Router } from 'express';

import {
    iniciarSesion,
    registrarLaico,
    cedulaDisponible,
    olvideContrasena,
    restablecerContrasena
} from '../controllers/auth.controller.js';

const router = Router();

router.post('/login', iniciarSesion);
router.post('/registro', registrarLaico);
router.get('/cedula-disponible/:cedula', cedulaDisponible);
router.post('/olvide-contrasena', olvideContrasena);
router.post('/restablecer-contrasena', restablecerContrasena);

export default router;
