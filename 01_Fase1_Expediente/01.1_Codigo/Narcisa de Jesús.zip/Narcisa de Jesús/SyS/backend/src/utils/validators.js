/** Algoritmo módulo 10 oficial para validar una cédula ecuatoriana de 10 dígitos. */
export function cedulaValida(cedula) {
    if (typeof cedula !== 'string' || !/^\d{10}$/.test(cedula)) {
        return false;
    }

    const digitos = cedula.split('').map(Number);
    const provincia = digitos[0] * 10 + digitos[1];
    if (provincia < 1 || provincia > 24) {
        return false;
    }
    if (digitos[2] > 6) {
        return false;
    }

    const coeficientes = [2, 1, 2, 1, 2, 1, 2, 1, 2];
    let suma = 0;
    for (let i = 0; i < 9; i++) {
        let valor = digitos[i] * coeficientes[i];
        if (valor > 9) {
            valor -= 9;
        }
        suma += valor;
    }

    const decenaSuperior = Math.ceil(suma / 10) * 10;
    const digitoVerificador = decenaSuperior - suma === 10 ? 0 : decenaSuperior - suma;
    return digitoVerificador === digitos[9];
}
