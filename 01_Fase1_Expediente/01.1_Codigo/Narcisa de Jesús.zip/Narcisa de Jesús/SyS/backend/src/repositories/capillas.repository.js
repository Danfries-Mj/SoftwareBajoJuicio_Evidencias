import { pool } from '../database/connection.js';

export const obtenerCapillasRepository = async() => {
    const resultado = await pool.query(
        'SELECT * FROM vista_capillas ORDER BY id_capilla ASC'
    );

    return resultado.rows;
};

export const obtenerCapillaPorIdRepository = async(id) => {
    const resultado = await pool.query(
        'SELECT * FROM vista_capillas WHERE id_capilla = $1', [id]
    );

    return resultado.rows[0];
};

export const crearCapillaRepository = async(capilla) => {
    const { nombre, direccion, telefono } = capilla;

    const resultado = await pool.query(
        `SELECT * FROM fn_crear_capilla($1, $2, $3)`, [nombre, direccion, telefono]
    );

    return resultado.rows[0];
};

export const actualizarCapillaRepository = async(id, capilla) => {
    const { nombre, direccion, telefono, activa } = capilla;

    const resultado = await pool.query(
        `SELECT * FROM fn_actualizar_capilla($1, $2, $3, $4, $5)`, [id, nombre, direccion, telefono, activa]
    );

    return resultado.rows[0];
};

export const eliminarCapillaRepository = async(id) => {
    const resultado = await pool.query(
        `SELECT * FROM fn_eliminar_capilla($1)`, [id]
    );

    return resultado.rows[0];
};