import { pool } from '../database/connection.js';

const SELECT_EVENTO_BASE = `
    SELECT * FROM vista_eventos e
`;

export const obtenerEventosRepository = async(filtros = {}) => {
    const condiciones = [];
    const valores = [];

    if (filtros.id_capilla) {
        valores.push(filtros.id_capilla);
        condiciones.push(`e.id_capilla = $${valores.length}`);
    }

    if (filtros.tipo_ambito) {
        valores.push(filtros.tipo_ambito);
        condiciones.push(`e.tipo_ambito = $${valores.length}`);
    }

    if (filtros.estado) {
        valores.push(filtros.estado);
        condiciones.push(`e.estado = $${valores.length}`);
    }

    const whereClause = condiciones.length ? `WHERE ${condiciones.join(' AND ')}` : '';

    const resultado = await pool.query(
        `${SELECT_EVENTO_BASE} ${whereClause} ORDER BY e.fecha ASC`, valores
    );

    return resultado.rows;
};

export const obtenerEventoPorIdRepository = async(id) => {
    const resultado = await pool.query(
        `${SELECT_EVENTO_BASE} WHERE e.id_evento = $1`, [id]
    );

    return resultado.rows[0];
};

export const obtenerEucaristiaDuplicadaRepository = async(fecha, horaInicio, idExcluir = null) => {
    const valores = [fecha, horaInicio];
    let condicionExcluir = '';

    if (idExcluir) {
        valores.push(idExcluir);
        condicionExcluir = `AND id_evento <> $${valores.length}`;
    }

    const resultado = await pool.query(
        `SELECT * FROM eventos
         WHERE categoria = 'Eucaristia' AND fecha = $1 AND hora_inicio = $2 ${condicionExcluir}`,
        valores
    );

    return resultado.rows[0];
};

export const crearEventoRepository = async(evento) => {
    const {
        nombre, descripcion, tipo_ambito, categoria, id_capilla,
        fecha, hora_inicio, hora_fin, lugar, capacidad, estado, creado_por
    } = evento;

    const resultado = await pool.query(
        `SELECT * FROM fn_crear_evento($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12)`,
        [nombre, descripcion, tipo_ambito, categoria, id_capilla, fecha, hora_inicio, hora_fin, lugar, capacidad, estado, creado_por]
    );

    return resultado.rows[0];
};

export const actualizarEventoRepository = async(id, evento) => {
    const {
        nombre, descripcion, tipo_ambito, categoria, id_capilla,
        fecha, hora_inicio, hora_fin, lugar, capacidad, estado
    } = evento;

    const resultado = await pool.query(
        `SELECT * FROM fn_actualizar_evento($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12)`,
        [id, nombre, descripcion, tipo_ambito, categoria, id_capilla, fecha, hora_inicio, hora_fin, lugar, capacidad, estado]
    );

    return resultado.rows[0];
};

export const eliminarEventoRepository = async(id) => {
    const resultado = await pool.query(
        `SELECT * FROM fn_eliminar_evento($1)`, [id]
    );

    return resultado.rows[0];
};
