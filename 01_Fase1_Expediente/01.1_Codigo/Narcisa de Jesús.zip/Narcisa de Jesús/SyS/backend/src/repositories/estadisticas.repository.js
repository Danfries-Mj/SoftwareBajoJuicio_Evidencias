import { pool } from '../database/connection.js';

/**
 * Conteos públicos para la página "Sobre Nosotros" (sin autenticación, así que solo se
 * exponen números agregados, nunca listados ni datos personales).
 * - catequizandos: personas con al menos una inscripción de catequesis Activa en este
 *   momento (se cuenta por cédula distinta para no duplicar a quien esté Activo en más
 *   de un nivel a la vez).
 * - catequistas: usuarios con rol Catequista actualmente activos.
 * - capillas: capillas activas.
 */
export const obtenerEstadisticasPublicasRepository = async() => {
    const resultado = await pool.query('SELECT * FROM vista_estadisticas_publicas');

    const fila = resultado.rows[0];
    return {
        capillas: parseInt(fila.capillas, 10),
        catequizandos: parseInt(fila.catequizandos, 10),
        catequistas: parseInt(fila.catequistas, 10)
    };
};
