import { pool } from '../database/connection.js';

const SELECT_CERTIFICADO_BASE = `
    SELECT * FROM vista_certificados cert
`;

export const obtenerCertificadosRepository = async(filtros = {}) => {
    const condiciones = [];
    const valores = [];

    if (filtros.id_persona) {
        valores.push(filtros.id_persona);
        condiciones.push(`cert.id_persona = $${valores.length}`);
    }

    if (filtros.tipo) {
        valores.push(filtros.tipo);
        condiciones.push(`cert.tipo = $${valores.length}`);
    }

    if (filtros.estado) {
        valores.push(filtros.estado);
        condiciones.push(`cert.estado = $${valores.length}`);
    }

    const whereClause = condiciones.length ? `WHERE ${condiciones.join(' AND ')}` : '';

    const resultado = await pool.query(
        `${SELECT_CERTIFICADO_BASE} ${whereClause} ORDER BY cert.fecha_solicitud DESC`, valores
    );

    return resultado.rows;
};

export const obtenerCertificadoPrerequisitoRepository = async(id_persona, tipo) => {
    const resultado = await pool.query(
        `${SELECT_CERTIFICADO_BASE}
         WHERE cert.id_persona = $1
           AND cert.tipo = $2
           AND cert.estado = 'Emitido'
         ORDER BY cert.fecha_emision DESC
         LIMIT 1`, [id_persona, tipo]
    );

    return resultado.rows[0];
};

export const obtenerCertificadoPorIdRepository = async(id) => {
    const resultado = await pool.query(
        `${SELECT_CERTIFICADO_BASE} WHERE cert.id_certificado = $1`, [id]
    );

    return resultado.rows[0];
};

export const crearCertificadoRepository = async(certificado) => {
    const { id_persona, tipo, id_capilla, archivo_nombre, archivo_url, mime_type, estado, fecha_emision } = certificado;

    const resultado = await pool.query(
        `SELECT * FROM fn_crear_certificado($1, $2, $3, $4, $5, $6, $7, $8)`, [id_persona, tipo, id_capilla, archivo_nombre || null, archivo_url || null, mime_type || null, estado || 'Pendiente', fecha_emision || null]
    );

    return resultado.rows[0];
};

export const emitirCertificadoRepository = async(id, datos) => {
    const { fecha_emision, archivo_url, archivo_nombre, mime_type } = datos;

    const resultado = await pool.query(
        `SELECT * FROM fn_emitir_certificado($1, $2, $3, $4, $5)`, [id, fecha_emision, archivo_url, archivo_nombre, mime_type]
    );

    return resultado.rows[0];
};

export const rechazarCertificadoRepository = async(id) => {
    const resultado = await pool.query(
        `SELECT * FROM fn_rechazar_certificado($1)`, [id]
    );

    return resultado.rows[0];
};

export const eliminarCertificadoRepository = async(id) => {
    const resultado = await pool.query(
        `SELECT * FROM fn_eliminar_certificado($1)`, [id]
    );

    return resultado.rows[0];
};