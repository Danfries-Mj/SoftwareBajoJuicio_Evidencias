import { pool } from '../database/connection.js';

export const obtenerDocumentosRepository = async(filtros = {}) => {
    const condiciones = [];
    const valores = [];

    if (filtros.id_usuario) {
        valores.push(filtros.id_usuario);
        condiciones.push(`id_usuario = $${valores.length}`);
    }

    const whereClause = condiciones.length ? `WHERE ${condiciones.join(' AND ')}` : '';

    const resultado = await pool.query(
        `SELECT * FROM vista_documentos ${whereClause} ORDER BY fecha_subida DESC`, valores
    );

    return resultado.rows;
};

export const obtenerDocumentoPorIdRepository = async(id) => {
    const resultado = await pool.query(
        'SELECT * FROM vista_documentos WHERE id_documento = $1', [id]
    );

    return resultado.rows[0];
};

export const crearDocumentoRepository = async(documento) => {
    const { id_usuario, tipo, archivo_nombre, archivo_url, mime_type } = documento;

    const resultado = await pool.query(
        `SELECT * FROM fn_crear_documento($1, $2, $3, $4, $5)`,
        [id_usuario, tipo, archivo_nombre, archivo_url, mime_type]
    );

    return resultado.rows[0];
};

export const actualizarNombreDocumentoRepository = async(id, archivoNombre) => {
    const resultado = await pool.query(
        `SELECT * FROM fn_actualizar_nombre_documento($1, $2)`,
        [id, archivoNombre]
    );

    return resultado.rows[0];
};

export const eliminarDocumentoRepository = async(id) => {
    const resultado = await pool.query(
        `SELECT * FROM fn_eliminar_documento($1)`, [id]
    );

    return resultado.rows[0];
};
