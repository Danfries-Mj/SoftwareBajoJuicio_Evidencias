import { pool } from '../database/connection.js';

export const obtenerPersonasRepository = async() => {
    const resultado = await pool.query(
        'SELECT * FROM vista_persona ORDER BY id_persona ASC'
    );

    return resultado.rows;
};

export const obtenerPersonaPorIdRepository = async(id) => {
    const resultado = await pool.query(
        'SELECT * FROM vista_persona WHERE id_persona = $1', [id]
    );

    return resultado.rows[0];
};

export const obtenerPersonaPorCedulaRepository = async(cedula) => {
    const resultado = await pool.query(
        'SELECT * FROM vista_persona WHERE cedula = $1', [cedula]
    );

    return resultado.rows[0];
};

export const crearPersonaRepository = async(persona) => {
    const { cedula, nombres, apellidos, telefono } = persona;

    const resultado = await pool.query(
        `SELECT * FROM fn_crear_persona($1, $2, $3, $4)`,
        [cedula, nombres, apellidos, telefono]
    );

    return resultado.rows[0];
};

export const actualizarPersonaRepository = async(id, persona) => {
    const { nombres, apellidos, telefono } = persona;

    const resultado = await pool.query(
        `SELECT * FROM fn_actualizar_persona($1, $2, $3, $4)`,
        [id, nombres, apellidos, telefono]
    );

    return resultado.rows[0];
};

export const eliminarPersonaRepository = async(id) => {
    const resultado = await pool.query(
        `SELECT * FROM fn_eliminar_persona($1)`, [id]
    );

    return resultado.rows[0];
};
