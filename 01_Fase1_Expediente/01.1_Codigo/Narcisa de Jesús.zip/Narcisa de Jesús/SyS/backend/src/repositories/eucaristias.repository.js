import { pool } from '../database/connection.js';

const SELECT_EUCARISTIA_BASE = `
    SELECT * FROM vista_eucaristias e
`;

export const obtenerEucaristiasRepository = async(filtros = {}) => {
    const condiciones = [];
    const valores = [];

    if (filtros.id_capilla) {
        valores.push(filtros.id_capilla);
        condiciones.push(`e.id_capilla = $${valores.length}`);
    }

    if (filtros.dia_semana) {
        valores.push(filtros.dia_semana);
        condiciones.push(`e.dia_semana = $${valores.length}`);
    }

    if (filtros.estado) {
        valores.push(filtros.estado);
        condiciones.push(`e.estado = $${valores.length}`);
    }

    const whereClause = condiciones.length ? `WHERE ${condiciones.join(' AND ')}` : '';

    const resultado = await pool.query(
        `${SELECT_EUCARISTIA_BASE} ${whereClause} ORDER BY e.id_capilla ASC, e.hora_inicio ASC`, valores
    );

    return resultado.rows;
};

export const obtenerEucaristiaPorIdRepository = async(id) => {
    const resultado = await pool.query(
        `${SELECT_EUCARISTIA_BASE} WHERE e.id_eucaristia = $1`, [id]
    );

    return resultado.rows[0];
};

export const obtenerEucaristiaPorIdEventoRepository = async(idEvento) => {
    const resultado = await pool.query(
        `${SELECT_EUCARISTIA_BASE} WHERE e.id_evento = $1`, [idEvento]
    );

    return resultado.rows[0];
};

export const obtenerEucaristiaDuplicadaRepository = async(idCapilla, diaSemana, horaInicio, idExcluir = null) => {
    const valores = [idCapilla, diaSemana, horaInicio];
    let condicionExcluir = '';

    if (idExcluir) {
        valores.push(idExcluir);
        condicionExcluir = `AND id_eucaristia <> $${valores.length}`;
    }

    const resultado = await pool.query(
        `SELECT * FROM eucaristias
         WHERE id_capilla = $1 AND dia_semana = $2 AND hora_inicio = $3
           AND estado <> 'Cancelada' ${condicionExcluir}`, valores
    );

    return resultado.rows[0];
};

export const crearEucaristiaRepository = async(eucaristia) => {
    const { id_capilla, dia_semana, fecha, hora_inicio, hora_fin, id_sacerdote, estado, id_solicitud, id_evento } = eucaristia;

    const resultado = await pool.query(
        `SELECT * FROM fn_crear_eucaristia($1, $2, $3, $4, $5, $6, $7, $8, $9)`,
        [id_capilla, dia_semana, fecha, hora_inicio, hora_fin, id_sacerdote, estado, id_solicitud ?? null, id_evento ?? null]
    );

    return resultado.rows[0];
};

export const actualizarEucaristiaRepository = async(id, eucaristia) => {
    const { id_capilla, dia_semana, fecha, hora_inicio, hora_fin, id_sacerdote, estado, id_solicitud, id_evento } = eucaristia;

    const resultado = await pool.query(
        `SELECT * FROM fn_actualizar_eucaristia($1, $2, $3, $4, $5, $6, $7, $8, $9, $10)`,
        [id, id_capilla, dia_semana, fecha, hora_inicio, hora_fin, id_sacerdote, estado, id_solicitud ?? null, id_evento ?? null]
    );

    return resultado.rows[0];
};

/**
 * Marca como 'Realizada' toda eucaristía Activa/Programada cuya fecha ya pasó, o cuya
 * fecha es hoy pero su hora (hora_fin, o hora_inicio si no tiene fin) ya pasó. Una misa
 * de hoy programada más tarde en el día NO se toca, aunque sea "hoy".
 */
export const marcarPasadasComoRealizadasRepository = async() => {
    const resultado = await pool.query(
        `SELECT * FROM fn_marcar_eucaristias_pasadas_realizadas()`
    );

    return resultado.rows;
};

export const eliminarEucaristiaRepository = async(id) => {
    const resultado = await pool.query(
        `SELECT * FROM fn_eliminar_eucaristia($1)`, [id]
    );

    return resultado.rows[0];
};
