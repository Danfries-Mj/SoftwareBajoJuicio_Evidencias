import { pool } from '../database/connection.js';

const SELECT_INSCRITO_BASE = `
    SELECT * FROM vista_inscritos_catequesis ic
`;

export const obtenerInscritosRepository = async(filtros = {}) => {
    const condiciones = [];
    const valores = [];

    if (filtros.id_capilla) {
        valores.push(filtros.id_capilla);
        condiciones.push(`ic.id_capilla = $${valores.length}`);
    }

    if (filtros.nivel) {
        valores.push(filtros.nivel);
        condiciones.push(`ic.nivel = $${valores.length}`);
    }

    if (filtros.estado) {
        valores.push(filtros.estado);
        condiciones.push(`ic.estado = $${valores.length}`);
    }

    if (filtros.nombre) {
        valores.push(`%${filtros.nombre}%`);
        condiciones.push(`ic.nombres ILIKE $${valores.length}`);
    }

    const whereClause = condiciones.length ? `WHERE ${condiciones.join(' AND ')}` : '';

    const resultado = await pool.query(
        `${SELECT_INSCRITO_BASE} ${whereClause} ORDER BY ic.nombres ASC`, valores
    );

    return resultado.rows;
};

export const obtenerInscritoPorIdRepository = async(id) => {
    const resultado = await pool.query(
        `${SELECT_INSCRITO_BASE} WHERE ic.id_inscrito = $1`, [id]
    );

    return resultado.rows[0];
};

export const crearInscritoRepository = async(inscrito) => {
    const { id_inscripcion, cedula, nombres, nivel, id_capilla, id_catequista, fecha_inscripcion, monto, comprobante, estado } = inscrito;

    const resultado = await pool.query(
        `SELECT * FROM fn_crear_inscrito_catequesis($1, $2, $3, $4, $5, $6, $7, $8, $9, $10)`,
        [id_inscripcion, cedula, nombres, nivel, id_capilla, id_catequista, fecha_inscripcion, monto, comprobante, estado]
    );

    return resultado.rows[0];
};

export const actualizarInscritoRepository = async(id, inscrito) => {
    const { id_catequista, estado } = inscrito;

    const resultado = await pool.query(
        `SELECT * FROM fn_actualizar_inscrito_catequesis($1, $2, $3)`,
        [id, id_catequista, estado]
    );

    return resultado.rows[0];
};

/**
 * Busca el inscrito Pendiente de ese nivel para esa cédula. Se usa para encontrar el
 * inscrito que quedó esperando a que el Sacerdote valide su certificado prerrequisito.
 */
export const obtenerInscritoPendientePorCedulaRepository = async(cedula, nivel) => {
    const resultado = await pool.query(
        `${SELECT_INSCRITO_BASE} WHERE ic.cedula = $1 AND ic.nivel = $2 AND ic.estado = 'Pendiente'`,
        [cedula, nivel]
    );

    return resultado.rows[0];
};

export const eliminarInscritoRepository = async(id) => {
    const resultado = await pool.query(
        `SELECT * FROM fn_eliminar_inscrito_catequesis($1)`, [id]
    );

    return resultado.rows[0];
};
