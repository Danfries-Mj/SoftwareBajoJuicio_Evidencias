import { pool } from '../database/connection.js';
import { ejecutarConAuditoria } from './auditoria.repository.js';

const SELECT_DONACION_BASE = `
    SELECT * FROM vista_donaciones d
`;

export const FONDOS_PARROQUIALES = ['Fondo de Salud', 'Fondo General'];

export const obtenerDonacionesRepository = async(filtros = {}) => {
    const condiciones = [];
    const valores = [];

    if (filtros.id_usuario) {
        valores.push(filtros.id_usuario);
        condiciones.push(`d.id_usuario = $${valores.length}`);
    }

    if (filtros.estado) {
        valores.push(filtros.estado);
        condiciones.push(`d.estado = $${valores.length}`);
    }

    if (filtros.id_capilla_tesorero !== undefined && filtros.id_capilla_tesorero !== null) {
        valores.push(filtros.id_capilla_tesorero);
        condiciones.push(
            `((d.id_fondo IS NULL AND d.id_capilla = $${valores.length}) OR (d.id_fondo IS NOT NULL AND d.fondo_id_capilla = $${valores.length}))`
        );
    }

    if (filtros.solo_parroquiales) {
        valores.push(FONDOS_PARROQUIALES);
        condiciones.push(`(d.id_fondo IS NOT NULL AND d.fondo_nombre = ANY($${valores.length}))`);
    }

    const whereClause = condiciones.length ? `WHERE ${condiciones.join(' AND ')}` : '';

    const resultado = await pool.query(
        `${SELECT_DONACION_BASE} ${whereClause} ORDER BY d.fecha DESC`, valores
    );

    return resultado.rows;
};

export const obtenerDonacionPorIdRepository = async(id) => {
    const resultado = await pool.query(
        `${SELECT_DONACION_BASE} WHERE d.id_donacion = $1`, [id]
    );

    return resultado.rows[0];
};

export const crearDonacionRepository = async(donacion) => {
    const { id_usuario, id_capilla, fecha, monto, id_documento, id_fondo } = donacion;

    const resultado = await pool.query(
        `SELECT * FROM fn_crear_donacion($1, $2, $3, $4, $5, $6)`,
        [id_usuario, id_capilla, fecha, monto, id_documento || null, id_fondo || null]
    );

    return resultado.rows[0];
};

export const cambiarEstadoDonacionRepository = async(id, estado, idUsuarioRevisor) => {
    return await ejecutarConAuditoria(idUsuarioRevisor, async(client) => {
        const resultado = await client.query(
            `SELECT * FROM fn_cambiar_estado_donacion($1, $2)`, [id, estado]
        );

        return resultado.rows[0];
    });
};

export const eliminarDonacionRepository = async(id) => {
    const resultado = await pool.query(
        `SELECT * FROM fn_eliminar_donacion($1)`, [id]
    );

    return resultado.rows[0];
};