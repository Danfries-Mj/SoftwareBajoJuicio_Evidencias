import { pool } from '../database/connection.js';
import { ejecutarConAuditoria } from './auditoria.repository.js';

const SELECT_USUARIO_BASE = `
    SELECT * FROM vista_usuarios u
`;

export const obtenerUsuariosRepository = async(filtros = {}) => {
    const condiciones = [];
    const valores = [];

    if (filtros.rol) {
        valores.push(filtros.rol);
        condiciones.push(`u.rol = $${valores.length}`);
    }

    if (filtros.id_capilla) {
        valores.push(filtros.id_capilla);
        condiciones.push(`u.id_capilla = $${valores.length}`);
    }

    // Se compara contra undefined y no por valor de verdad: activo es booleano y
    // { activo: false } es un filtro válido (listar usuarios desactivados).
    if (filtros.activo !== undefined) {
        valores.push(filtros.activo);
        condiciones.push(`u.activo = $${valores.length}`);
    }

    const whereClause = condiciones.length ? `WHERE ${condiciones.join(' AND ')}` : '';

    const resultado = await pool.query(
        `${SELECT_USUARIO_BASE} ${whereClause} ORDER BY u.id_usuario ASC`, valores
    );

    return resultado.rows;
};

export const obtenerUsuarioPorIdRepository = async(id) => {
    const resultado = await pool.query(
        `${SELECT_USUARIO_BASE} WHERE u.id_usuario = $1`, [id]
    );

    return resultado.rows[0];
};

export const obtenerUsuarioPorCedulaRepository = async(cedula) => {
    const resultado = await pool.query(
        `${SELECT_USUARIO_BASE} WHERE u.cedula = $1`, [cedula]
    );

    return resultado.rows[0];
};

export const obtenerUsuarioPorPersonaRepository = async(idPersona) => {
    const resultado = await pool.query(
        `SELECT id_usuario, id_persona, correo, rol, id_capilla, activo
         FROM usuarios
         WHERE id_persona = $1`, [idPersona]
    );

    return resultado.rows[0] || null;
};

export const obtenerUsuarioPorCorreoRepository = async(correo) => {
    const resultado = await pool.query(
        `SELECT u.*, p.cedula, p.nombres, p.apellidos, p.telefono
         FROM usuarios u
         JOIN persona p ON p.id_persona = u.id_persona
         WHERE u.correo = $1`, [correo]
    );

    return resultado.rows[0];
};

export const guardarCodigoRecuperacionRepository = async(id_usuario, codigoHash, expira) => {
    await pool.query(
        `SELECT fn_guardar_codigo_recuperacion($1, $2, $3)`,
        [id_usuario, codigoHash, expira]
    );
};

export const actualizarContrasenaYLimpiarCodigoRepository = async(id_usuario, contrasenaHash) => {
    await pool.query(
        `SELECT fn_actualizar_contrasena_y_limpiar_codigo($1, $2)`,
        [id_usuario, contrasenaHash]
    );
};

export const crearUsuarioConPersonaRepository = async(datos, idUsuarioCreador) => {
    return await ejecutarConAuditoria(idUsuarioCreador, async(client) => {
        const resultado = await client.query(
            `SELECT fn_crear_usuario_con_persona($1, $2, $3, $4, $5, $6, $7, $8, $9) AS resultado`,
            [
                datos.idPersonaExistente ?? null, datos.cedula, datos.nombres, datos.apellidos,
                datos.telefono, datos.correo, datos.contrasenaHash, datos.rol, datos.id_capilla
            ]
        );

        return resultado.rows[0].resultado;
    });
};

export const actualizarUsuarioRepository = async(id, datos, idUsuarioEditor) => {
    return await ejecutarConAuditoria(idUsuarioEditor, async(client) => {
        const resultado = await client.query(
            `SELECT * FROM fn_actualizar_usuario($1, $2, $3, $4)`,
            [id, datos.rol, datos.id_capilla, datos.activo]
        );

        return resultado.rows[0];
    });
};

export const actualizarPerfilUsuarioRepository = async(id, datos) => {
    const resultado = await pool.query(
        `SELECT * FROM fn_actualizar_perfil_usuario($1, $2, $3, $4, $5, $6)`,
        [id, datos.nombres, datos.apellidos, datos.telefono, datos.correo, datos.contrasenaHash || null]
    );

    return resultado.rows[0];
};

export const obtenerUsuariosPorCapillaRepository = async(idCapilla) => {
    const valores = [];
    let query = `SELECT id_usuario FROM usuarios WHERE activo = true`;
    if (idCapilla) {
        valores.push(idCapilla);
        query += ` AND id_capilla = $1`;
    }
    const resultado = await pool.query(query, valores);
    return resultado.rows.map(r => r.id_usuario);
};

export const cambiarEstadoUsuarioRepository = async(id, activo, idUsuarioEditor) => {
    return await ejecutarConAuditoria(idUsuarioEditor, async(client) => {
        const resultado = await client.query(
            `SELECT * FROM fn_cambiar_estado_usuario($1, $2)`,
            [id, activo]
        );

        return resultado.rows[0];
    });
};
