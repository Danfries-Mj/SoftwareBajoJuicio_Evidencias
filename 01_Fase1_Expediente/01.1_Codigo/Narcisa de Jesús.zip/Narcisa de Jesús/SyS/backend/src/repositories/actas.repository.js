import { pool } from '../database/connection.js';

const SELECT_ACTA_BASE = `
    SELECT * FROM vista_actas a
`;

export const obtenerActasRepository = async(filtros = {}) => {
    const condiciones = [];
    const valores = [];

    if (filtros.id_capilla) {
        valores.push(filtros.id_capilla);
        condiciones.push(`a.id_capilla = $${valores.length}`);
    }

    if (filtros.id_capilla_alcance !== undefined && filtros.id_capilla_alcance !== null) {
        valores.push(filtros.id_capilla_alcance);
        condiciones.push(`(a.id_capilla IS NULL OR a.id_capilla = $${valores.length})`);
    }

    if (filtros.tipo) {
        valores.push(filtros.tipo);
        condiciones.push(`a.tipo = $${valores.length}`);
    }

    const whereClause = condiciones.length ? `WHERE ${condiciones.join(' AND ')}` : '';

    const resultado = await pool.query(
        `${SELECT_ACTA_BASE} ${whereClause} ORDER BY a.fecha DESC`, valores
    );

    return resultado.rows;
};

export const obtenerActaPorIdRepository = async(id) => {
    const resultado = await pool.query(
        `${SELECT_ACTA_BASE} WHERE a.id_acta = $1`, [id]
    );

    return resultado.rows[0];
};

export const crearActaRepository = async(acta) => {
    const { titulo, tipo, id_capilla, lugar, descripcion, asistentes, fecha, proxima_reunion, creado_por } = acta;

    const resultado = await pool.query(
        `SELECT * FROM fn_crear_acta($1, $2, $3, $4, $5, $6, $7, $8, $9)`, [titulo, tipo, id_capilla, lugar, descripcion, asistentes, fecha, proxima_reunion, creado_por]
    );

    return resultado.rows[0];
};

export const actualizarActaRepository = async(id, acta) => {
    const { titulo, tipo, id_capilla, lugar, descripcion, asistentes, fecha, proxima_reunion, estado } = acta;

    const resultado = await pool.query(
        `SELECT * FROM fn_actualizar_acta($1, $2, $3, $4, $5, $6, $7, $8, $9, $10)`, [id, titulo, tipo, id_capilla, lugar, descripcion, asistentes, fecha, proxima_reunion, estado]
    );

    return resultado.rows[0];
};

export const eliminarActaRepository = async(id) => {
    const resultado = await pool.query(
        `SELECT * FROM fn_eliminar_acta($1)`, [id]
    );

    return resultado.rows[0];
};