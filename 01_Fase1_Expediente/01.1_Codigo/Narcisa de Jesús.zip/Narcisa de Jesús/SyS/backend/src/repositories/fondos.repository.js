import { pool } from '../database/connection.js';

const SELECT_FONDO_BASE = `
    SELECT * FROM vista_fondos f
`;

export const obtenerFondosRepository = async(filtros = {}) => {
    const condiciones = [];
    const valores = [];

    if (filtros.id_capilla !== undefined) {
        if (filtros.id_capilla === null) {
            condiciones.push('f.id_capilla IS NULL');
        } else {
            valores.push(filtros.id_capilla);
            condiciones.push(`f.id_capilla = $${valores.length}`);
        }
    }

    const whereClause = condiciones.length ? `WHERE ${condiciones.join(' AND ')}` : '';

    const resultado = await pool.query(
        `${SELECT_FONDO_BASE} ${whereClause} ORDER BY f.id_fondo ASC`, valores
    );

    return resultado.rows;
};

export const obtenerFondosPorAlcanceRepository = async(idCapilla) => {
    const resultado = await pool.query(
        `${SELECT_FONDO_BASE} WHERE f.id_capilla IS NULL OR f.id_capilla = $1 ORDER BY f.id_fondo ASC`, [idCapilla]
    );

    return resultado.rows;
};

export const obtenerFondoPorIdRepository = async(id) => {
    const resultado = await pool.query(
        `${SELECT_FONDO_BASE} WHERE f.id_fondo = $1`, [id]
    );

    return resultado.rows[0];
};

export const crearFondoRepository = async(fondo) => {
    const { nombre, descripcion, saldo_actual, id_capilla } = fondo;

    const resultado = await pool.query(
        `SELECT * FROM fn_crear_fondo($1, $2, $3, $4)`,
        [nombre, descripcion, saldo_actual, id_capilla]
    );

    return resultado.rows[0];
};

export const actualizarFondoRepository = async(id, fondo) => {
    const { nombre, descripcion, id_capilla } = fondo;

    const resultado = await pool.query(
        `SELECT * FROM fn_actualizar_fondo($1, $2, $3, $4)`,
        [id, nombre, descripcion, id_capilla]
    );

    return resultado.rows[0];
};

export const eliminarFondoRepository = async(id) => {
    const resultado = await pool.query(
        `SELECT * FROM fn_eliminar_fondo($1)`, [id]
    );

    return resultado.rows[0];
};
