import { pool } from '../database/connection.js';

const SELECT_INTENCION_BASE = `
    SELECT * FROM vista_intenciones_misa i
`;

export const obtenerIntencionesRepository = async(filtros = {}) => {
    const condiciones = [];
    const valores = [];

    if (filtros.id_usuario) {
        valores.push(filtros.id_usuario);
        condiciones.push(`i.id_usuario = $${valores.length}`);
    }

    if (filtros.estado) {
        valores.push(filtros.estado);
        condiciones.push(`i.estado = $${valores.length}`);
    }

    const whereClause = condiciones.length ? `WHERE ${condiciones.join(' AND ')}` : '';

    const resultado = await pool.query(
        `${SELECT_INTENCION_BASE} ${whereClause} ORDER BY i.fecha_deseada ASC`, valores
    );

    return resultado.rows;
};

export const obtenerIntencionPorIdRepository = async(id) => {
    const resultado = await pool.query(
        `${SELECT_INTENCION_BASE} WHERE i.id_intencion = $1`, [id]
    );

    return resultado.rows[0];
};

export const crearIntencionRepository = async(intencion) => {
    const { id_usuario, nombre_mencionar, tipo, fecha_deseada, id_eucaristia } = intencion;

    const resultado = await pool.query(
        `SELECT * FROM fn_crear_intencion_misa($1, $2, $3, $4, $5)`,
        [id_usuario, nombre_mencionar, tipo, fecha_deseada, id_eucaristia]
    );

    return resultado.rows[0];
};

export const asignarIntencionRepository = async(id, idEucaristia) => {
    const resultado = await pool.query(
        `SELECT * FROM fn_asignar_intencion_misa($1, $2)`,
        [id, idEucaristia]
    );

    return resultado.rows[0];
};

export const rechazarIntencionRepository = async(id) => {
    const resultado = await pool.query(
        `SELECT * FROM fn_rechazar_intencion_misa($1)`, [id]
    );

    return resultado.rows[0];
};

export const eliminarIntencionRepository = async(id) => {
    const resultado = await pool.query(
        `SELECT * FROM fn_eliminar_intencion_misa($1)`, [id]
    );

    return resultado.rows[0];
};
