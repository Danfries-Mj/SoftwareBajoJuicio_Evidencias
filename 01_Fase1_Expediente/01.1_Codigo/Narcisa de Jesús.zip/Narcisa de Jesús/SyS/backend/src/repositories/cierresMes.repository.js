import { pool } from '../database/connection.js';

export const obtenerCierresRepository = async() => {
    const resultado = await pool.query(
        'SELECT * FROM vista_cierres_mes ORDER BY anio DESC, mes DESC'
    );

    return resultado.rows;
};

export const obtenerCierresPorAlcanceRepository = async(idCapilla) => {
    const resultado = await pool.query(
        `SELECT * FROM vista_cierres_mes
         WHERE id_capilla IS NULL OR id_capilla = $1
         ORDER BY anio DESC, mes DESC`, [idCapilla]
    );

    return resultado.rows;
};

export const obtenerCierrePorIdRepository = async(id) => {
    const resultado = await pool.query(
        'SELECT * FROM vista_cierres_mes WHERE id_cierre = $1', [id]
    );

    return resultado.rows[0];
};

export const obtenerCierrePorMesAnioRepository = async(mes, anio, idCapilla) => {
    const resultado = await pool.query(
        `SELECT * FROM cierres_mes
         WHERE mes = $1 AND anio = $2 AND id_capilla IS NOT DISTINCT FROM $3`, [mes, anio, idCapilla]
    );

    return resultado.rows[0];
};


/**
 * Sin idCapilla: cierre parroquial, suma todos los fondos (comportamiento histórico).
 * Con idCapilla: cierre de capilla, restringido a los movimientos de los fondos de esa capilla.
 */
export const calcularTotalesMesRepository = async(mes, anio, idCapilla) => {
    const condiciones = ['EXTRACT(MONTH FROM m.fecha) = $1', 'EXTRACT(YEAR FROM m.fecha) = $2'];
    const valores = [mes, anio];

    if (idCapilla !== null && idCapilla !== undefined) {
        valores.push(idCapilla);
        condiciones.push(`f.id_capilla = $${valores.length}`);
    }

    const resultado = await pool.query(
        `SELECT
            COALESCE(SUM(m.monto) FILTER (WHERE m.tipo = 'Ingreso'), 0) AS total_ingresos,
            COALESCE(SUM(m.monto) FILTER (WHERE m.tipo = 'Egreso'), 0) AS total_egresos
         FROM movimientos_financieros m
         JOIN fondos f ON f.id_fondo = m.id_fondo
         WHERE ${condiciones.join(' AND ')}`, valores
    );

    return resultado.rows[0];
};

export const crearCierreRepository = async(cierre) => {
    const { mes, anio, total_ingresos, total_egresos, generado_por, id_capilla } = cierre;

    const resultado = await pool.query(
        `SELECT * FROM fn_crear_cierre_mes($1, $2, $3, $4, $5, $6)`, [mes, anio, total_ingresos, total_egresos, generado_por, id_capilla ?? null]
    );

    return resultado.rows[0];
};

export const eliminarCierreRepository = async(id) => {
    const resultado = await pool.query(
        `SELECT * FROM fn_eliminar_cierre_mes($1)`, [id]
    );

    return resultado.rows[0];
};