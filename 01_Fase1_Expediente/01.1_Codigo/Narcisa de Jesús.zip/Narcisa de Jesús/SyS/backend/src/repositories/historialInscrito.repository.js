import { pool } from '../database/connection.js';

export const obtenerHistorialPorInscritoRepository = async(idInscrito) => {
    const resultado = await pool.query(
        `SELECT * FROM vista_historial_inscrito
         WHERE id_inscrito = $1
         ORDER BY fecha_cambio DESC`, [idInscrito]
    );

    return resultado.rows;
};

export const obtenerHistorialPorIdRepository = async(id) => {
    const resultado = await pool.query(
        'SELECT * FROM vista_historial_inscrito WHERE id_historial = $1', [id]
    );

    return resultado.rows[0];
};

export const crearHistorialInscritoRepository = async(historial) => {
    const { id_inscrito, comprobante, estado_anterior, estado_nuevo, nota } = historial;

    const resultado = await pool.query(
        `SELECT * FROM fn_crear_historial_inscrito($1, $2, $3, $4, $5)`,
        [id_inscrito, comprobante, estado_anterior, estado_nuevo, nota]
    );

    return resultado.rows[0];
};
