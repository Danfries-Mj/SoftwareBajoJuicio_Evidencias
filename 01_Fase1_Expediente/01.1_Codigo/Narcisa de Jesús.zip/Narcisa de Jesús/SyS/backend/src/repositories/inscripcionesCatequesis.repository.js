import { pool } from '../database/connection.js';
import { ejecutarConAuditoria } from './auditoria.repository.js';

const SELECT_INSCRIPCION_BASE = `
    SELECT * FROM vista_inscripciones_catequesis i
`;

export const obtenerInscripcionesRepository = async(filtros = {}) => {
    const condiciones = [];
    const valores = [];

    if (filtros.id_capilla) {
        valores.push(filtros.id_capilla);
        condiciones.push(`i.id_capilla = $${valores.length}`);
    }

    if (filtros.nivel) {
        valores.push(filtros.nivel);
        condiciones.push(`i.nivel = $${valores.length}`);
    }

    if (filtros.estado) {
        valores.push(filtros.estado);
        condiciones.push(`i.estado = $${valores.length}`);
    }

    if (filtros.id_laico) {
        valores.push(filtros.id_laico);
        condiciones.push(`i.id_laico = $${valores.length}`);
    }

    const whereClause = condiciones.length ? `WHERE ${condiciones.join(' AND ')}` : '';

    const resultado = await pool.query(
        `${SELECT_INSCRIPCION_BASE} ${whereClause} ORDER BY i.fecha_solicitud DESC`, valores
    );

    return resultado.rows;
};

export const obtenerInscripcionPorIdRepository = async(id) => {
    const resultado = await pool.query(
        `${SELECT_INSCRIPCION_BASE} WHERE i.id_inscripcion = $1`, [id]
    );

    return resultado.rows[0];
};

export const crearInscripcionRepository = async(inscripcion) => {
    const { id_laico, nivel, id_capilla, monto, id_documento } = inscripcion;

    const resultado = await pool.query(
        `SELECT * FROM fn_crear_inscripcion_catequesis($1, $2, $3, $4, $5)`,
        [id_laico, nivel, id_capilla, monto, id_documento || null]
    );

    return resultado.rows[0];
};

export const cambiarEstadoInscripcionRepository = async(id, estado, idRevisor) => {
    const pagoConfirmado = estado === 'Aprobada';
    return await ejecutarConAuditoria(idRevisor, async(client) => {
        const resultado = await client.query(
            `SELECT * FROM fn_cambiar_estado_inscripcion_catequesis($1, $2, $3, $4)`,
            [id, estado, idRevisor, pagoConfirmado]
        );

        return resultado.rows[0];
    });
};

export const eliminarInscripcionRepository = async(id) => {
    const resultado = await pool.query(
        `SELECT * FROM fn_eliminar_inscripcion_catequesis($1)`, [id]
    );

    return resultado.rows[0];
};

/**
 * Indica si el laico ya tiene una inscripción de ese nivel aprobada. Se levanta si esa
 * inscripción se rechaza (deja de estar 'Aprobada') o se elimina.
 */
export const existeInscripcionAprobadaRepository = async(id_laico, nivel) => {
    const resultado = await pool.query(
        `SELECT EXISTS (
            SELECT 1 FROM inscripciones_catequesis
            WHERE id_laico = $1 AND nivel = $2 AND estado = 'Aprobada'
        ) AS existe`,
        [id_laico, nivel]
    );

    return resultado.rows[0].existe;
};
