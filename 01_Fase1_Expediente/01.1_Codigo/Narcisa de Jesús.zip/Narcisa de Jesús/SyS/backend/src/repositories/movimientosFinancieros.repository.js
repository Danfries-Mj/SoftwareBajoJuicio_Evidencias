import { pool } from '../database/connection.js';
import { ejecutarConAuditoria } from './auditoria.repository.js';

const SELECT_MOVIMIENTO_BASE = `
    SELECT * FROM vista_movimientos_financieros m
`;

export const obtenerMovimientosRepository = async(filtros = {}) => {
    const condiciones = [];
    const valores = [];

    if (filtros.id_fondo) {
        valores.push(filtros.id_fondo);
        condiciones.push(`m.id_fondo = $${valores.length}`);
    }

    if (filtros.tipo) {
        valores.push(filtros.tipo);
        condiciones.push(`m.tipo = $${valores.length}`);
    }

    if (filtros.fecha_desde) {
        valores.push(filtros.fecha_desde);
        condiciones.push(`m.fecha >= $${valores.length}`);
    }

    if (filtros.fecha_hasta) {
        valores.push(filtros.fecha_hasta);
        condiciones.push(`m.fecha <= $${valores.length}`);
    }

    if (filtros.id_capilla !== undefined) {
        if (filtros.id_capilla === null) {
            condiciones.push(`m.id_capilla IS NULL`);
        } else {
            valores.push(filtros.id_capilla);
            condiciones.push(`(m.id_capilla = $${valores.length} OR m.id_capilla IS NULL)`);
        }
    }

    const whereClause = condiciones.length ? `WHERE ${condiciones.join(' AND ')}` : '';

    const resultado = await pool.query(
        `${SELECT_MOVIMIENTO_BASE} ${whereClause} ORDER BY m.fecha DESC, m.id_movimiento DESC`, valores
    );

    return resultado.rows;
};

export const obtenerMovimientoPorIdRepository = async(id) => {
    const resultado = await pool.query(
        `${SELECT_MOVIMIENTO_BASE} WHERE m.id_movimiento = $1`, [id]
    );

    return resultado.rows[0];
};

export const crearMovimientoRepository = async(movimiento, idUsuario) => {
    return await ejecutarConAuditoria(idUsuario, async(client) => {
        const resultado = await client.query(
            `SELECT * FROM fn_crear_movimiento_financiero($1, $2, $3, $4, $5, $6, $7, $8)`,
            [
                movimiento.tipo, movimiento.categoria, movimiento.descripcion, movimiento.id_fondo,
                movimiento.monto, movimiento.fecha, movimiento.justificacion, movimiento.registrado_por
            ]
        );

        return resultado.rows[0];
    });
};

export const actualizarMovimientoRepository = async(id, movimiento, idUsuario) => {
    return await ejecutarConAuditoria(idUsuario, async(client) => {
        const resultado = await client.query(
            `SELECT * FROM fn_actualizar_movimiento_financiero($1, $2, $3, $4, $5, $6, $7, $8)`,
            [
                id, movimiento.tipo, movimiento.categoria, movimiento.descripcion, movimiento.id_fondo,
                movimiento.monto, movimiento.fecha, movimiento.justificacion
            ]
        );

        return resultado.rows[0];
    });
};

export const eliminarMovimientoRepository = async(id, idUsuario) => {
    return await ejecutarConAuditoria(idUsuario, async(client) => {
        const resultado = await client.query(
            `SELECT * FROM fn_eliminar_movimiento_financiero($1)`, [id]
        );

        return resultado.rows[0];
    });
};
