import { pool } from '../database/connection.js';

export const ejecutarConAuditoria = async(idUsuario, callback) => {
    const client = await pool.connect();

    try {
        await client.query('BEGIN');

        if (idUsuario) {
            await client.query(
                `SELECT set_config('app.current_user_id', $1, true)`, [String(idUsuario)]
            );
        }

        const resultado = await callback(client);

        await client.query('COMMIT');

        return resultado;
    } catch (error) {
        await client.query('ROLLBACK');
        throw error;
    } finally {
        client.release();
    }
};

export const obtenerAuditoriaRepository = async(filtros = {}) => {
    const condiciones = [];
    const valores = [];

    if (filtros.tabla_afectada) {
        valores.push(filtros.tabla_afectada);
        condiciones.push(`tabla_afectada = $${valores.length}`);
    }

    if (filtros.id_usuario) {
        valores.push(filtros.id_usuario);
        condiciones.push(`id_usuario = $${valores.length}`);
    }

    const whereClause = condiciones.length ? `WHERE ${condiciones.join(' AND ')}` : '';

    const resultado = await pool.query(
        `SELECT * FROM vista_auditoria ${whereClause} ORDER BY fecha DESC`, valores
    );

    return resultado.rows;
};

export const obtenerAuditoriaPorIdRepository = async(id) => {
    const resultado = await pool.query(
        'SELECT * FROM vista_auditoria WHERE id_auditoria = $1', [id]
    );

    return resultado.rows[0];
};