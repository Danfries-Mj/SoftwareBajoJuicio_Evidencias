import { pool } from '../database/connection.js';

export const obtenerNotificacionesRepository = async(idUsuario, soloPendientes = false) => {
    let query = `SELECT * FROM vista_notificaciones WHERE id_usuario = $1`;
    if (soloPendientes) {
        query += ` AND leida = false`;
    }
    query += ` ORDER BY fecha_creacion DESC LIMIT 50`;

    const resultado = await pool.query(query, [idUsuario]);
    return resultado.rows;
};

export const contarPendientesRepository = async(idUsuario) => {
    const resultado = await pool.query(
        `SELECT COUNT(*) AS pendientes FROM vista_notificaciones WHERE id_usuario = $1 AND leida = false`,
        [idUsuario]
    );
    return parseInt(resultado.rows[0].pendientes, 10);
};

export const crearNotificacionRepository = async(idUsuario, titulo, mensaje) => {
    const resultado = await pool.query(
        `SELECT * FROM fn_crear_notificacion($1, $2, $3)`,
        [idUsuario, titulo, mensaje]
    );
    return resultado.rows[0];
};

export const marcarLeidaRepository = async(idNotificacion, idUsuario) => {
    const resultado = await pool.query(
        `SELECT * FROM fn_marcar_notificacion_leida($1, $2)`,
        [idNotificacion, idUsuario]
    );
    return resultado.rows[0];
};

export const marcarTodasLeidasRepository = async(idUsuario) => {
    const resultado = await pool.query(
        `SELECT * FROM fn_marcar_todas_notificaciones_leidas($1)`,
        [idUsuario]
    );
    return resultado.rows;
};
