import { pool } from '../database/connection.js';

const SELECT_SOLICITUD_BASE = `
    SELECT * FROM vista_solicitudes_sacramento s
`;

export const obtenerSolicitudesRepository = async(filtros = {}) => {
    const condiciones = [];
    const valores = [];

    if (filtros.id_usuario) {
        valores.push(filtros.id_usuario);
        condiciones.push(`s.id_usuario = $${valores.length}`);
    }

    if (filtros.sacramento) {
        valores.push(filtros.sacramento);
        condiciones.push(`s.sacramento = $${valores.length}`);
    }

    if (filtros.sacramentos?.length) {
        valores.push(filtros.sacramentos);
        condiciones.push(`s.sacramento = ANY($${valores.length})`);
    }

    if (filtros.estado) {
        valores.push(filtros.estado);
        condiciones.push(`s.estado = $${valores.length}`);
    }

    if (filtros.id_capilla) {
        valores.push(filtros.id_capilla);
        condiciones.push(`s.id_capilla = $${valores.length}`);
    }

    const whereClause = condiciones.length ? `WHERE ${condiciones.join(' AND ')}` : '';

    const resultado = await pool.query(
        `${SELECT_SOLICITUD_BASE} ${whereClause} ORDER BY s.fecha_solicitud DESC`, valores
    );

    return resultado.rows;
};

/**
 * Busca la solicitud Pendiente de ese sacramento cuyo beneficiario sea esta persona (por
 * id_persona, vía beneficiarios_solicitud). Se usa para encontrar la solicitud que depende
 * de un certificado que el Sacerdote acaba de rechazar.
 */
export const obtenerSolicitudPendientePorBeneficiarioRepository = async(idPersona, sacramento) => {
    const resultado = await pool.query(
        `${SELECT_SOLICITUD_BASE}
         WHERE s.estado = 'Pendiente'
           AND s.sacramento = $2
           AND s.id_solicitud IN (
               SELECT b.id_solicitud FROM beneficiarios_solicitud b WHERE b.id_persona = $1
           )
         ORDER BY s.fecha_solicitud DESC
         LIMIT 1`,
        [idPersona, sacramento]
    );

    return resultado.rows[0];
};

export const obtenerSolicitudPorIdRepository = async(id) => {
    const resultado = await pool.query(
        `${SELECT_SOLICITUD_BASE} WHERE s.id_solicitud = $1`, [id]
    );

    return resultado.rows[0];
};

export const crearSolicitudConBeneficiariosRepository = async(solicitud, beneficiarios = []) => {
    const resultado = await pool.query(
        `SELECT fn_crear_solicitud_con_beneficiarios($1, $2, $3, $4, $5, $6) AS resultado`,
        [
            solicitud.id_usuario, solicitud.sacramento, solicitud.modalidad,
            solicitud.id_capilla, solicitud.id_documento, JSON.stringify(beneficiarios)
        ]
    );

    return resultado.rows[0].resultado;
};

export const asignarSolicitudRepository = async(id, datos) => {
    const { fecha_asignada, hora_inicio, hora_fin, id_capilla } = datos;

    const resultado = await pool.query(
        `SELECT * FROM fn_asignar_solicitud_sacramento($1, $2, $3, $4, $5)`,
        [id, fecha_asignada, hora_inicio, hora_fin, id_capilla]
    );

    return resultado.rows[0];
};

export const aprobarSolicitudRepository = async(id) => {
    const resultado = await pool.query(
        `SELECT * FROM fn_aprobar_solicitud_sacramento($1)`, [id]
    );

    return resultado.rows[0];
};

export const rechazarSolicitudRepository = async(id) => {
    const resultado = await pool.query(
        `SELECT * FROM fn_rechazar_solicitud_sacramento($1)`, [id]
    );

    return resultado.rows[0];
};

export const eliminarSolicitudRepository = async(id) => {
    const resultado = await pool.query(
        `SELECT * FROM fn_eliminar_solicitud_sacramento($1)`, [id]
    );

    return resultado.rows[0];
};

/**
 * Indica si la cédula ya es beneficiaria de una solicitud de ese sacramento en estado
 * 'Atendida'. Se levanta automáticamente si esa solicitud se rechaza (deja de estar
 * 'Atendida') o se elimina (deja de existir), sin necesidad de lógica adicional.
 */
export const existeSolicitudAtendidaPorCedulaRepository = async(cedula, sacramento) => {
    const resultado = await pool.query(
        `SELECT EXISTS (
            SELECT 1
            FROM vista_solicitudes_sacramento s
            JOIN vista_beneficiarios_solicitud b ON b.id_solicitud = s.id_solicitud
            WHERE b.cedula = $1 AND s.sacramento = $2 AND s.estado = 'Atendida'
        ) AS existe`,
        [cedula, sacramento]
    );

    return resultado.rows[0].existe;
};
