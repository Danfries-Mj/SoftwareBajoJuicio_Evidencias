import { pool } from '../database/connection.js';

export const obtenerBeneficiariosPorSolicitudRepository = async(idSolicitud) => {
    const resultado = await pool.query(
        'SELECT * FROM vista_beneficiarios_solicitud WHERE id_solicitud = $1', [idSolicitud]
    );

    return resultado.rows;
};

export const obtenerBeneficiarioPorIdRepository = async(id) => {
    const resultado = await pool.query(
        'SELECT * FROM vista_beneficiarios_solicitud WHERE id_beneficiario = $1', [id]
    );

    return resultado.rows[0];
};

export const crearBeneficiarioRepository = async(beneficiario, client = pool) => {
    const { id_solicitud, rol_beneficiario, nombres, apellidos, cedula, telefono, id_persona } = beneficiario;

    const resultado = await client.query(
        `SELECT * FROM fn_crear_beneficiario_solicitud($1, $2, $3, $4, $5, $6, $7)`, [id_solicitud, rol_beneficiario, nombres, apellidos, cedula, telefono || null, id_persona]
    );

    return resultado.rows[0];
};

export const eliminarBeneficiarioRepository = async(id) => {
    const resultado = await pool.query(
        `SELECT * FROM fn_eliminar_beneficiario_solicitud($1)`, [id]
    );

    return resultado.rows[0];
};