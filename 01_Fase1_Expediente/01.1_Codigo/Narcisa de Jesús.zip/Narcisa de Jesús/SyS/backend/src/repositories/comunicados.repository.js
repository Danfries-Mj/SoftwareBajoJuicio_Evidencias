import { pool } from '../database/connection.js';

const SELECT_COMUNICADO_BASE = `
    SELECT * FROM vista_comunicados com
`;

export const obtenerComunicadosRepository = async(filtros = {}) => {
    const condiciones = [];
    const valores = [];

    if (filtros.id_capilla) {
        valores.push(filtros.id_capilla);
        condiciones.push(
            filtros.incluirGenerales ?
            `(com.id_capilla = $${valores.length} OR com.id_capilla IS NULL)` :
            `com.id_capilla = $${valores.length}`
        );
    }

    if (filtros.estado) {
        valores.push(filtros.estado);
        condiciones.push(`com.estado = $${valores.length}`);
    }

    const whereClause = condiciones.length ? `WHERE ${condiciones.join(' AND ')}` : '';

    const resultado = await pool.query(
        `${SELECT_COMUNICADO_BASE} ${whereClause} ORDER BY com.fecha_creacion DESC`, valores
    );

    return resultado.rows;
};

export const obtenerComunicadoPorIdRepository = async(id) => {
    const resultado = await pool.query(
        `${SELECT_COMUNICADO_BASE} WHERE com.id_comunicado = $1`, [id]
    );

    return resultado.rows[0];
};

export const crearComunicadoRepository = async(comunicado) => {
    const { titulo, mensaje, id_capilla, estado, creado_por } = comunicado;

    const resultado = await pool.query(
        `SELECT * FROM fn_crear_comunicado($1, $2, $3, $4, $5)`, [titulo, mensaje, id_capilla, estado, creado_por]
    );

    return resultado.rows[0];
};

export const actualizarComunicadoRepository = async(id, comunicado) => {
    const { titulo, mensaje, id_capilla, estado } = comunicado;

    const resultado = await pool.query(
        `SELECT * FROM fn_actualizar_comunicado($1, $2, $3, $4, $5)`, [id, titulo, mensaje, id_capilla, estado]
    );

    return resultado.rows[0];
};

export const eliminarComunicadoRepository = async(id) => {
    const resultado = await pool.query(
        `SELECT * FROM fn_eliminar_comunicado($1)`, [id]
    );

    return resultado.rows[0];
};