import jwt from 'jsonwebtoken';
import { jwtConfig } from '../config/jwt.config.js';

export const verificarToken = (req, res, next) => {
    const encabezado = req.headers['authorization'];

    if (!encabezado || !encabezado.startsWith('Bearer ')) {
        return res.status(401).json({ mensaje: 'Token de autenticación no proporcionado' });
    }

    const token = encabezado.split(' ')[1];

    try {
        const payload = jwt.verify(token, jwtConfig.secret);
        req.usuario = payload;
        next();
    } catch (error) {
        return res.status(401).json({ mensaje: 'Token inválido o expirado' });
    }
};

export const autorizarRoles = (...rolesPermitidos) => {
    return (req, res, next) => {
        if (!req.usuario) {
            return res.status(401).json({ mensaje: 'No autenticado' });
        }

        if (!rolesPermitidos.includes(req.usuario.rol)) {
            return res.status(403).json({
                mensaje: 'No tiene permisos para realizar esta acción',
                rolesPermitidos,
                rolActual: req.usuario.rol
            });
        }

        next();
    };
};
